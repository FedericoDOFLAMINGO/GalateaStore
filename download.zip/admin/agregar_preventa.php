<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */

session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';
requireRole('admin');

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$msg = '';
$msg_type = '';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    csrf_validate();
    $nombre      = trim($_POST['nombre_producto'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio      = floatval($_POST['precio'] ?? 0);
    $stock       = intval($_POST['stock_disponible'] ?? 0);
    $categoria   = trim($_POST['categoria'] ?? '');
    $fecha_inicio= $_POST['fecha_inicio'] ?? '';
    $fecha_fin   = $_POST['fecha_fin'] ?? '';
    $imagen_url  = trim($_POST['imagen_url'] ?? '');

    if (empty($nombre) || $precio <= 0 || $stock < 0) {
        $msg = 'Por favor completa todos los campos obligatorios correctamente.';
        $msg_type = 'err';
    } else {
        $stmt = $conn->prepare("INSERT INTO preventas (nombre_producto, descripcion, precio, stock_disponible, categoria, fecha_inicio, fecha_fin, imagen_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdiisss", $nombre, $descripcion, $precio, $stock, $categoria, $fecha_inicio, $fecha_fin, $imagen_url);
        if ($stmt->execute()) {
            $msg = '✅ Preventa agregada correctamente.';
            $msg_type = 'ok';
        } else {
            $msg = '❌ Error al guardar: ' . $stmt->error;
            $msg_type = 'err';
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agregar Preventa — One Piece Preventas</title>
  <link rel="stylesheet" href="../css/estilos.css">
  <link rel="stylesheet" href="../css/animations.css">
</head>
<body class="dashboard-body">

<?php include '../navbar.php'; ?>
<?php
include '../breadcrumbs.php';
generarBreadcrumbs($breadcrumbs_agregar_preventa);
?>

<div class="page-content">
  <h1 class="page-title">➕ Agregar Preventa</h1>

  <div class="form-card">
    <?php if ($msg): ?>
      <div class="msg-box msg-<?php echo $msg_type; ?>"><?php echo htmlspecialchars($msg); ?></div>
    <?php endif; ?>

    <?= csrf_field() ?>
  <form method="POST" action="">
      <div class="form-row">
        <div class="form-field">
          <label>Nombre del producto *</label>
          <input type="text" name="nombre_producto" required placeholder="Ej: Starter Deck Zoro">
        </div>
        <div class="form-field">
          <label>Categoría</label>
          <select name="categoria">
            <option value="">— Seleccionar —</option>
            <option value="Starters">Starters</option>
            <option value="Expansiones">Expansiones</option>
            <option value="accesorios">Accesorios</option>
            <option value="Figuras">Figuras</option>
          </select>
        </div>
      </div>

      <div class="form-field">
        <label>Descripción</label>
        <textarea name="descripcion" placeholder="Describe el producto..."></textarea>
      </div>

      <div class="form-row">
        <div class="form-field">
          <label>Precio (MXN) *</label>
          <input type="number" name="precio" min="0" step="0.01" required placeholder="0.00">
        </div>
        <div class="form-field">
          <label>Stock disponible *</label>
          <input type="number" name="stock_disponible" min="0" required placeholder="0">
        </div>
      </div>

      <div class="form-row">
        <div class="form-field">
          <label>Fecha inicio</label>
          <input type="date" name="fecha_inicio">
        </div>
        <div class="form-field">
          <label>Fecha fin</label>
          <input type="date" name="fecha_fin">
        </div>
      </div>

      <div class="form-field">
        <label>URL de imagen</label>
        <input type="text" name="imagen_url" placeholder="https://... o ruta relativa">
      </div>

      <button type="submit" class="btn-submit">💾 Guardar Preventa</button>
      <a href="panel_admin.php"
         style="display:block;text-align:center;margin-top:12px;color:rgba(247,214,122,0.6);font-size:0.88rem;text-decoration:none;">
        ← Volver al panel
      </a>
    </form>
  </div>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="../js/cache.js"></script>
<script src="../js/api.js"></script>
<script src="../js/dom.js"></script>
<script src="../js/animations.js"></script>
<script src="../js/polling.js"></script>
<script src="../js/menu-scripts.js"></script>
</body>
</html>

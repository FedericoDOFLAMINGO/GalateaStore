<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
session_start();
include __DIR__ . '/../navbar.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$success = $_GET['success'] ?? null;
$error = $_GET['error'] ?? '';

?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Resultado de Edición</title>
  <link rel="stylesheet" href="../css/estilos.css" />
</head>
<body class="dashboard-body">


<div style="text-align:center; margin-top:50px;">
  <?php if ($success == 1): ?>
    <h2 style="color: #4CAF50;">✅ Preventa actualizada correctamente.</h2>
  <?php else: ?>
    <h2 style="color: #f44336;">❌ Error al actualizar preventa.</h2>
    <p><?php echo htmlspecialchars($error); ?></p>
  <?php endif; ?>
  <a href="panel_admin.php" style="color: #f7d67a; font-weight:bold;">⬅️ Volver al panel</a>
</div>

</body>
</html>

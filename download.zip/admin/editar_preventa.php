<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */

session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';
requireRole('admin');

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$msg      = '';
$msg_type = '';
$preventa = null;

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM preventas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $preventa = $res->fetch_assoc();
    $stmt->close();
}

if (!$preventa && $id === 0) {
    // Mostrar lista para seleccionar
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $pid         = intval($_POST['id']);
    $nombre      = trim($_POST['nombre_producto'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $precio      = floatval($_POST['precio'] ?? 0);
    $stock       = intval($_POST['stock_disponible'] ?? 0);
    $categoria   = trim($_POST['categoria'] ?? '');
    $fecha_inicio= $_POST['fecha_inicio'] ?? '';
    $fecha_fin   = $_POST['fecha_fin'] ?? '';
    $imagen_url  = trim($_POST['imagen_url'] ?? '');

    $stmt = $conn->prepare("UPDATE preventas SET nombre_producto=?, descripcion=?, precio=?, stock_disponible=?, categoria=?, fecha_inicio=?, fecha_fin=?, imagen_url=? WHERE id=?");
    $stmt->bind_param("ssdisssi", $nombre, $descripcion, $precio, $stock, $categoria, $fecha_inicio, $fecha_fin, $imagen_url, $pid);

    if ($stmt->execute()) {
        $msg = '✅ Preventa actualizada correctamente.';
        $msg_type = 'ok';
        // Recargar datos
        $stmt2 = $conn->prepare("SELECT * FROM preventas WHERE id = ?");
        $stmt2->bind_param("i", $pid);
        $stmt2->execute();
        $preventa = $stmt2->get_result()->fetch_assoc();
        $stmt2->close();
        $id = $pid;
    } else {
        $msg = '❌ Error: ' . $stmt->error;
        $msg_type = 'err';
    }
    $stmt->close();
}

// Si no hay id, mostrar todas las preventas para editar
$todas = null;
if (!$preventa) {
    $todas = $conn->query("SELECT id, nombre_producto, precio, stock_disponible FROM preventas ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Editar Preventa — One Piece Preventas</title>
  <link rel="stylesheet" href="../css/estilos.css">
  <link rel="stylesheet" href="../css/animations.css">
</head>
<body class="dashboard-body">

<?php include '../navbar.php'; ?>
<?php
include '../breadcrumbs.php';
generarBreadcrumbs($breadcrumbs_editar_preventa);
?>

<div class="page-content">
  <h1 class="page-title">✏️ Editar Preventa</h1>

  <?php if ($preventa): ?>
    <div class="form-card">
      <?php if ($msg): ?>
        <div class="msg-box msg-<?php echo $msg_type; ?>"><?php echo htmlspecialchars($msg); ?></div>
      <?php endif; ?>

      <?= csrf_field() ?>
  <form method="POST" action="">
        <input type="hidden" name="id" value="<?php echo $preventa['id']; ?>">

        <div class="form-row">
          <div class="form-field">
            <label>Nombre del producto *</label>
            <input type="text" name="nombre_producto" required
                   value="<?php echo htmlspecialchars($preventa['nombre_producto']); ?>">
          </div>
          <div class="form-field">
            <label>Categoría</label>
            <select name="categoria">
              <?php foreach (['', 'Starters', 'Expansiones', 'accesorios', 'Figuras'] as $cat): ?>
                <option value="<?php echo $cat; ?>"
                  <?php echo ($preventa['categoria'] ?? '') === $cat ? 'selected' : ''; ?>>
                  <?php echo $cat ?: '— Seleccionar —'; ?>
                </option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="form-field">
          <label>Descripción</label>
          <textarea name="descripcion"><?php echo htmlspecialchars($preventa['descripcion'] ?? ''); ?></textarea>
        </div>

        <div class="form-row">
          <div class="form-field">
            <label>Precio (MXN) *</label>
            <input type="number" name="precio" min="0" step="0.01" required
                   value="<?php echo $preventa['precio']; ?>">
          </div>
          <div class="form-field">
            <label>Stock disponible *</label>
            <input type="number" name="stock_disponible" min="0" required
                   value="<?php echo $preventa['stock_disponible']; ?>">
          </div>
        </div>

        <div class="form-row">
          <div class="form-field">
            <label>Fecha inicio</label>
            <input type="date" name="fecha_inicio" value="<?php echo $preventa['fecha_inicio'] ?? ''; ?>">
          </div>
          <div class="form-field">
            <label>Fecha fin</label>
            <input type="date" name="fecha_fin" value="<?php echo $preventa['fecha_fin'] ?? ''; ?>">
          </div>
        </div>

        <div class="form-field">
          <label>URL de imagen</label>
          <input type="text" name="imagen_url" value="<?php echo htmlspecialchars($preventa['imagen_url'] ?? ''); ?>">
        </div>

        <button type="submit" class="btn-submit">💾 Actualizar Preventa</button>
        <a href="panel_admin.php"
           style="display:block;text-align:center;margin-top:12px;color:rgba(247,214,122,0.6);font-size:0.88rem;text-decoration:none;">
          ← Volver al panel
        </a>
      </form>
    </div>

  <?php else: ?>
    <!-- Selector de preventa -->
    <?php if ($todas && $todas->num_rows > 0): ?>
      <div class="tabla-container">
        <table class="tabla-preventas">
          <thead>
            <tr><th>ID</th><th>Producto</th><th>Precio</th><th>Stock</th><th>Acción</th></tr>
          </thead>
          <tbody>
            <?php while ($r = $todas->fetch_assoc()): ?>
            <tr>
              <td>#<?php echo $r['id']; ?></td>
              <td><?php echo htmlspecialchars($r['nombre_producto']); ?></td>
              <td>$<?php echo number_format($r['precio'], 2); ?></td>
              <td><?php echo $r['stock_disponible']; ?></td>
              <td><a href="editar_preventa.php?id=<?php echo $r['id']; ?>" class="btn-accion btn-editar">✏️ Editar</a></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p style="text-align:center;color:rgba(247,214,122,0.6);padding:40px;">No hay preventas para editar.</p>
    <?php endif; ?>
  <?php endif; ?>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="../js/cache.js"></script>
<script src="../js/api.js"></script>
<script src="../js/dom.js"></script>
<script src="../js/animations.js"></script>
<script src="../js/polling.js"></script>
<script src="../js/menu-scripts.js"></script>
</body>
</html>

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';    // Para incluir db.php (que está en code/)
include __DIR__ . '/../navbar.php'; // si navbar.php está en code/


if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? '';

if (!$id) {
    echo "ID no válido";
    exit;
}

$stmt = $conn->prepare("DELETE FROM preventas WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    header("Location: panel_admin.php");
    exit;
} else {
    echo "❌ Error al eliminar: " . $stmt->error;
}

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * admin/gestionar_usuarios.php — Gestión de Usuarios (Punto 6 — Práctica 1 Unidad 3)
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 *
 * Funcionalidades implementadas:
 *  - Listado completo de usuarios con búsqueda y filtro por rol
 *  - Cambio de rol (admin / editor / cliente)
 *  - Activar / desactivar MFA forzado
 *  - Ver sesiones activas por usuario
 *  - Banear usuarios (deshabilitar cuenta)
 *  - Eliminar usuario
 *  - Datos simulados integrados para demo cuando la BD no tenga datos
 */

session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';
include __DIR__ . '/../lang/translations.php';
requireRole('admin');

$userId   = (int)$_SESSION['usuario']['id'];
$usuario  = $_SESSION['usuario']['nombre_usuario'];
$userLang = $_SESSION['usuario']['language'] ?? 'es';
if (!isValidLang($userLang)) $userLang = 'es';
$t = getLang($userLang);

// Leer tema del usuario
$stmtPref = $conn->prepare("SELECT theme FROM clientes WHERE id = ?");
$stmtPref->bind_param('i', $userId);
$stmtPref->execute();
$stmtPref->bind_result($userTheme);
$stmtPref->fetch();
$stmtPref->close();
$userTheme = in_array($userTheme, ['dark','light']) ? $userTheme : 'dark';

$msg     = '';
$msgTipo = '';

// ── PROCESAR ACCIONES ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();
    $accion     = $_POST['accion']    ?? '';
    $targetId   = (int)($_POST['target_id'] ?? 0);

    // No permitir que el admin se modifique a sí mismo accidentalmente
    if ($targetId === $userId && in_array($accion, ['eliminar', 'banear'])) {
        $msg = '⚠️ No puedes realizar esta acción sobre tu propia cuenta.';
        $msgTipo = 'err';
    } elseif ($targetId > 0) {

        if ($accion === 'cambiar_rol') {
            $nuevoRol = in_array($_POST['nuevo_rol'] ?? '', ['admin','editor','cliente'])
                        ? $_POST['nuevo_rol'] : 'cliente';
            $stmt = $conn->prepare("UPDATE clientes SET rol = ? WHERE id = ?");
            $stmt->bind_param('si', $nuevoRol, $targetId);
            $stmt->execute();
            $stmt->close();
            $msg = "✅ Rol actualizado a '$nuevoRol'.";
            $msgTipo = 'ok';

        } elseif ($accion === 'toggle_mfa') {
            // Consultar estado actual
            $stmt = $conn->prepare("SELECT mfa_enabled FROM clientes WHERE id = ?");
            $stmt->bind_param('i', $targetId);
            $stmt->execute();
            $stmt->bind_result($mfaActual);
            $stmt->fetch();
            $stmt->close();
            $nuevoMfa = $mfaActual ? 0 : 1;
            $stmt2 = $conn->prepare("UPDATE clientes SET mfa_enabled = ? WHERE id = ?");
            $stmt2->bind_param('ii', $nuevoMfa, $targetId);
            $stmt2->execute();
            $stmt2->close();
            $msg = $nuevoMfa ? '✅ MFA activado para el usuario.' : '⚠️ MFA desactivado para el usuario.';
            $msgTipo = 'ok';

        } elseif ($accion === 'revocar_sesiones') {
            // Revocar TODAS las sesiones del usuario
            $stmt = $conn->prepare("UPDATE sessions SET revoked = 1 WHERE user_id = ?");
            $stmt->bind_param('i', $targetId);
            $stmt->execute();
            $afectadas = $stmt->affected_rows;
            $stmt->close();
            $msg = "✅ Se cerraron $afectadas sesión(es) del usuario.";
            $msgTipo = 'ok';

        } elseif ($accion === 'eliminar') {
            $stmt = $conn->prepare("DELETE FROM clientes WHERE id = ?");
            $stmt->bind_param('i', $targetId);
            $stmt->execute();
            $stmt->close();
            $msg = '✅ Usuario eliminado correctamente.';
            $msgTipo = 'ok';

        } elseif ($accion === 'banear') {
            // "Banear" = revocar todas sus sesiones + marcar como baneado (col opcional)
            // Si tu tabla no tiene col 'banned', se revocan sesiones y se puede agregar la col
            $conn->query("UPDATE sessions SET revoked = 1 WHERE user_id = $targetId");
            // Intentar actualizar col banned si existe
            @$conn->query("UPDATE clientes SET banned = 1 WHERE id = $targetId");
            $msg = '🚫 Usuario baneado: sesiones cerradas.';
            $msgTipo = 'ok';
        }
    }
}

// ── OBTENER USUARIOS REALES DE BD ────────────────────────────────────
$filtroRol   = $_GET['rol']    ?? '';
$busqueda    = trim($_GET['q'] ?? '');
$validRoles  = ['admin','editor','cliente'];

$sql = "SELECT c.id, c.nombre_usuario, c.email, c.rol, c.mfa_enabled,
               c.phone, c.theme, c.language, c.created_at,
               COUNT(s.id) AS sesiones_activas
        FROM clientes c
        LEFT JOIN sessions s ON s.user_id = c.id AND s.revoked = 0 AND s.expires_at > NOW()
        WHERE 1=1";
$params = [];
$types  = '';

if ($filtroRol && in_array($filtroRol, $validRoles)) {
    $sql    .= " AND c.rol = ?";
    $params[] = $filtroRol;
    $types   .= 's';
}
if ($busqueda) {
    $sql    .= " AND (c.nombre_usuario LIKE ? OR c.email LIKE ?)";
    $like    = "%$busqueda%";
    $params[] = $like;
    $params[] = $like;
    $types   .= 'ss';
}
$sql .= " GROUP BY c.id ORDER BY c.created_at DESC";

$stmt    = $conn->prepare($sql);
if ($types) $stmt->bind_param($types, ...$params);
$stmt->execute();
$usuarios = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// ── DATOS SIMULADOS si la BD está vacía o solo hay 1 usuario ─────────
// Útil para demostración en entornos de prueba
$simUsers = [];
if (count($usuarios) <= 1) {
    $simUsers = [
        ['id'=>'SIM-1', 'nombre_usuario'=>'monkey_luffy',  'email'=>'luffy@mugiwara.op',    'rol'=>'admin',   'mfa_enabled'=>1, 'sesiones_activas'=>2, 'created_at'=>'2026-01-01 00:00:00', 'phone'=>'+52 123 456 7890', 'simulado'=>true],
        ['id'=>'SIM-2', 'nombre_usuario'=>'roronoa_zoro',  'email'=>'zoro@mugiwara.op',      'rol'=>'editor',  'mfa_enabled'=>0, 'sesiones_activas'=>1, 'created_at'=>'2026-01-02 10:30:00', 'phone'=>'',                 'simulado'=>true],
        ['id'=>'SIM-3', 'nombre_usuario'=>'nami_navigator','email'=>'nami@mugiwara.op',      'rol'=>'cliente', 'mfa_enabled'=>1, 'sesiones_activas'=>3, 'created_at'=>'2026-01-05 14:15:00', 'phone'=>'+52 999 123 4567', 'simulado'=>true],
        ['id'=>'SIM-4', 'nombre_usuario'=>'usopp_god',     'email'=>'usopp@mugiwara.op',     'rol'=>'cliente', 'mfa_enabled'=>0, 'sesiones_activas'=>0, 'created_at'=>'2026-01-08 09:00:00', 'phone'=>'',                 'simulado'=>true],
        ['id'=>'SIM-5', 'nombre_usuario'=>'sanji_chef',    'email'=>'sanji@mugiwara.op',     'rol'=>'editor',  'mfa_enabled'=>1, 'sesiones_activas'=>1, 'created_at'=>'2026-01-10 18:45:00', 'phone'=>'+52 777 888 9999', 'simulado'=>true],
        ['id'=>'SIM-6', 'nombre_usuario'=>'nico_robin',    'email'=>'robin@mugiwara.op',     'rol'=>'cliente', 'mfa_enabled'=>0, 'sesiones_activas'=>2, 'created_at'=>'2026-01-12 11:00:00', 'phone'=>'',                 'simulado'=>true],
        ['id'=>'SIM-7', 'nombre_usuario'=>'chopper_doc',   'email'=>'chopper@mugiwara.op',   'rol'=>'cliente', 'mfa_enabled'=>1, 'sesiones_activas'=>0, 'created_at'=>'2026-01-15 08:20:00', 'phone'=>'+52 444 555 6666', 'simulado'=>true],
        ['id'=>'SIM-8', 'nombre_usuario'=>'franky_cola',   'email'=>'franky@mugiwara.op',    'rol'=>'editor',  'mfa_enabled'=>0, 'sesiones_activas'=>1, 'created_at'=>'2026-01-18 16:30:00', 'phone'=>'',                 'simulado'=>true],
    ];
}

$allUsers   = array_merge($usuarios, $simUsers);
$totalUsers = count($allUsers);

// Roles para el badge de color
$rolColors = ['admin'=>'#e74c3c','editor'=>'#f39c12','cliente'=>'#2ecc71'];
$rolLabels = ['admin'=>'Admin','editor'=>'Editor','cliente'=>'Cliente'];

// Aplicar tema light si corresponde
$themeVars = '';
if ($userTheme === 'light') {
    $themeVars = '
    <style>
      :root {
        --bg-main:#f5f0e8;--bg-card:#fff;--text-main:#1a1008;--text-muted:#5a4030;
        --gold:#8b5e1a;--gold-bright:#b07a20;--border-color:rgba(139,94,26,0.25);
      }
      body { background:var(--bg-main) !important; color:var(--text-main) !important; }
      .navbar-mejorado { background:#fff !important; border-bottom:2px solid #b07a20 !important; }
      .nav-link, .logo-text { color:#1a1008 !important; }
      .nav-link:hover { background:rgba(139,94,26,0.1) !important; }
      .submenu { background:#fff !important; border-color:#b07a20 !important; }
      .submenu li a { color:#1a1008 !important; }
      .page-content { background:transparent; }
      .usr-card { background:#fff !important; border-color:rgba(139,94,26,0.2) !important; color:#1a1008 !important; }
      .usr-card td { color:#1a1008 !important; border-color:rgba(139,94,26,0.1) !important; }
      .page-title, .usr-card th { color:var(--gold) !important; }
      .stat-pill { background:rgba(139,94,26,0.1) !important; color:#1a1008 !important; }
      .btn-action { opacity:0.9; }
      .table-filters input, .table-filters select { background:#fff !important; color:#1a1008 !important; border-color:#b07a20 !important; }
      .sim-badge { background:rgba(139,94,26,0.15) !important; color:#8b5e1a !important; }
    </style>';
}
?>
<!DOCTYPE html>
<html lang="<?= $userLang ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($t['adm_usuarios_title']) ?></title>
  <link rel="stylesheet" href="../css/estilos.css">
  <link rel="stylesheet" href="../css/animations.css">
  <?= $themeVars ?>
  <style>
    .usr-card {
      background: rgba(30,18,10,0.85);
      border: 1px solid rgba(247,214,122,0.2);
      border-radius: 14px;
      overflow: hidden;
      margin-top: 20px;
    }
    .usr-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.88rem;
    }
    .usr-table th {
      background: rgba(66,47,26,0.9);
      color: var(--gold-bright);
      padding: 12px 14px;
      text-align: left;
      font-size: 0.82rem;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      border-bottom: 2px solid rgba(247,214,122,0.25);
    }
    .usr-table td {
      padding: 11px 14px;
      border-bottom: 1px solid rgba(247,214,122,0.08);
      color: rgba(247,214,122,0.85);
      vertical-align: middle;
    }
    .usr-table tr:last-child td { border-bottom: none; }
    .usr-table tr:hover td { background: rgba(247,214,122,0.04); }
    .rol-badge {
      display: inline-block;
      padding: 3px 10px;
      border-radius: 20px;
      font-size: 0.78rem;
      font-weight: bold;
      color: #fff;
    }
    .mfa-dot {
      display: inline-block;
      width: 10px; height: 10px;
      border-radius: 50%;
      margin-right: 5px;
    }
    .btn-action {
      display: inline-block;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 0.76rem;
      cursor: pointer;
      border: 1px solid;
      background: transparent;
      margin: 2px;
      color: inherit;
      transition: all 0.2s;
    }
    .btn-action:hover { opacity: 0.85; transform: translateY(-1px); }
    .btn-rol   { border-color: rgba(247,214,122,0.4); color: var(--gold); }
    .btn-mfa   { border-color: rgba(52,152,219,0.5);  color: #74b9ff; }
    .btn-ses   { border-color: rgba(155,89,182,0.5);  color: #a29bfe; }
    .btn-ban   { border-color: rgba(230,126,34,0.5);  color: #fdcb6e; }
    .btn-del   { border-color: rgba(231,76,60,0.5);   color: #ff7675; }
    .table-filters {
      display: flex;
      gap: 12px;
      align-items: center;
      flex-wrap: wrap;
      margin-bottom: 16px;
    }
    .table-filters input,
    .table-filters select {
      background: rgba(66,47,26,0.7);
      border: 1px solid rgba(247,214,122,0.3);
      color: var(--gold);
      padding: 8px 14px;
      border-radius: 8px;
      font-size: 0.88rem;
      outline: none;
    }
    .table-filters input::placeholder { color: rgba(247,214,122,0.4); }
    .stat-pill {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      background: rgba(247,214,122,0.1);
      border: 1px solid rgba(247,214,122,0.2);
      border-radius: 20px;
      padding: 5px 14px;
      font-size: 0.85rem;
      color: var(--gold);
    }
    .sim-badge {
      font-size: 0.68rem;
      background: rgba(247,214,122,0.12);
      color: rgba(247,214,122,0.6);
      border-radius: 4px;
      padding: 1px 6px;
      margin-left: 4px;
    }
    .modal-overlay {
      display: none;
      position: fixed; inset: 0;
      background: rgba(0,0,0,0.7);
      z-index: 9000;
      align-items: center;
      justify-content: center;
    }
    .modal-overlay.active { display: flex; }
    .modal-box {
      background: #2c1f14;
      border: 2px solid var(--gold);
      border-radius: 14px;
      padding: 28px 32px;
      max-width: 420px;
      width: 90%;
      animation: fadeInUp 0.3s ease;
    }
    .modal-box h3 { color: var(--gold-bright); margin-bottom: 12px; }
    .modal-box p  { color: rgba(247,214,122,0.7); font-size:0.9rem; margin-bottom:18px; }
    .modal-actions { display:flex; gap:10px; justify-content:flex-end; }
    .modal-confirm { background:rgba(231,76,60,0.3); border:1px solid rgba(231,76,60,0.6); color:#ff7675; }
    .modal-cancel  { background:transparent; border:1px solid rgba(247,214,122,0.3); color:var(--gold); }
    @media(max-width:768px){
      .usr-table { font-size:0.78rem; }
      .usr-table th, .usr-table td { padding:8px 8px; }
      .hide-mobile { display:none; }
    }
  </style>
</head>
<body class="dashboard-body<?= $userTheme === 'light' ? ' theme-light' : '' ?>">

<?php include '../navbar.php'; ?>
<?php
include '../breadcrumbs.php';
$bc = [
    'Inicio'           => '/dashboard.php',
    'Panel Admin'      => '/admin/panel_admin.php',
    $t['adm_usuarios_h1'] => '',
];
generarBreadcrumbs($bc);
?>

<div class="page-content">

  <h1 class="page-title"><?= htmlspecialchars($t['adm_usuarios_h1']) ?></h1>

  <?php if ($msg): ?>
    <div class="msg-box msg-<?= $msgTipo ?>" style="margin-bottom:16px;"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <!-- Estadísticas rápidas -->
  <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px;">
    <?php
      $cntAdmin   = count(array_filter($allUsers, fn($u)=>$u['rol']==='admin'));
      $cntEditor  = count(array_filter($allUsers, fn($u)=>$u['rol']==='editor'));
      $cntCliente = count(array_filter($allUsers, fn($u)=>$u['rol']==='cliente'));
      $cntMfa     = count(array_filter($allUsers, fn($u)=>$u['mfa_enabled']));
    ?>
    <div class="stat-pill">👥 <?= htmlspecialchars($t['adm_usr_total']) ?> <strong><?= $totalUsers ?></strong></div>
    <div class="stat-pill">⚙️ Admins: <strong><?= $cntAdmin ?></strong></div>
    <div class="stat-pill">✏️ Editores: <strong><?= $cntEditor ?></strong></div>
    <div class="stat-pill">👤 Clientes: <strong><?= $cntCliente ?></strong></div>
    <div class="stat-pill">🔐 MFA activo: <strong><?= $cntMfa ?></strong></div>
    <?php if (!empty($simUsers)): ?>
    <div class="stat-pill" style="border-color:rgba(247,200,80,0.3);background:rgba(247,200,80,0.08);">
      🧪 Datos simulados incluidos
    </div>
    <?php endif; ?>
  </div>

  <!-- Filtros de búsqueda -->
  <form method="GET" action="">
    <div class="table-filters">
      <input type="text" name="q" placeholder="<?= htmlspecialchars($t['adm_usr_buscar']) ?>"
             value="<?= htmlspecialchars($busqueda) ?>" style="flex:1;min-width:180px;">
      <select name="rol">
        <option value=""><?= htmlspecialchars($t['adm_usr_todos']) ?></option>
        <option value="admin"   <?= $filtroRol==='admin'   ? 'selected':'' ?>>Admin</option>
        <option value="editor"  <?= $filtroRol==='editor'  ? 'selected':'' ?>>Editor</option>
        <option value="cliente" <?= $filtroRol==='cliente' ? 'selected':'' ?>>Cliente</option>
      </select>
      <button type="submit" class="btn-submit" style="padding:8px 20px;font-size:0.88rem;">
        🔍 <?= htmlspecialchars($t['nav_buscar_btn']) ?>
      </button>
      <?php if ($busqueda || $filtroRol): ?>
      <a href="gestionar_usuarios.php" class="btn-action btn-rol" style="padding:8px 14px;">✖ Limpiar</a>
      <?php endif; ?>
    </div>
  </form>

  <!-- Tabla de usuarios -->
  <div class="usr-card">
    <table class="usr-table">
      <thead>
        <tr>
          <th><?= htmlspecialchars($t['adm_usr_id']) ?></th>
          <th><?= htmlspecialchars($t['adm_usr_nombre']) ?></th>
          <th class="hide-mobile"><?= htmlspecialchars($t['adm_usr_email']) ?></th>
          <th><?= htmlspecialchars($t['adm_usr_rol']) ?></th>
          <th><?= htmlspecialchars($t['adm_usr_mfa']) ?></th>
          <th class="hide-mobile"><?= htmlspecialchars($t['adm_usr_sesiones']) ?></th>
          <th class="hide-mobile"><?= htmlspecialchars($t['adm_usr_creado']) ?></th>
          <th><?= htmlspecialchars($t['adm_usr_acciones']) ?></th>
        </tr>
      </thead>
      <tbody>
        <?php if (empty($allUsers)): ?>
        <tr>
          <td colspan="8" style="text-align:center;padding:24px;color:rgba(247,214,122,0.4);">
            No se encontraron usuarios con esos criterios.
          </td>
        </tr>
        <?php endif; ?>
        <?php foreach ($allUsers as $usr):
          $isSimulado = !empty($usr['simulado']);
          $rolColor   = $rolColors[$usr['rol']] ?? '#aaa';
          $isCurrentUser = (!$isSimulado && (int)$usr['id'] === $userId);
          $sesiones   = (int)($usr['sesiones_activas'] ?? 0);
          $creado     = $usr['created_at'] ? date('d/m/Y', strtotime($usr['created_at'])) : '—';
        ?>
        <tr id="row-usr-<?= $usr['id'] ?>">
          <!-- ID -->
          <td style="font-size:0.75rem;color:rgba(247,214,122,0.45);">
            <?= htmlspecialchars($usr['id']) ?>
          </td>

          <!-- Nombre -->
          <td>
            <strong style="color:var(--gold-bright);"><?= htmlspecialchars($usr['nombre_usuario']) ?></strong>
            <?php if ($isCurrentUser): ?><span class="sim-badge">tú</span><?php endif; ?>
            <?php if ($isSimulado):    ?><span class="sim-badge">🧪 demo</span><?php endif; ?>
          </td>

          <!-- Email -->
          <td class="hide-mobile" style="font-size:0.82rem;color:rgba(247,214,122,0.65);">
            <?= htmlspecialchars($usr['email'] ?? '—') ?>
          </td>

          <!-- Rol -->
          <td>
            <span class="rol-badge" style="background:<?= $rolColor ?>;">
              <?= htmlspecialchars($rolLabels[$usr['rol']] ?? ucfirst($usr['rol'])) ?>
            </span>
          </td>

          <!-- MFA -->
          <td>
            <?php if ($usr['mfa_enabled']): ?>
              <span class="mfa-dot" style="background:#6ee89a;"></span>
              <?= htmlspecialchars($t['adm_usr_activo']) ?>
            <?php else: ?>
              <span class="mfa-dot" style="background:#e74c3c;"></span>
              <?= htmlspecialchars($t['adm_usr_inactivo']) ?>
            <?php endif; ?>
          </td>

          <!-- Sesiones -->
          <td class="hide-mobile">
            <span style="color:<?= $sesiones > 0 ? '#6ee89a' : 'rgba(247,214,122,0.35)' ?>;">
              <?= $sesiones ?> activa<?= $sesiones !== 1 ? 's' : '' ?>
            </span>
          </td>

          <!-- Creado -->
          <td class="hide-mobile" style="font-size:0.8rem;color:rgba(247,214,122,0.5);">
            <?= $creado ?>
          </td>

          <!-- Acciones -->
          <td>
            <?php if (!$isSimulado): ?>
              <!-- Cambiar rol -->
              <form method="POST" style="display:inline;" onsubmit="return confirm('¿Cambiar rol de este usuario?');">
                <?= csrf_field() ?>
                <input type="hidden" name="accion"    value="cambiar_rol">
                <input type="hidden" name="target_id" value="<?= $usr['id'] ?>">
                <select name="nuevo_rol" class="btn-action btn-rol"
                        style="padding:4px 6px;cursor:pointer;"
                        onchange="this.closest('form').submit()">
                  <option value="">🔄 Rol</option>
                  <option value="admin"   <?= $usr['rol']==='admin'   ? 'selected':'' ?>>Admin</option>
                  <option value="editor"  <?= $usr['rol']==='editor'  ? 'selected':'' ?>>Editor</option>
                  <option value="cliente" <?= $usr['rol']==='cliente' ? 'selected':'' ?>>Cliente</option>
                </select>
              </form>

              <!-- Toggle MFA -->
              <form method="POST" style="display:inline;">
                <?= csrf_field() ?>
                <input type="hidden" name="accion"    value="toggle_mfa">
                <input type="hidden" name="target_id" value="<?= $usr['id'] ?>">
                <button type="submit" class="btn-action btn-mfa" title="<?= htmlspecialchars($t['adm_usr_forzar_mfa']) ?>">
                  🔐
                </button>
              </form>

              <!-- Revocar sesiones -->
              <form method="POST" style="display:inline;" onsubmit="return confirm('¿Cerrar todas las sesiones de este usuario?');">
                <?= csrf_field() ?>
                <input type="hidden" name="accion"    value="revocar_sesiones">
                <input type="hidden" name="target_id" value="<?= $usr['id'] ?>">
                <button type="submit" class="btn-action btn-ses" title="<?= htmlspecialchars($t['adm_usr_ver_ses']) ?>">
                  🔌
                </button>
              </form>

              <?php if (!$isCurrentUser): ?>
              <!-- Banear -->
              <button type="button" class="btn-action btn-ban"
                      onclick="abrirModal('ban','<?= $usr['id'] ?>','<?= htmlspecialchars($usr['nombre_usuario']) ?>')"
                      title="<?= htmlspecialchars($t['adm_usr_banear']) ?>">
                🚫
              </button>

              <!-- Eliminar -->
              <button type="button" class="btn-action btn-del"
                      onclick="abrirModal('del','<?= $usr['id'] ?>','<?= htmlspecialchars($usr['nombre_usuario']) ?>')"
                      title="<?= htmlspecialchars($t['adm_usr_eliminar']) ?>">
                🗑️
              </button>
              <?php endif; ?>

            <?php else: ?>
              <!-- Usuario simulado: solo mostrar botones visuales deshabilitados -->
              <span style="font-size:0.75rem;color:rgba(247,214,122,0.3);font-style:italic;">
                🧪 Demo — solo visual
              </span>
            <?php endif; ?>
          </td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>

  <!-- Nota sobre datos simulados -->
  <?php if (!empty($simUsers)): ?>
  <div style="margin-top:14px;padding:12px 16px;background:rgba(247,214,122,0.06);
              border:1px solid rgba(247,214,122,0.15);border-radius:8px;font-size:0.82rem;
              color:rgba(247,214,122,0.55);">
    🧪 <strong>Datos de demostración:</strong> Los usuarios marcados con <em>"demo"</em> son simulados
    para mostrar la interfaz. Las acciones de gestión solo funcionan con usuarios reales de la BD.
    Agrega usuarios a través del registro para verlos aquí.
  </div>
  <?php endif; ?>

</div><!-- /page-content -->

<!-- Modal de confirmación banear/eliminar -->
<div class="modal-overlay" id="modalConfirm">
  <div class="modal-box">
    <h3 id="modalTitle">⚠️ Confirmar acción</h3>
    <p id="modalText">¿Estás seguro?</p>
    <div class="modal-actions">
      <form method="POST" id="modalForm">
        <?= csrf_field() ?>
        <input type="hidden" name="accion"    id="modalAccion"   value="">
        <input type="hidden" name="target_id" id="modalTargetId" value="">
        <button type="button" class="btn-action modal-cancel"  onclick="cerrarModal()">Cancelar</button>
        <button type="submit" class="btn-action modal-confirm" id="modalConfirmBtn">Confirmar</button>
      </form>
    </div>
  </div>
</div>

<footer class="site-footer">
  <p><?= htmlspecialchars($t['footer_copy']) ?></p>
</footer>

<script src="../js/cache.js"></script>
<script src="../js/api.js"></script>
<script src="../js/dom.js"></script>
<script src="../js/animations.js"></script>
<script src="../js/menu-scripts.js"></script>
<script>
function abrirModal(tipo, id, nombre) {
  const modal    = document.getElementById('modalConfirm');
  const title    = document.getElementById('modalTitle');
  const text     = document.getElementById('modalText');
  const accion   = document.getElementById('modalAccion');
  const targetId = document.getElementById('modalTargetId');
  const btn      = document.getElementById('modalConfirmBtn');

  if (tipo === 'ban') {
    title.textContent  = '🚫 Banear usuario';
    text.textContent   = `¿Banear a "${nombre}"? Se cerrarán todas sus sesiones.`;
    accion.value       = 'banear';
    btn.textContent    = '🚫 Banear';
    btn.style.background = 'rgba(230,126,34,0.3)';
    btn.style.borderColor = 'rgba(230,126,34,0.6)';
    btn.style.color    = '#fdcb6e';
  } else {
    title.textContent  = '🗑️ Eliminar usuario';
    text.textContent   = `¿Eliminar a "${nombre}" permanentemente? Esta acción no se puede deshacer.`;
    accion.value       = 'eliminar';
    btn.textContent    = '🗑️ Eliminar';
    btn.style.background = 'rgba(231,76,60,0.3)';
    btn.style.borderColor = 'rgba(231,76,60,0.6)';
    btn.style.color    = '#ff7675';
  }

  targetId.value = id;
  modal.classList.add('active');
}

function cerrarModal() {
  document.getElementById('modalConfirm').classList.remove('active');
}

document.getElementById('modalConfirm').addEventListener('click', function(e) {
  if (e.target === this) cerrarModal();
});
</script>
</body>
</html>

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $descripcion = $_POST['descripcion'];
    $precio = $_POST['precio'];
    $precio_compra = $_POST['precio_compra'];
    $stock = $_POST['stock'];
    $fecha_inicio = $_POST['fecha_inicio'];
    $fecha_fin = $_POST['fecha_fin'];
    $estado = $_POST['estado'];

    // Obtener datos actuales para conservar rutas previas de imagen/comprobante
    $stmt = $conn->prepare("SELECT imagen_url, imagen_comprobante FROM preventas WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $preventa = $result->fetch_assoc();

    $imagen_url = $preventa['imagen_url'];
    $imagen_comprobante = $preventa['imagen_comprobante'];

    // Subir imagen principal (si se cargó una nueva)
    if (!empty($_FILES['imagen']['name'])) {
        $nombreImagen = basename($_FILES['imagen']['name']);
        $rutaDestino = __DIR__ . "/../uploads/" . $nombreImagen;
        $rutaDB = "/uploads/" . $nombreImagen;
        if (!is_dir(__DIR__ . "/../uploads")) mkdir(__DIR__ . "/../uploads", 0777, true);
        move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaDestino);
        $imagen_url = $rutaDB;
    }

    // Subir comprobante (si se cargó uno nuevo)
    if (!empty($_FILES['imagen_comprobante']['name'])) {
        $nombreComprobante = basename($_FILES['imagen_comprobante']['name']);
        $rutaComprobante = __DIR__ . "/../uploads/comprobantes/" . $nombreComprobante;
        $rutaDBComprobante = "/uploads/comprobantes/" . $nombreComprobante;
        if (!is_dir(__DIR__ . "/../uploads/comprobantes")) mkdir(__DIR__ . "/../uploads/comprobantes", 0777, true);
        move_uploaded_file($_FILES['imagen_comprobante']['tmp_name'], $rutaComprobante);
        $imagen_comprobante = $rutaDBComprobante;
    }

    // Actualizar preventa
    $sql = "UPDATE preventas SET 
        nombre_producto=?, descripcion=?, precio=?, precio_compra=?, stock_disponible=?, 
        imagen_url=?, imagen_comprobante=?, estado=?, fecha_inicio=?, fecha_fin=?, fecha_actualizacion=CURDATE()
        WHERE id=?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssddisssssi",
        $nombre,
        $descripcion,
        $precio,
        $precio_compra,
        $stock,
        $imagen_url,
        $imagen_comprobante,
        $estado,
        $fecha_inicio,
        $fecha_fin,
        $id
    );

    if ($stmt->execute()) {
        header("Location: panel_admin.php?msg=success");
        exit;
    } else {
        header("Location: panel_admin.php?msg=error&detalle=" . urlencode($stmt->error));
        exit;
    }
}
?>

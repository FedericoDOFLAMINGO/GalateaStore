<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */

session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';
requireRole('admin');

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$preventa = null;

if ($id > 0) {
    $stmt = $conn->prepare("SELECT * FROM preventas WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $preventa = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Pedidos de esta preventa
$pedidos = null;
if ($preventa) {
    $stmt2 = $conn->prepare("
        SELECT p.id, c.nombre_usuario, p.cantidad, p.fecha_pedido, COALESCE(p.estado,'pendiente') as estado
        FROM pedidos p
        JOIN clientes c ON p.cliente_id = c.id
        WHERE p.preventa_id = ?
        ORDER BY p.fecha_pedido DESC
    ");
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $pedidos = $stmt2->get_result();
    $stmt2->close();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inspeccionar Preventa — One Piece Preventas</title>
  <link rel="stylesheet" href="../css/estilos.css">
  <link rel="stylesheet" href="../css/animations.css">
</head>
<body class="dashboard-body">

<?php include '../navbar.php'; ?>
<?php
include '../breadcrumbs.php';
$bc = [
  'Inicio' => '/dashboard.php',
  'Admin'  => '/admin/panel_admin.php',
  'Inspeccionar' => ''
];
generarBreadcrumbs($bc);
?>

<div class="page-content">
  <h1 class="page-title">🔍 Detalle de Preventa</h1>

  <?php if ($preventa): ?>
    <div style="display:grid;grid-template-columns:1fr 2fr;gap:24px;margin-bottom:32px;background:rgba(61,43,31,0.85);border:1px solid rgba(247,214,122,0.3);border-radius:14px;padding:24px;">
      <div style="text-align:center;">
        <img src="<?php echo htmlspecialchars($preventa['imagen_url'] ?? ''); ?>"
             alt="<?php echo htmlspecialchars($preventa['nombre_producto']); ?>"
             style="max-width:200px;border-radius:12px;border:2px solid var(--gold);"
             onerror="this.src='../img/op13.jpeg'">
      </div>
      <div>
        <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);margin-bottom:16px;">
          <?php echo htmlspecialchars($preventa['nombre_producto']); ?>
        </h2>
        <div class="info-row"><strong>Descripción:</strong> <?php echo htmlspecialchars($preventa['descripcion'] ?? '—'); ?></div>
        <div class="info-row"><strong>Categoría:</strong> <?php echo htmlspecialchars($preventa['categoria'] ?? '—'); ?></div>
        <div class="info-row"><strong>Precio:</strong> <span style="color:var(--green-ok);font-weight:700;">$<?php echo number_format($preventa['precio'], 2); ?></span></div>
        <div class="info-row"><strong>Stock:</strong> <?php echo $preventa['stock_disponible']; ?> unidades</div>
        <div class="info-row"><strong>Fecha inicio:</strong> <?php echo htmlspecialchars($preventa['fecha_inicio'] ?? '—'); ?></div>
        <div class="info-row"><strong>Fecha fin:</strong> <?php echo htmlspecialchars($preventa['fecha_fin'] ?? '—'); ?></div>
        <div style="margin-top:16px;display:flex;gap:10px;">
          <a href="editar_preventa.php?id=<?php echo $preventa['id']; ?>" class="btn-accion btn-editar">✏️ Editar</a>
          <a href="cambiar_estado.php?id=<?php echo $preventa['id']; ?>" class="btn-accion btn-estado-on">🔄 Cambiar Estado</a>
          <a href="eliminar_preventa.php?id=<?php echo $preventa['id']; ?>"
             class="btn-accion btn-eliminar"
             onclick="return confirm('¿Eliminar esta preventa?')">🗑️ Eliminar</a>
        </div>
      </div>
    </div>

    <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);margin-bottom:16px;">📋 Pedidos de esta Preventa</h2>

    <?php if ($pedidos && $pedidos->num_rows > 0): ?>
      <div class="tabla-container">
        <table class="tabla-preventas">
          <thead>
            <tr><th>#</th><th>Cliente</th><th>Cantidad</th><th>Fecha</th><th>Estado</th></tr>
          </thead>
          <tbody>
            <?php while ($p = $pedidos->fetch_assoc()):
              $badgeClass = match($p['estado']) {
                'confirmado' => 'badge-confirmado',
                'cancelado'  => 'badge-cancelado',
                default      => 'badge-pendiente'
              };
            ?>
            <tr>
              <td>#<?php echo $p['id']; ?></td>
              <td><?php echo htmlspecialchars($p['nombre_usuario']); ?></td>
              <td><?php echo $p['cantidad']; ?></td>
              <td style="font-size:0.85rem;"><?php echo $p['fecha_pedido']; ?></td>
              <td><span class="badge <?php echo $badgeClass; ?>"><?php echo ucfirst($p['estado']); ?></span></td>
            </tr>
            <?php endwhile; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <p style="color:rgba(247,214,122,0.5);text-align:center;padding:30px;">Sin pedidos registrados para esta preventa.</p>
    <?php endif; ?>

  <?php else: ?>
    <div style="text-align:center;padding:50px;">
      <p style="color:rgba(247,214,122,0.6);">Preventa no encontrada.</p>
      <a href="panel_admin.php" class="btn-accion btn-inspeccionar" style="display:inline-block;margin-top:16px;">← Volver al panel</a>
    </div>
  <?php endif; ?>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="../js/cache.js"></script>
<script src="../js/api.js"></script>
<script src="../js/dom.js"></script>
<script src="../js/animations.js"></script>
<script src="../js/polling.js"></script>
<script src="../js/menu-scripts.js"></script>
</body>
</html>

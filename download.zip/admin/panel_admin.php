<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */

session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';
requireRole('admin');

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$sql    = "SELECT * FROM preventas ORDER BY id DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panel Admin — One Piece Preventas</title>
  <link rel="stylesheet" href="../css/estilos.css">
  <link rel="stylesheet" href="../css/animations.css">
</head>
<body class="dashboard-body">

<?php include '../navbar.php'; ?>
<?php
include '../breadcrumbs.php';
generarBreadcrumbs($breadcrumbs_panel_admin);
?>

<div class="page-content">
  <h1 class="page-title">⚙️ Panel de Administración</h1>

  <div class="quick-actions" style="margin-bottom:28px;">
    <a href="agregar_preventa.php" class="quick-card">
      <img src="../img/zoro.png" alt="">
      <span>➕ Agregar Preventa</span>
    </a>
    <a href="../preventas_activas.php" class="quick-card">
      <img src="../img/nami.png" alt="">
      <span>👁️ Ver Activas</span>
    </a>
    <a href="gestionar_usuarios.php" class="quick-card">
      <img src="../img/robin.png" alt="">
      <span>👥 Gestionar Usuarios</span>
    </a>
    <a href="../ayuda.php" class="quick-card">
      <img src="../img/chooper.png" alt="">
      <span>❓ Ayuda</span>
    </a>
  </div>

  <!-- ═══ ESTADÍSTICAS EN TIEMPO REAL ═══ -->
  <div class="stats-grid" style="margin-bottom:28px;">
    <div class="stat-card">
      <span class="stat-icon">📦</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-activas">—</div>
        <div class="stat-label">Preventas Activas</div>
      </div>
    </div>
    <div class="stat-card">
      <span class="stat-icon">⏳</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-pendientes">—</div>
        <div class="stat-label">Pedidos Pendientes <span class="badge-notify" id="badge-pedidos-pendientes" style="display:none;"></span></div>
      </div>
    </div>
    <div class="stat-card">
      <span class="stat-icon">📅</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-hoy">—</div>
        <div class="stat-label">Pedidos Hoy</div>
      </div>
    </div>
    <div class="stat-card">
      <span class="stat-icon">👥</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-clientes">—</div>
        <div class="stat-label">Total Clientes</div>
      </div>
    </div>
  </div>

  <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);margin-bottom:16px;">
    📋 Todas las Preventas
  </h2>

  <?php if ($result && $result->num_rows > 0): ?>
    <div class="tabla-container">
      <table class="tabla-preventas">
        <thead>
          <tr>
            <th>ID</th>
            <th>Imagen</th>
            <th>Producto</th>
            <th>Precio</th>
            <th>Stock</th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($row = $result->fetch_assoc()):
            $activo = isset($row['activo']) ? $row['activo'] : ($row['stock_disponible'] > 0 ? 1 : 0);
          ?>
          <tr>
            <td>#<?php echo $row['id']; ?></td>
            <td>
              <img loading="lazy" src="<?php echo htmlspecialchars($row['imagen_url']); ?>"
                   alt="<?php echo htmlspecialchars($row['nombre_producto']); ?>"
                   style="max-width:60px;border-radius:8px;"
                   onerror="this.src='../img/op13.jpeg'">
            </td>
            <td>
              <strong><?php echo htmlspecialchars($row['nombre_producto']); ?></strong><br>
              <small style="color:rgba(247,214,122,0.55);font-size:0.8rem;">
                <?php echo htmlspecialchars($row['descripcion'] ?? ''); ?>
              </small>
            </td>
            <td style="color:var(--green-ok);font-weight:700;">$<?php echo number_format($row['precio'], 2); ?></td>
            <td><?php echo $row['stock_disponible']; ?></td>
            <td>
              <span class="badge <?php echo $activo ? 'badge-active' : 'badge-inactive'; ?>">
                <?php echo $activo ? 'Activo' : 'Inactivo'; ?>
              </span>
            </td>
            <td>
              <a href="inspeccionar_preventa.php?id=<?php echo $row['id']; ?>" class="btn-accion btn-inspeccionar">🔍</a>
              <a href="editar_preventa.php?id=<?php echo $row['id']; ?>" class="btn-accion btn-editar">✏️</a>
              <a href="cambiar_estado.php?id=<?php echo $row['id']; ?>"
                 class="btn-accion <?php echo $activo ? 'btn-estado-on' : 'btn-estado-off'; ?>">
                <?php echo $activo ? '🟢' : '⚫'; ?>
              </a>
              <a href="eliminar_preventa.php?id=<?php echo $row['id']; ?>"
                 class="btn-accion btn-eliminar"
                 onclick="return confirm('¿Eliminar esta preventa?')">🗑️</a>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  <?php else: ?>
    <div style="text-align:center;padding:50px;">
      <p style="color:rgba(247,214,122,0.6);">No hay preventas registradas aún.</p>
      <a href="agregar_preventa.php"
         style="display:inline-block;margin-top:16px;padding:12px 24px;background:var(--gold-bright);color:var(--dark-brown);border-radius:10px;text-decoration:none;font-weight:700;">
        ➕ Agregar primera preventa
      </a>
    </div>
  <?php endif; ?>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="../js/cache.js"></script>
<script src="../js/api.js"></script>
<script src="../js/dom.js"></script>
<script src="../js/animations.js"></script>
<script src="../js/polling.js"></script>
<script src="../js/menu-scripts.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
  // Cargar estadísticas con Promise.allSettled
  loadStats();

  // Polling de pedidos pendientes
  if (window.OnePiecePolling) {
    OnePiecePolling.startPedidosPolling('tabla-pedidos-body', 'badge-pedidos-pendientes');
  }

  async function loadStats() {
    console.time('[Admin] Cargar estadísticas');
    const [statsResult] = await Promise.allSettled([
      fetch('../api_pedidos.php?action=stats').then(r => r.json())
    ]);
    console.timeEnd('[Admin] Cargar estadísticas');

    if (statsResult.status === 'fulfilled') {
      const s = statsResult.value;
      setNum('stat-num-activas',    s.preventas_activas  || 0);
      setNum('stat-num-pendientes', s.pedidos_pendientes || 0);
      setNum('stat-num-hoy',        s.pedidos_hoy        || 0);
      setNum('stat-num-clientes',   s.total_clientes     || 0);
      const badge = document.getElementById('badge-pedidos-pendientes');
      if (badge && s.pedidos_pendientes > 0) {
        badge.textContent = s.pedidos_pendientes;
        badge.style.display = 'inline-flex';
      }
    }
  }

  function setNum(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = val;
  }
});
</script>
</body>
</html>

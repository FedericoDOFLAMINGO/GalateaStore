<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * api_pedidos.php — Endpoint JSON para polling en tiempo real
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Acciones:
 *   ?action=nuevos&since=TIMESTAMP  → pedidos nuevos (admin)
 *   ?action=estado&id=ID            → estado de un pedido (cliente)
 *   ?action=stats                   → estadísticas del dashboard
 */

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

$action = $_GET['action'] ?? '';
$rol    = $_SESSION['usuario']['rol'];

// ────────────────────────────────────────────────────────
// ACCIÓN: nuevos pedidos para el admin
// ────────────────────────────────────────────────────────
if ($action === 'nuevos') {
    if ($rol !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Acceso denegado']);
        exit;
    }

    // Obtener pedidos pendientes recientes (últimos 5 minutos)
    $sql = "
        SELECT p.id, p.cantidad, p.fecha_pedido, p.estado,
               cl.nombre_usuario,
               pr.nombre_producto, pr.imagen_url
        FROM pedidos p
        JOIN clientes cl  ON p.cliente_id  = cl.id
        JOIN preventas pr ON p.preventa_id = pr.id
        WHERE p.estado = 'pendiente'
          AND p.fecha_pedido >= DATE_SUB(NOW(), INTERVAL 5 MINUTE)
        ORDER BY p.fecha_pedido DESC
        LIMIT 20
    ";

    $result = $conn->query($sql);
    $nuevos = [];

    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $badgeClass = 'badge-pendiente';
            $badgeLabel = '⏳ Pendiente';
            $imgSrc = !empty($row['imagen_url']) ? htmlspecialchars($row['imagen_url']) : 'img/op13.jpeg';

            // Generar el HTML de la fila para inserción dinámica
            $rowHTML = "
                <td>#" . htmlspecialchars($row['id']) . "</td>
                <td><img src=\"{$imgSrc}\" style=\"max-width:50px;border-radius:6px;\" loading=\"lazy\" onerror=\"this.src='img/op13.jpeg'\"></td>
                <td><strong>" . htmlspecialchars($row['nombre_producto']) . "</strong></td>
                <td>" . htmlspecialchars($row['nombre_usuario']) . "</td>
                <td>" . htmlspecialchars($row['cantidad']) . "</td>
                <td style=\"font-size:0.82rem;\">" . htmlspecialchars($row['fecha_pedido']) . "</td>
                <td><span class=\"badge {$badgeClass}\">{$badgeLabel}</span></td>
                <td>
                  <a href=\"admin/inspeccionar_preventa.php?pedido_id=" . $row['id'] . "\" class=\"btn-accion btn-inspeccionar\">🔍 Ver</a>
                </td>
            ";

            $nuevos[] = [
                'id'      => $row['id'],
                'rowHTML' => $rowHTML,
            ];
        }
    }

    // Contar total pendientes
    $countResult = $conn->query("SELECT COUNT(*) as total FROM pedidos WHERE estado = 'pendiente'");
    $totalPendientes = $countResult ? $countResult->fetch_assoc()['total'] : 0;

    echo json_encode([
        'nuevos'           => $nuevos,
        'total_pendientes' => (int) $totalPendientes,
        'timestamp'        => time(),
    ]);
    exit;
}

// ────────────────────────────────────────────────────────
// ACCIÓN: estado de un pedido específico (cliente)
// ────────────────────────────────────────────────────────
if ($action === 'estado') {
    $pedidoId  = intval($_GET['id'] ?? 0);
    $clienteId = $_SESSION['usuario']['id'];

    if ($pedidoId <= 0) {
        echo json_encode(['error' => 'ID inválido']);
        exit;
    }

    $stmt = $conn->prepare("
        SELECT estado FROM pedidos
        WHERE id = ? AND cliente_id = ?
    ");
    $stmt->bind_param('ii', $pedidoId, $clienteId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        echo json_encode(['error' => 'Pedido no encontrado']);
        exit;
    }

    $row = $result->fetch_assoc();
    $estado = $row['estado'];

    $labels = [
        'pendiente'  => '⏳ Pendiente',
        'confirmado' => '✅ Confirmado',
        'cancelado'  => '❌ Cancelado',
        'enviado'    => '📦 Enviado',
    ];
    $classes = [
        'pendiente'  => 'badge-pendiente',
        'confirmado' => 'badge-confirmado',
        'cancelado'  => 'badge-cancelado',
        'enviado'    => 'badge-active',
    ];

    $label = $labels[$estado] ?? $estado;
    $class = $classes[$estado] ?? 'badge-pendiente';

    echo json_encode([
        'estado'    => $estado,
        'badgeHTML' => "<span class=\"badge {$class}\">{$label}</span>",
    ]);
    exit;
}

// ────────────────────────────────────────────────────────
// ACCIÓN: estadísticas generales (admin)
// ────────────────────────────────────────────────────────
if ($action === 'stats') {
    if ($rol !== 'admin') {
        http_response_code(403);
        echo json_encode(['error' => 'Acceso denegado']);
        exit;
    }

    $stats = [];

    $r = $conn->query("SELECT COUNT(*) as c FROM preventas WHERE stock_disponible > 0");
    $stats['preventas_activas'] = $r ? (int)$r->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT COUNT(*) as c FROM pedidos WHERE estado = 'pendiente'");
    $stats['pedidos_pendientes'] = $r ? (int)$r->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT COUNT(*) as c FROM pedidos WHERE DATE(fecha_pedido) = CURDATE()");
    $stats['pedidos_hoy'] = $r ? (int)$r->fetch_assoc()['c'] : 0;

    $r = $conn->query("SELECT COUNT(*) as c FROM clientes");
    $stats['total_clientes'] = $r ? (int)$r->fetch_assoc()['c'] : 0;

    echo json_encode($stats);
    exit;
}

// Acción no reconocida
http_response_code(400);
echo json_encode(['error' => 'Acción no válida']);

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * api_preventas.php — Endpoint JSON para búsqueda en tiempo real
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * GET params:
 *   q         → término de búsqueda
 *   categoria → filtrar por categoría
 *   disponible → solo con stock > 0
 *   formato   → 'galeria' (default) | 'tabla'
 */

session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode(['error' => 'No autenticado']);
    exit;
}

include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

console_time_start(); // medición de rendimiento

$q          = trim($_GET['q']         ?? '');
$categoria  = trim($_GET['categoria'] ?? '');
$disponible = !empty($_GET['disponible']);

// ── Construir query con prepared statement ────────────
$conditions = ['1=1'];
$params     = [];
$types      = '';

if ($q !== '') {
    $conditions[] = '(nombre_producto LIKE ? OR descripcion LIKE ?)';
    $params[] = "%{$q}%";
    $params[] = "%{$q}%";
    $types   .= 'ss';
}

if ($categoria !== '') {
    $conditions[] = 'categoria = ?';
    $params[] = $categoria;
    $types   .= 's';
}

if ($disponible) {
    $conditions[] = 'stock_disponible > 0';
}

$sql = 'SELECT id, nombre_producto, descripcion, precio, stock_disponible,
               imagen_url, fecha_inicio, fecha_fin, categoria
        FROM preventas
        WHERE ' . implode(' AND ', $conditions) . '
        ORDER BY fecha_inicio DESC
        LIMIT 50';

$stmt = $conn->prepare($sql);

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$items = [];
while ($row = $result->fetch_assoc()) {
    $items[] = [
        'id'               => (int)$row['id'],
        'nombre_producto'  => $row['nombre_producto'],
        'descripcion'      => $row['descripcion'] ?? '',
        'precio'           => (float)$row['precio'],
        'stock_disponible' => (int)$row['stock_disponible'],
        'imagen_url'       => $row['imagen_url'] ?? '',
        'fecha_inicio'     => $row['fecha_inicio'] ?? '',
        'fecha_fin'        => $row['fecha_fin'] ?? '',
        'categoria'        => $row['categoria'] ?? '',
    ];
}

$stmt->close();

// ── Respuesta ─────────────────────────────────────────
echo json_encode([
    'total'   => count($items),
    'items'   => $items,
    'tiempo'  => console_time_end(),
]);

// ── Helpers de medición ───────────────────────────────
function console_time_start() {
    $GLOBALS['_perf_start'] = microtime(true);
}
function console_time_end() {
    $ms = (microtime(true) - $GLOBALS['_perf_start']) * 1000;
    return round($ms, 2) . 'ms';
}

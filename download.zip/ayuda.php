<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */

session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ayuda — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="dashboard-body">

<?php include 'navbar.php'; ?>
<?php
include 'breadcrumbs.php';
$breadcrumbs_ayuda = ['Inicio' => '/dashboard.php', 'Ayuda' => ''];
generarBreadcrumbs($breadcrumbs_ayuda);
?>

<div class="ayuda-container">

  <div class="ayuda-hero">
    <h1>🏴‍☠️ Centro de Ayuda</h1>
    <p>Todo lo que necesitas saber sobre One Piece Preventas</p>
  </div>

  <!-- ===== MISIÓN ===== -->
  <div class="ayuda-section" id="secMision">
    <div class="ayuda-header" onclick="toggleAyuda('secMision')">
      <h3><span class="icon">🎯</span> Nuestra Misión</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>Nuestra misión es brindar a los fanáticos del anime <strong>One Piece</strong> en México y Latinoamérica acceso anticipado a productos exclusivos, garantizando la autenticidad, calidad y puntualidad en cada entrega.</p>
      <p>Trabajamos directamente con distribuidores y marcas oficiales para ofrecerte figuras, cartas coleccionables, accesorios y expansiones antes de que lleguen al mercado general, a precios justos y con atención personalizada.</p>
    </div>
  </div>

  <!-- ===== VISIÓN ===== -->
  <div class="ayuda-section" id="secVision">
    <div class="ayuda-header" onclick="toggleAyuda('secVision')">
      <h3><span class="icon">🔭</span> Nuestra Visión</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>Ser la plataforma líder de preventas de productos de anime en habla hispana, reconocida por su confiabilidad, variedad y comunidad activa de coleccionistas.</p>
      <p>Aspiramos a expandir nuestro catálogo más allá de One Piece, cubriendo todos los grandes títulos del anime moderno, y convertirnos en el puente entre los fans y los productos que aman.</p>
    </div>
  </div>

  <!-- ===== QUÉ HACEMOS ===== -->
  <div class="ayuda-section" id="secQueSomos">
    <div class="ayuda-header" onclick="toggleAyuda('secQueSomos')">
      <h3><span class="icon">⚓</span> ¿Qué es One Piece Preventas?</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>One Piece Preventas es una plataforma digital donde puedes apartar productos temáticos de One Piece <strong>antes de su lanzamiento oficial</strong>. Al hacer una preventa:</p>
      <ul>
        <li>Aseguras tu producto aunque el stock sea limitado</li>
        <li>Pagas el precio de preventa (generalmente más bajo)</li>
        <li>Recibes tu pedido en cuanto el producto está disponible</li>
        <li>Tienes acceso a ediciones especiales y exclusivas</li>
      </ul>
      <p>Nuestro catálogo incluye: <strong>Starters</strong> (mazos iniciales de cartas), <strong>Expansiones</strong> (booster packs), <strong>Accesorios</strong> (playmates, sleeves, dado) y <strong>Figuras</strong> de colección.</p>
    </div>
  </div>

  <!-- ===== CÓMO HACER UN PEDIDO ===== -->
  <div class="ayuda-section" id="secPedido">
    <div class="ayuda-header" onclick="toggleAyuda('secPedido')">
      <h3><span class="icon">🛒</span> ¿Cómo hacer un pedido?</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>Realizar un pedido es muy sencillo, sigue estos pasos:</p>
      <ul>
        <li>Inicia sesión con tu cuenta (o regístrate si es tu primera vez)</li>
        <li>Ve a la sección <strong>"Hacer Pedido"</strong> en el menú de Preventas</li>
        <li>Elige el producto que deseas y selecciona la cantidad</li>
        <li>Sube tu comprobante de pago (transferencia o depósito)</li>
        <li>Haz clic en <strong>"Pedir"</strong> y ¡listo!</li>
        <li>Podrás ver el estado de tu pedido en <strong>"Mis Pedidos"</strong></li>
      </ul>
    </div>
  </div>

  <!-- ===== PAGOS ===== -->
  <div class="ayuda-section" id="secPagos">
    <div class="ayuda-header" onclick="toggleAyuda('secPagos')">
      <h3><span class="icon">💳</span> Métodos de pago</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>Aceptamos los siguientes métodos de pago:</p>
      <ul>
        <li>Transferencia bancaria (SPEI)</li>
        <li>Depósito en OXXO</li>
        <li>PayPal (amigos y familia)</li>
        <li>Mercado Pago</li>
      </ul>
      <p>Una vez realizado el pago, sube tu comprobante al momento de hacer el pedido. El equipo verificará y confirmará tu orden en un plazo de <strong>24 a 48 horas hábiles</strong>.</p>
    </div>
  </div>

  <!-- ===== ENVÍOS ===== -->
  <div class="ayuda-section" id="secEnvios">
    <div class="ayuda-header" onclick="toggleAyuda('secEnvios')">
      <h3><span class="icon">📦</span> Envíos y entregas</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>Los pedidos en preventa se envían una vez que el producto llega a nuestro almacén. El tiempo varía según el producto:</p>
      <ul>
        <li><strong>Productos en stock:</strong> envío en 3-5 días hábiles</li>
        <li><strong>Preventas activas:</strong> envío en la fecha estimada del producto</li>
        <li>Envíos a toda la República Mexicana vía Estafeta, DHL o Fedex</li>
        <li>El costo de envío se calcula según tu código postal</li>
      </ul>
    </div>
  </div>

  <!-- ===== MI CUENTA ===== -->
  <div class="ayuda-section" id="secCuenta">
    <div class="ayuda-header" onclick="toggleAyuda('secCuenta')">
      <h3><span class="icon">👤</span> Gestión de mi cuenta</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>Desde tu perfil puedes:</p>
      <ul>
        <li>Cambiar tu nombre de usuario</li>
        <li>Actualizar tu contraseña</li>
        <li>Ver el historial completo de tus pedidos</li>
        <li>Revisar el estado de cada orden</li>
      </ul>
      <p>Para acceder a tu perfil haz clic en tu nombre de usuario en la barra de navegación superior y selecciona <strong>"Mi Perfil"</strong>.</p>
    </div>
  </div>

  <!-- ===== CONTACTO ===== -->
  <div class="ayuda-section" id="secContacto">
    <div class="ayuda-header" onclick="toggleAyuda('secContacto')">
      <h3><span class="icon">✉️</span> Contacto y soporte</h3>
      <span class="ayuda-chevron">▼</span>
    </div>
    <div class="ayuda-body">
      <p>¿Tienes alguna duda o problema? Contáctanos por cualquiera de estos medios:</p>
      <ul>
        <li>📘 Facebook: <a href="https://www.facebook.com/share/14DvRmiHCis/" target="_blank" style="color:var(--gold-bright)">One Piece Preventas</a></li>
        <li>📧 Whatsapp: 449 105 9872</li>
        <li>⏰ Horario de atención: Lunes a Viernes de 10am a 6pm (Hora Centro de México)</li>
      </ul>
      <p>Respondemos todos los mensajes en un plazo máximo de 24 horas hábiles.</p>
    </div>
  </div>

</div>

<footer class="site-footer">
  <p>Síguenos en <a href="https://www.facebook.com/share/14DvRmiHCis/" target="_blank">Facebook</a> &nbsp;|&nbsp;
  &copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="js/cache.js"></script>
<script src="js/api.js"></script>
<script src="js/dom.js"></script>
<script src="js/animations.js"></script>
<script src="js/carousel.js"></script>
<script src="js/menu-scripts.js"></script>
<script>
function toggleAyuda(id) {
  const section = document.getElementById(id);
  const isOpen  = section.classList.contains('open');
  // Cerrar todos
  document.querySelectorAll('.ayuda-section').forEach(s => s.classList.remove('open'));
  // Abrir el clickeado si no estaba abierto
  if (!isOpen) section.classList.add('open');
}
// Abrir el primero por defecto
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('secMision').classList.add('open');
});
</script>

</body>
</html>

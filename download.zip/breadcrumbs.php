<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * Función para generar breadcrumbs dinámicamente
 * 
 * @param array $breadcrumbs Array con estructura: ['nombre' => 'URL'] o solo 'nombre' para el activo
 * @return void Imprime el HTML de breadcrumbs
 */
function generarBreadcrumbs($breadcrumbs) {
    if (empty($breadcrumbs)) {
        return;
    }
    
    echo '<div class="breadcrumbs-container">';
    echo '<nav aria-label="Breadcrumb" class="breadcrumbs">';
    echo '<ol itemscope itemtype="https://schema.org/BreadcrumbList">';
    
    $position = 1;
    $totalItems = count($breadcrumbs);
    
    foreach ($breadcrumbs as $nombre => $url) {
        echo '<li itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem"';
        
        // Si es el último elemento (activo)
        if ($position === $totalItems) {
            echo ' class="active"';
            echo '>';
            echo '<span itemprop="name">' . htmlspecialchars($nombre) . '</span>';
        } else {
            echo '>';
            echo '<a itemprop="item" href="' . htmlspecialchars($url) . '">';
            echo '<span itemprop="name">' . htmlspecialchars($nombre) . '</span>';
            echo '</a>';
        }
        
        echo '<meta itemprop="position" content="' . $position . '" />';
        
        // Agregar separador excepto en el último elemento
        if ($position < $totalItems) {
            echo '<span class="separator">›</span>';
        }
        
        echo '</li>';
        $position++;
    }
    
    echo '</ol>';
    echo '</nav>';
    echo '</div>';
}

/**
 * Breadcrumbs predefinidos para páginas comunes
 */
$breadcrumbs_dashboard = [
    'Inicio' => '/dashboard.php'
];

$breadcrumbs_preventas_activas = [
    'Inicio' => '/dashboard.php',
    'Preventas' => '#',
    'Preventas Activas' => ''
];

$breadcrumbs_hacer_pedido = [
    'Inicio' => '/dashboard.php',
    'Preventas' => '#',
    'Hacer Pedido' => ''
];

$breadcrumbs_mis_pedidos = [
    'Inicio' => '/dashboard.php',
    'Mis Pedidos' => ''
];

$breadcrumbs_panel_admin = [
    'Inicio' => '/dashboard.php',
    'Administración' => '#',
    'Panel Admin' => ''
];

$breadcrumbs_agregar_preventa = [
    'Inicio' => '/dashboard.php',
    'Administración' => '/admin/panel_admin.php',
    'Agregar Preventa' => ''
];

$breadcrumbs_editar_preventa = [
    'Inicio' => '/dashboard.php',
    'Administración' => '/admin/panel_admin.php',
    'Editar Preventa' => ''
];
?>

<?php
/**
 * config.php — Constantes globales del sistema
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */

// ── URL base del sitio ────────────────────────────────────────────────
define('BASE_URL', 'https://galateastore.infinityfreeapp.com');

// ── Google OAuth 2.0 ─────────────────────────────────────────────────
define('GOOGLE_CLIENT_ID',     '909916770984-fq8da4dgg66one22rhp1m9lkvoni4a0i.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI',  BASE_URL . '/seguridad/google_callback.php');

// ── Nombre de la app ──────────────────────────────────────────────────
define('APP_NAME', 'OnePiecePreventas');

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * dashboard.php — Panel principal de la plataforma
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 * Matrícula: 221181
 *
 * FIXES:
 *  - Validación de sesión en BD (cierre global entre navegadores)
 *  - Aplicación de tema oscuro/claro desde BD
 *  - Soporte de idioma (es/en) desde BD
 */
session_start();

// ── Redirigir si no hay sesión PHP ────────────────────────────────────
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

// ══════════════════════════════════════════════════════════════════════
// FIX 1: VALIDACIÓN DE SESIÓN EN BD (cierre de sesión global)
// Si el token fue revocado desde otro lado, expulsar al usuario aquí.
// ══════════════════════════════════════════════════════════════════════
$tokenBD = $_SESSION['session_token'] ?? null;
if ($tokenBD) {
    $sesionBD = validarSesionBD($conn, $tokenBD);
    if (!$sesionBD) {
        // Sesión revocada o expirada — destruir sesión local y redirigir
        session_unset();
        session_destroy();
        header('Location: login.php?msg=sesion_expirada');
        exit;
    }
} else {
    // No hay token en sesión → sesión inválida (sesión antigua pre-fix)
    session_unset();
    session_destroy();
    header('Location: login.php?msg=sesion_expirada');
    exit;
}

// ══════════════════════════════════════════════════════════════════════
// FIX 2: LEER TEMA E IDIOMA DESDE LA BD
// ══════════════════════════════════════════════════════════════════════
$userId = (int)$_SESSION['usuario']['id'];
$stmtPref = $conn->prepare("SELECT theme, language FROM clientes WHERE id = ?");
$stmtPref->bind_param('i', $userId);
$stmtPref->execute();
$stmtPref->bind_result($userTheme, $userLang);
$stmtPref->fetch();
$stmtPref->close();

// Valores seguros por defecto
$userTheme = in_array($userTheme, ['dark', 'light']) ? $userTheme : 'dark';
$userLang  = in_array($userLang,  ['es', 'en', 'fr', 'ja', 'zh']) ? $userLang  : 'es';
// Sync session so navbar and all pages get the correct language
$_SESSION['usuario']['language'] = $userLang;
$_SESSION['usuario']['theme']    = $userTheme;

// ══════════════════════════════════════════════════════════════════════
// FIX 3: TEXTOS DE IDIOMA (es / en / fr / ja / zh) — 5 idiomas
// Cargamos desde el archivo central de traducciones
// ══════════════════════════════════════════════════════════════════════
require_once __DIR__ . '/lang/translations.php';
$_fullT = getLang($userLang);

// Mapa de claves cortas (dashboard usa claves sin prefijo 'dash_')
// para no tener que reescribir todo el dashboard.php
$t = [
    'title'           => $_fullT['dash_title']         ?? 'Dashboard',
    'bienvenido'      => $_fullT['dash_bienvenido']     ?? 'Bienvenido',
    'bienvenido_sub'  => $_fullT['dash_logueado_como']  ?? 'Sesión iniciada como',
    'administrador'   => $_fullT['dash_administrador']  ?? 'Administrador',
    'empezar'         => $_fullT['dash_empezar']        ?? '⚓ Empezar',
    'panel_admin'     => $_fullT['dash_panel_admin']    ?? '⚙️ Panel Admin',
    'bienvenido_user' => $_fullT['dash_bienvenido_u']   ?? '🏴‍☠️ Bienvenido, ',
    'panel_adm_btn'   => $_fullT['dash_panel_adm_btn']  ?? 'Panel Admin',
    'nueva_prev'      => $_fullT['dash_nueva_prev']     ?? 'Nueva Preventa',
    'ver_prev'        => $_fullT['dash_ver_prev']       ?? 'Ver Preventas',
    'ayuda'           => $_fullT['dash_ayuda']          ?? 'Ayuda',
    'app_b'           => $_fullT['dash_app_b']          ?? 'App B (SSO)',
    'prev_activas'    => $_fullT['dash_prev_activas']   ?? 'Preventas Activas',
    'ped_pendientes'  => $_fullT['dash_ped_pend']       ?? 'Pedidos Pendientes',
    'ped_hoy'         => $_fullT['dash_ped_hoy']        ?? 'Pedidos Hoy',
    'total_clientes'  => $_fullT['dash_total_cli']      ?? 'Total Clientes',
    'prev_dest'       => $_fullT['dash_prev_dest']      ?? '🏴‍☠️ Preventas Destacadas',
    'nuevos_lanz'     => $_fullT['dash_nuevos_lanz']    ?? '🆕 Nuevos Lanzamientos',
    'prev_disp'       => $_fullT['dash_prev_disp']      ?? '🛒 Preventas Disponibles',
    'buscar_ph'       => $_fullT['nav_buscar_ph']       ?? 'Buscar preventa...',
    'todas_cat'       => $_fullT['nav_todas_cat']       ?? 'Todas las categorías',
    'cargando'        => $_fullT['dash_cargando']       ?? 'Cargando...',
    'ordenar'         => $_fullT['dash_ordenar']        ?? '🛒 Ordenar ahora',
    'mis_pedidos'     => $_fullT['dash_mis_pedidos']    ?? 'Mis Pedidos',
    'hacer_pedido'    => $_fullT['dash_hacer_pedido']   ?? 'Hacer Pedido',
    'fb_siguenos'     => $_fullT['dash_fb_siguenos']    ?? 'Síguenos en',
    'badge_nuevo'     => $_fullT['dash_badge_nuevo']    ?? '✦ Nuevo',
    'badge_prev'      => $_fullT['dash_badge_prev']     ?? '⚡ Preventa',
    'nuevo_lanz'      => $_fullT['dash_badge_nuevo']    ?? '✦ Nuevo',
    'prev_badge'      => $_fullT['dash_badge_prev']     ?? '⚡ Preventa',
    'disponibles'     => $_fullT['dash_disponibles']    ?? 'disponibles',
    'en_stock'        => $_fullT['dash_en_stock']       ?? 'en stock',
    'ver_det'         => $_fullT['dash_ver_det']        ?? 'Ver detalles →',
    'sesion_exp'      => $_fullT['dash_sesion_exp']     ?? '⏰ Tu sesión expiró.',
    'footer_copy'     => $_fullT['footer_copy']         ?? '© 2026 One Piece Preventas.',
];

// ── Datos de sesión ───────────────────────────────────────────────────
$usuario      = $_SESSION['usuario']['nombre_usuario'];
$rol          = $_SESSION['usuario']['rol'];
$show_welcome = isset($_SESSION['show_welcome']) && $_SESSION['show_welcome'];
if ($show_welcome) unset($_SESSION['show_welcome']);

/* ── Obtener categorías para el filtro ── */
$cats_res   = $conn->query("SELECT DISTINCT categoria FROM preventas WHERE categoria != '' ORDER BY categoria");
$categorias = [];
while ($cats_res && $c = $cats_res->fetch_assoc()) $categorias[] = $c['categoria'];

/* ── Para el carrusel — top 6 más recientes con stock ── */
$sqlCar = "SELECT id, nombre_producto, precio, stock_disponible, imagen_url, categoria,
                  fecha_inicio, fecha_fin
           FROM preventas WHERE stock_disponible > 0 ORDER BY fecha_inicio DESC LIMIT 6";
$resCar = $conn->query($sqlCar);
$slides = $resCar ? $resCar->fetch_all(MYSQLI_ASSOC) : [];

/* ── Nuevos lanzamientos: últimos 4 agregados ── */
$sqlNuevos = "SELECT id, nombre_producto, precio, stock_disponible, imagen_url, categoria, fecha_inicio
              FROM preventas WHERE stock_disponible > 0 ORDER BY fecha_inicio DESC LIMIT 4";
$resNuevos = $conn->query($sqlNuevos);
$nuevos    = $resNuevos ? $resNuevos->fetch_all(MYSQLI_ASSOC) : [];

/* Helper: determinar si una preventa es "nueva" (últimos 7 días) o "preventa" */
function getBadgeType(string $fecha_inicio): string {
  $diff = (new DateTime())->diff(new DateTime($fecha_inicio))->days;
  return $diff <= 7 ? 'nuevo' : 'preventa';
}
?>
<!DOCTYPE html>
<html lang="<?= $userLang ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $t['title'] ?></title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">

  <?php /* ══ FIX 2: Inyectar variables CSS según el tema del usuario ══ */ ?>
  <!-- Light theme handled via CSS class theme-light in estilos.css -->
</head>
<body class="dashboard-body<?= $userTheme === 'light' ? ' theme-light' : '' ?>">

<?php include 'navbar.php'; ?>
<?php include 'breadcrumbs.php'; generarBreadcrumbs($breadcrumbs_dashboard); ?>

<!-- ═══════════════════════════════════════════
     MODAL DE BIENVENIDA
═══════════════════════════════════════════ -->
<?php if ($show_welcome): ?>
<div class="welcome-overlay" id="welcomeModal">
  <div class="welcome-modal">
    <img src="img/Sombrero.png" alt="Sombrero" class="sombrero-icon">
    <h2><?= $t['bienvenido'] ?></h2>
    <div class="welcome-name">⚓ <?= htmlspecialchars($usuario) ?></div>
    <?php if ($rol === 'admin'): ?>
      <p><?= $t['bienvenido_sub'] ?> <strong><?= $t['administrador'] ?></strong>.</p>
      <div class="welcome-features">
        <div class="welcome-feature"><span class="feat-icon">📦</span><?= $t['nueva_prev'] ?></div>
        <div class="welcome-feature"><span class="feat-icon">👥</span><?= $t['ped_pendientes'] ?></div>
        <div class="welcome-feature"><span class="feat-icon">➕</span><?= $t['nueva_prev'] ?></div>
        <div class="welcome-feature"><span class="feat-icon">⚙️</span><?= $t['panel_adm_btn'] ?></div>
      </div>
    <?php else: ?>
      <p><?= $t['bienvenido_sub'] ?> <strong>One Piece Preventas</strong>.</p>
      <div class="welcome-features">
        <div class="welcome-feature"><span class="feat-icon">🛍️</span><?= $t['ver_prev'] ?></div>
        <div class="welcome-feature"><span class="feat-icon">📋</span><?= $t['hacer_pedido'] ?></div>
        <div class="welcome-feature"><span class="feat-icon">📦</span><?= $t['mis_pedidos'] ?></div>
        <div class="welcome-feature"><span class="feat-icon">👤</span>Perfil</div>
      </div>
    <?php endif; ?>
    <button class="btn-welcome" id="btnCloseWelcome"><?= $t['empezar'] ?></button>
  </div>
</div>
<?php endif; ?>

<div class="page-content">
  <h1 class="page-title">
    <?= $rol === 'admin' ? $t['panel_admin'] : $t['bienvenido_user'] . htmlspecialchars($usuario) . '!' ?>
  </h1>

  <!-- Quick actions -->
  <?php if ($rol === 'admin'): ?>
  <div class="quick-actions">
    <a href="admin/panel_admin.php"      class="quick-card"><img src="img/usoop.png" alt=""><span><?= $t['panel_adm_btn'] ?></span></a>
    <a href="admin/agregar_preventa.php" class="quick-card"><img src="img/zoro.png"  alt=""><span><?= $t['nueva_prev'] ?></span></a>
    <a href="preventas_activas.php"      class="quick-card"><img src="img/nami.png"  alt=""><span><?= $t['ver_prev'] ?></span></a>
    <a href="ayuda.php"                  class="quick-card"><img src="img/chooper.png" alt=""><span><?= $t['ayuda'] ?></span></a>
    <a href="sso_generar.php"            class="quick-card"><img src="img/sanji.png" alt=""><span><?= $t['app_b'] ?></span></a>
  </div>

  <!-- ═══ ESTADÍSTICAS ADMIN ═══ -->
  <div id="stats-container" class="stats-grid">
    <div class="stat-card" id="stat-activas">
      <span class="stat-icon">📦</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-activas">—</div>
        <div class="stat-label"><?= $t['prev_activas'] ?></div>
      </div>
    </div>
    <div class="stat-card" id="stat-pendientes">
      <span class="stat-icon">⏳</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-pendientes">—</div>
        <div class="stat-label"><?= $t['ped_pendientes'] ?> <span class="badge-notify" id="badge-pedidos-pendientes" style="display:none"></span></div>
      </div>
    </div>
    <div class="stat-card" id="stat-hoy">
      <span class="stat-icon">📅</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-hoy">—</div>
        <div class="stat-label"><?= $t['ped_hoy'] ?></div>
      </div>
    </div>
    <div class="stat-card" id="stat-clientes">
      <span class="stat-icon">👥</span>
      <div class="stat-info">
        <div class="stat-num" id="stat-num-clientes">—</div>
        <div class="stat-label"><?= $t['total_clientes'] ?></div>
      </div>
    </div>
  </div>

  <?php else: ?>
  <div class="quick-actions">
    <a href="preventas_activas.php" class="quick-card"><img src="img/nami.png"    alt=""><span><?= $t['ver_prev'] ?></span></a>
    <a href="hacer_pedido.php"       class="quick-card"><img src="img/zoro.png"   alt=""><span><?= $t['hacer_pedido'] ?></span></a>
    <a href="mis_pedidos.php"        class="quick-card"><img src="img/sanji.png"  alt=""><span><?= $t['mis_pedidos'] ?></span></a>
    <a href="ayuda.php"              class="quick-card"><img src="img/chooper.png" alt=""><span><?= $t['ayuda'] ?></span></a>
  </div>
  <?php endif; ?>

  <!-- ═══ CARRUSEL DE PREVENTAS DESTACADAS ═══ -->
  <?php if (count($slides) >= 2): ?>
  <p class="carousel-section-title"><?= $t['prev_dest'] ?></p>
  <div id="carousel-preventas" class="carousel-wrapper" tabindex="0" style="margin-bottom:36px;">
    <div class="carousel-track">
      <?php foreach ($slides as $slide):
        $badge    = getBadgeType($slide['fecha_inicio'] ?? date('Y-m-d'));
        $badgeTxt = $badge === 'nuevo' ? $t['badge_nuevo'] : $t['badge_prev'];
        $imgUrl   = htmlspecialchars($slide['imagen_url'] ?: 'img/op13.jpeg');
        $nombre   = htmlspecialchars($slide['nombre_producto']);
        $precio   = number_format($slide['precio'], 2);
        $stock    = (int)$slide['stock_disponible'];
        $id       = (int)$slide['id'];
      ?>
      <div class="carousel-slide">
        <img data-src="<?= $imgUrl ?>"
             src="img/op13.jpeg"
             alt="<?= $nombre ?>"
             class="imagen-preventa"
             onerror="this.src='img/op13.jpeg'">
        <div class="carousel-caption">
          <span class="carousel-badge badge-<?= $badge ?>"><?= $badgeTxt ?></span>
          <h3><?= $nombre ?></h3>
          <div class="carousel-caption-meta">
            <span class="carousel-price">$<?= $precio ?></span>
            <span class="carousel-stock">📦 <?= $stock ?> <?= $t['disponibles'] ?></span>
          </div>
          <a href="hacer_pedido.php?id=<?= $id ?>" class="carousel-btn-order">
            <?= $t['ordenar'] ?>
          </a>
        </div>
        <div class="carousel-thumb-info">
          <span style="font-size:0.7rem;text-transform:uppercase;letter-spacing:1px;">Stock</span>
          <strong><?= $stock ?></strong>
          <span><?= $t['disponibles'] ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <button class="carousel-btn-prev" aria-label="Anterior">&#8249;</button>
    <button class="carousel-btn-next" aria-label="Siguiente">&#8250;</button>
    <div class="carousel-indicators"></div>
  </div>
  <?php endif; ?>

  <!-- ═══ NUEVOS LANZAMIENTOS ═══ -->
  <?php if (count($nuevos) > 0): ?>
  <div class="nuevos-section">
    <p class="carousel-section-title"><?= $t['nuevos_lanz'] ?></p>
    <div class="nuevos-grid">
      <?php foreach ($nuevos as $n):
        $badge2    = getBadgeType($n['fecha_inicio'] ?? date('Y-m-d'));
        $badgeTxt2 = $badge2 === 'nuevo' ? $t['nuevo_lanz'] : $t['prev_badge'];
        $imgUrl2   = htmlspecialchars($n['imagen_url'] ?: 'img/op13.jpeg');
        $nombre2   = htmlspecialchars($n['nombre_producto']);
        $precio2   = number_format($n['precio'], 2);
        $stock2    = (int)$n['stock_disponible'];
        $id2       = (int)$n['id'];
      ?>
      <a href="hacer_pedido.php?id=<?= $id2 ?>" class="nuevo-card">
        <div class="nuevo-card-img-wrap">
          <img data-src="<?= $imgUrl2 ?>"
               src="img/op13.jpeg"
               alt="<?= $nombre2 ?>"
               class="nuevo-card-img imagen-preventa"
               onerror="this.src='img/op13.jpeg'">
        </div>
        <div class="nuevo-card-body">
          <span class="nuevo-card-badge badge-<?= $badge2 ?>"><?= $badgeTxt2 ?></span>
          <h4><?= $nombre2 ?></h4>
          <div class="nuevo-card-price">$<?= $precio2 ?></div>
          <div class="nuevo-card-stock">📦 <?= $stock2 ?> <?= $t['en_stock'] ?></div>
          <span class="nuevo-card-cta"><?= $t['ver_det'] ?></span>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
  <?php endif; ?>

  <?php if ($rol !== 'admin'): ?>
  <!-- ═══ BUSCADOR EN TIEMPO REAL ═══ -->
  <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);margin-bottom:16px;"><?= $t['prev_disp'] ?></h2>

  <div class="buscador-container" style="margin-bottom:22px;display:flex;gap:12px;flex-wrap:wrap;align-items:center;">
    <input type="text" id="buscador-preventas"
           placeholder="<?= $t['buscar_ph'] ?>"
           autocomplete="off"
           style="flex:1;min-width:200px;padding:10px 16px;border:2px solid rgba(247,214,122,0.4);
                  border-radius:10px;background:rgba(44,31,20,0.8);color:var(--gold);font-size:0.95rem;">
    <select id="filtro-categoria"
            style="padding:10px 14px;border:2px solid rgba(247,214,122,0.4);border-radius:10px;
                   background:rgba(44,31,20,0.8);color:var(--gold);font-size:0.9rem;">
      <option value=""><?= $t['todas_cat'] ?></option>
      <?php foreach ($categorias as $cat): ?>
      <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
      <?php endforeach; ?>
    </select>
    <span id="resultado-count" style="font-size:0.85rem;color:rgba(247,214,122,0.6);white-space:nowrap;"></span>
  </div>

  <div id="galeria-preventas" class="galeria-preventas">
    <div style="text-align:center;padding:40px;grid-column:1/-1;">
      <div class="op-spinner" style="margin:0 auto 12px;"></div>
      <p style="color:rgba(247,214,122,0.5);font-size:0.9rem;"><?= $t['cargando'] ?></p>
    </div>
  </div>
  <?php endif; ?>

</div><!-- /page-content -->

<footer class="site-footer">
  <p><?= $t['fb_siguenos'] ?> <a href="https://www.facebook.com/share/14DvRmiHCis/" target="_blank">Facebook</a>
     &nbsp;|&nbsp; &copy; 2026 One Piece Preventas.</p>
</footer>

<script src="js/cache.js"></script>
<script src="js/api.js"></script>
<script src="js/dom.js"></script>
<script src="js/animations.js"></script>
<script src="js/carousel.js"></script>
<script src="js/polling.js"></script>
<script src="js/menu-scripts.js"></script>
<script>
(function () {
  'use strict';

  // ── Cerrar modal de bienvenida ──────────────────────────
  const btnWelcome = document.getElementById('btnCloseWelcome');
  if (btnWelcome) {
    btnWelcome.addEventListener('click', () => {
      const overlay = document.getElementById('welcomeModal');
      if (overlay) {
        overlay.style.transition = 'opacity 0.3s ease';
        overlay.style.opacity = '0';
        setTimeout(() => overlay.remove(), 320);
      }
    });
  }

  // ── Inicializar carrusel ────────────────────────────────
  if (document.getElementById('carousel-preventas') && window.OnePieceCarousel) {
    OnePieceCarousel.create('#carousel-preventas', { autoplayDelay: 4000 });
  }

  const isAdmin = <?= json_encode($rol === 'admin') ?>;

  if (isAdmin) {
    loadAdminStats();
    if (window.OnePiecePolling) {
      OnePiecePolling.startPedidosPolling('tabla-pedidos-body', 'badge-pedidos-pendientes');
    }
  }

  async function loadAdminStats() {
    const [statsResult] = await Promise.allSettled([
      fetch('api_pedidos.php?action=stats')
        .then(r => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    ]);

    if (statsResult.status === 'fulfilled') {
      const s = statsResult.value;
      animateCounter('stat-num-activas',    s.preventas_activas   || 0);
      animateCounter('stat-num-pendientes', s.pedidos_pendientes  || 0);
      animateCounter('stat-num-hoy',        s.pedidos_hoy         || 0);
      animateCounter('stat-num-clientes',   s.total_clientes      || 0);

      const badge = document.getElementById('badge-pedidos-pendientes');
      if (badge && s.pedidos_pendientes > 0) {
        badge.textContent = s.pedidos_pendientes;
        badge.style.display = 'inline-flex';
      }
      if (window.OnePieceCache) OnePieceCache.set('admin:stats', s, 30_000);
    }
  }

  function animateCounter(elId, target) {
    const el = document.getElementById(elId);
    if (!el) return;
    let current = 0;
    const step  = Math.max(1, Math.floor(target / 20));
    const timer = setInterval(() => {
      current = Math.min(current + step, target);
      el.textContent = current;
      if (current >= target) clearInterval(timer);
    }, 40);
  }

  // ── Buscador (solo clientes) ────────────────────────────
  const galeriaEl   = document.getElementById('galeria-preventas');
  const inputEl     = document.getElementById('buscador-preventas');
  const categoriaEl = document.getElementById('filtro-categoria');
  const countEl     = document.getElementById('resultado-count');
  var abortController = null;

  if (galeriaEl && inputEl) {
    buscarPreventas('', '');

    const debouncedBuscar = debounceLocal(function () {
      buscarPreventas(inputEl.value.trim(), categoriaEl ? categoriaEl.value : '');
    }, 400);

    inputEl.addEventListener('input', debouncedBuscar);
    if (categoriaEl) categoriaEl.addEventListener('change', debouncedBuscar);
  }

  async function buscarPreventas(q, categoria) {
    if (!galeriaEl) return;
    const cacheKey = `preventas:${q}:${categoria}`;
    if (window.OnePieceCache) {
      const cached = OnePieceCache.get(cacheKey);
      if (cached) { renderPreventas(cached); return; }
    }
    if (abortController) abortController.abort();
    abortController = new AbortController();
    if (window.OnePieceDOM) OnePieceDOM.showLoader(galeriaEl, '<?= addslashes($t['cargando']) ?>');
    try {
      const params = new URLSearchParams({ disponible: '1' });
      if (q)         params.set('q', q);
      if (categoria) params.set('categoria', categoria);
      const response = await fetch(`api_preventas.php?${params}`, { signal: abortController.signal });
      if (!response.ok) throw new Error('HTTP ' + response.status);
      const data = await response.json();
      if (window.OnePieceCache) OnePieceCache.set(cacheKey, data, 60_000);
      renderPreventas(data);
    } catch (err) {
      if (err.name === 'AbortError') return;
      if (window.OnePieceDOM) OnePieceDOM.showError(galeriaEl, 'No se pudo conectar. Intenta de nuevo.');
    }
  }

  function renderPreventas(data) {
    if (!galeriaEl || !window.OnePieceDOM) return;
    if (countEl) countEl.textContent = `${data.total} resultado${data.total !== 1 ? 's' : ''}`;
    if (data.total === 0) { OnePieceDOM.showEmpty(galeriaEl, 'No se encontraron preventas.'); return; }
    OnePieceDOM.renderList(galeriaEl, data.items, (item, index) => {
      const card = OnePieceDOM.crearTarjetaPreventa(item);
      card.dataset.animDelay = (index % 6) * 80;
      return card;
    });
    OnePieceDOM.lazyLoadImages('#galeria-preventas [data-src]');
    if (window.OnePieceAnimations) {
      galeriaEl.querySelectorAll('.anim-hidden').forEach((el, i) => {
        el.dataset.animDelay = (i % 6) * 80;
        setTimeout(() => el.classList.add('anim-visible'), parseInt(el.dataset.animDelay || 0));
      });
    }
  }

  function debounceLocal(fn, delay) {
    let t = null;
    return function(...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), delay); };
  }

})();
</script>
</body>
</html>

<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

$usuario = $_SESSION['usuario']['nombre_usuario'];
$rol = $_SESSION['usuario']['rol'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8" />
<title>Dashboard - Preventas</title>
<link rel="stylesheet" href="css/estilos.css" />
</head>
<body class="dashboard-body">

<nav class="navbar">
  <ul class="menu">
    <li>
      <a href="dashboard.php">
        <img src="img/Sombrero.png" alt="Sombrero de Paja" class="menu-icon">
        Inicio
      </a>
    </li>

    <?php if ($rol === 'admin'): ?>
      <li>
        <a href="admin/agregar_preventa.php">
          <img src="img/zoro.png" alt="Katana" class="menu-icon">
          Agregar Preventa
        </a>
      </li>
      <li>
        <a href="preventas_activas.php">
          <img src="img/nami.png" alt="Katana" class="menu-icon">
          Ver Preventas
        </a>
      </li>
      <li>
        <a href="admin/panel_admin.php">
          <img src="img/usoop.png" alt="Katana" class="menu-icon">
          Panel Admin
        </a>
      </li>
      <li>
        <a href="admin/exportar_pedidos.php">
          <img src="img/sanji.png" alt="Katana" class="menu-icon">
          Exportar Pedidos
        </a>
      </li>
    <?php endif; ?>

    <li>
      <a href="hacer_pedido.php">
        <img src="img/chooper.png" alt="Katana" class="menu-icon">
        Hacer Pedido
      </a>
    </li>
    <li>
      <a href="mis_pedidos.php">
        <img src="img/robin.png" alt="Katana" class="menu-icon">
        Mis Pedidos
      </a>
    </li>
    <li>
      <a href="logout.php">
        <img src="img/brook.png" alt="Katana" class="menu-icon">
        Cerrar Sesión
      </a>
    </li>
  </ul>
</nav>

<h1>Bienvenido, <?php echo htmlspecialchars($usuario); ?>!</h1>
<?php if ($rol === 'cliente'): ?>
  <?php
  include __DIR__ . '/db.php';
  $sql = "SELECT * FROM preventas WHERE stock_disponible > 0";
  $result = $conn->query($sql);
  ?>

  <h2 style="text-align:center; margin-top:30px;">Preventas Activas</h2>

  <?php if ($result->num_rows > 0): ?>
    <div class="galeria-preventas">
  <?php while($row = $result->fetch_assoc()): ?>
    <div class="tarjeta-preventa">
      <img src="<?php echo htmlspecialchars($row['imagen_url']); ?>" alt="Producto" class="imagen-preventa">
      <h3 class="nombre-preventa"><?php echo htmlspecialchars($row['nombre_producto']); ?></h3>
    </div>
  <?php endwhile; ?>
</div>

  <?php else: ?>
    <p style="text-align:center;">No hay preventas activas por ahora.</p>
  <?php endif; ?>
<?php endif; ?>




<footer style="text-align:center; margin-top:30px;">
  Síguenos en <a href="https://www.facebook.com/share/14DvRmiHCis/" target="_blank">Facebook</a>
</footer>

</body>
</html>

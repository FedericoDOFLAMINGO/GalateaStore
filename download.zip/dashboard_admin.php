<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
session_start();


if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    echo "⛔ Acceso solo para administradores.";
    exit;
}

$usuario = $_SESSION['usuario']['nombre_usuario'];
?>

<h1>Panel Admin - Bienvenido <?php echo htmlspecialchars($usuario); ?></h1>
<a href="agregar_preventa.php">Agregar Preventa</a> |
<a href="logout.php">Salir</a>

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
session_start();

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'cliente') {
    echo "⛔ Acceso solo para clientes.";
    exit;
}

$usuario = $_SESSION['usuario']['nombre_usuario'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Panel Cliente</title>

  <!-- ✅ SweetAlert -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <style>
    table { border-collapse: collapse; width: 100%; }
    th, td { padding: 10px; text-align: center; }
    img { max-height: 100px; }
  </style>
</head>
<body>

<h1>Panel Cliente - Hola <?php echo htmlspecialchars($usuario); ?></h1>
<a href="hacer_pedido.php">Hacer Pedido</a> |
<a href="logout.php">Salir</a>

<?php
include __DIR__ . '/db.php';

// Traer preventas activas
$sql = "SELECT * FROM preventas WHERE stock_disponible > 0";
$result = $conn->query($sql);
?>

<h2>Preventas Activas</h2>

<?php if ($result->num_rows > 0): ?>
<table border="1" cellpadding="10">
  <tr>
    <th>Producto</th>
    <th>Descripción</th>
    <th>Precio</th>
    <th>Stock</th>
    <th>Imagen</th>
    <th>Acción</th>
  </tr>
  <?php while($row = $result->fetch_assoc()): ?>
  <tr>
    <td><?php echo htmlspecialchars($row['nombre_producto']); ?></td>
    <td><?php echo htmlspecialchars($row['descripcion']); ?></td>
    <td>$<?php echo htmlspecialchars($row['precio']); ?></td>
    <td><?php echo htmlspecialchars($row['stock_disponible']); ?></td>
    <td><img src="<?php echo htmlspecialchars($row['imagen_url']); ?>" alt="Imagen" width="80"></td>
    <td>
      <form method="POST" action="procesar_pedido.php">
        <input type="hidden" name="preventa_id" value="<?php echo $row['id']; ?>">
        <input type="number" name="cantidad" min="1" max="<?php echo $row['stock_disponible']; ?>" value="1" required>
        <button type="submit">Pedir</button>
      </form>
    </td>
  </tr>
  <?php endwhile; ?>
</table>
<?php else: ?>
<p>No hay preventas activas en este momento.</p>
<?php endif; ?>

<!-- ✅ SweetAlert después del pedido -->
<?php if (isset($_GET['pedido']) && $_GET['pedido'] === 'exito'): ?>
<script>
Swal.fire({
  icon: 'success',
  title: '¡Pedido realizado!',
  text: 'Tu pedido fue registrado correctamente 🛒',
  confirmButtonColor: '#3085d6',
  confirmButtonText: 'Aceptar'
});
</script>
<?php endif; ?>

</body>
</html>

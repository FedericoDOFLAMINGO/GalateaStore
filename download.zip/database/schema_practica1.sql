-- ══════════════════════════════════════════════════════════════════════
-- PRÁCTICA 1 UNIDAD 3 — One Piece Preventas | IDGS 8B
-- Fernando Federico Ledesma Hernández | Matrícula: 221181
-- Sistema de Autenticación, Control de Acceso y Gestión de Multisesiones
-- ══════════════════════════════════════════════════════════════════════

-- ── Agregar columnas de seguridad a tabla clientes ────────────────────
ALTER TABLE clientes
  ADD COLUMN IF NOT EXISTS mfa_enabled TINYINT(1)   NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS phone       VARCHAR(20)  DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS theme       VARCHAR(20)  NOT NULL DEFAULT 'dark',
  ADD COLUMN IF NOT EXISTS language    VARCHAR(10)  NOT NULL DEFAULT 'es',
  ADD COLUMN IF NOT EXISTS secret_q1   VARCHAR(255) DEFAULT NULL COMMENT 'Pregunta secreta 1',
  ADD COLUMN IF NOT EXISTS secret_a1   VARCHAR(255) DEFAULT NULL COMMENT 'Respuesta 1 (bcrypt)',
  ADD COLUMN IF NOT EXISTS secret_q2   VARCHAR(255) DEFAULT NULL COMMENT 'Pregunta secreta 2',
  ADD COLUMN IF NOT EXISTS secret_a2   VARCHAR(255) DEFAULT NULL COMMENT 'Respuesta 2 (bcrypt)',
  ADD COLUMN IF NOT EXISTS created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- ── Sesiones activas (multisesiones, IP, User-Agent) ──────────────────
CREATE TABLE IF NOT EXISTS sessions (
  id            BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id       INT              NOT NULL,
  session_token VARCHAR(128)     NOT NULL UNIQUE COMMENT 'Token único por sesión',
  ip_address    VARCHAR(45)      NOT NULL,
  user_agent    TEXT             NOT NULL,
  created_at    DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  last_activity DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  expires_at    DATETIME         NOT NULL,
  revoked       TINYINT(1)      NOT NULL DEFAULT 0,
  INDEX idx_user_id (user_id),
  INDEX idx_token   (session_token),
  INDEX idx_expires (expires_at),
  FOREIGN KEY (user_id) REFERENCES clientes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Refresh tokens (token-based auth, expiración corta) ───────────────
CREATE TABLE IF NOT EXISTS refresh_tokens (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT             NOT NULL,
  token      VARCHAR(256)    NOT NULL UNIQUE,
  session_id BIGINT UNSIGNED DEFAULT NULL,
  expires_at DATETIME        NOT NULL,
  used       TINYINT(1)     NOT NULL DEFAULT 0,
  revoked    TINYINT(1)     NOT NULL DEFAULT 0,
  created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  INDEX idx_token   (token),
  FOREIGN KEY (user_id) REFERENCES clientes(id) ON DELETE CASCADE,
  FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Códigos MFA (OTP email / SMS simulado / llamada simulada) ─────────
CREATE TABLE IF NOT EXISTS mfa_codes (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT             NOT NULL,
  code       VARCHAR(10)     NOT NULL,
  type       ENUM('email','sms','call') NOT NULL DEFAULT 'email',
  expires_at DATETIME        NOT NULL,
  used       TINYINT(1)     NOT NULL DEFAULT 0,
  created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  INDEX idx_expires (expires_at),
  FOREIGN KEY (user_id) REFERENCES clientes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Tokens de recuperación de contraseña ──────────────────────────────
CREATE TABLE IF NOT EXISTS password_resets (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT             NOT NULL,
  token      VARCHAR(128)    NOT NULL UNIQUE,
  type       ENUM('email','sms','call','secret') NOT NULL DEFAULT 'email',
  expires_at DATETIME        NOT NULL,
  used       TINYINT(1)     NOT NULL DEFAULT 0,
  ip_address VARCHAR(45)    NOT NULL DEFAULT '',
  created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  INDEX idx_token   (token),
  INDEX idx_expires (expires_at),
  FOREIGN KEY (user_id) REFERENCES clientes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Intentos de login (brute force + credential stuffing) ─────────────
CREATE TABLE IF NOT EXISTS login_attempts (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  identifier VARCHAR(255)    NOT NULL COMMENT 'usuario o correo intentado',
  ip_address VARCHAR(45)     NOT NULL,
  success    TINYINT(1)     NOT NULL DEFAULT 0,
  created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_identifier (identifier),
  INDEX idx_ip         (ip_address),
  INDEX idx_created    (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Tokens SSO simulado (App A → App B sin re-autenticar) ─────────────
CREATE TABLE IF NOT EXISTS sso_tokens (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id    INT             NOT NULL,
  token      VARCHAR(128)    NOT NULL UNIQUE,
  app_origin VARCHAR(50)     NOT NULL DEFAULT 'appA',
  expires_at DATETIME        NOT NULL,
  used       TINYINT(1)     NOT NULL DEFAULT 0,
  created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_token (token),
  FOREIGN KEY (user_id) REFERENCES clientes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

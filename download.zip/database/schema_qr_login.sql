-- Tabla para el sistema de Login por QR
-- One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
-- Ejecutar en phpMyAdmin o MySQL

CREATE TABLE IF NOT EXISTS `qr_login_tokens` (
  `id`              INT UNSIGNED     NOT NULL AUTO_INCREMENT,
  `token`           VARCHAR(64)      NOT NULL UNIQUE,
  `status`          ENUM('pendiente','confirmado','usado','expirado') NOT NULL DEFAULT 'pendiente',
  `user_id`         INT UNSIGNED     NULL DEFAULT NULL,
  `ip_solicitante`  VARCHAR(45)      NOT NULL DEFAULT '',
  `confirmed_at`    DATETIME         NULL DEFAULT NULL,
  `expires_at`      DATETIME         NOT NULL,
  `created_at`      TIMESTAMP        NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `idx_token`  (`token`),
  INDEX `idx_status` (`status`),
  INDEX `idx_expires`(`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ══════════════════════════════════════════════════════════════════════
-- ACTUALIZACIONES V2 — One Piece Preventas | IDGS 8B
-- Fernando Federico Ledesma Hernández | Matrícula: 221181
-- 
-- EJECUTAR DESPUÉS de schema_practica1.sql (son alteraciones/adiciones)
-- Soporte para 5 idiomas, usuario baneado y tabla de emails enviados
-- ══════════════════════════════════════════════════════════════════════

-- ── Ampliar idiomas soportados (de 'es','en' a 5 idiomas) ──────────────
-- Si la columna language ya existe (VARCHAR(10)), solo aseguramos el CHECK
ALTER TABLE clientes 
  MODIFY COLUMN language VARCHAR(10) NOT NULL DEFAULT 'es';

-- ── Agregar columna banned (para banear usuarios sin eliminarlos) ───────
ALTER TABLE clientes
  ADD COLUMN IF NOT EXISTS banned TINYINT(1) NOT NULL DEFAULT 0;

-- ── Agregar columna rol si no existe (puede llamarse diferente en tu BD) ─
-- ALTER TABLE clientes ADD COLUMN IF NOT EXISTS rol VARCHAR(20) NOT NULL DEFAULT 'cliente';

-- ── Tabla de log de emails enviados (auditoría de correos reales) ───────
CREATE TABLE IF NOT EXISTS email_log (
  id          BIGINT UNSIGNED  NOT NULL AUTO_INCREMENT PRIMARY KEY,
  user_id     INT              NOT NULL,
  to_email    VARCHAR(255)     NOT NULL,
  subject     VARCHAR(255)     NOT NULL,
  tipo        ENUM('mfa_otp','password_reset','welcome','other') NOT NULL DEFAULT 'other',
  enviado     TINYINT(1)       NOT NULL DEFAULT 0 COMMENT '1=real, 0=simulado/fallido',
  error_msg   TEXT             DEFAULT NULL,
  created_at  DATETIME         NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id  (user_id),
  INDEX idx_created  (created_at),
  FOREIGN KEY (user_id) REFERENCES clientes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ── Índice en tabla clientes para búsqueda de usuarios por admin ────────
CREATE INDEX IF NOT EXISTS idx_clientes_rol    ON clientes(rol);
CREATE INDEX IF NOT EXISTS idx_clientes_banned ON clientes(banned);

-- ── Verificar que la columna email existe en clientes ──────────────────
-- ALTER TABLE clientes ADD COLUMN IF NOT EXISTS email VARCHAR(255) DEFAULT NULL;

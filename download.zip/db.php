<?php
$host     = 'sql206.infinityfree.com';
$dbname   = 'if0_41665003_onepiece';
$username = 'if0_41665003';
$password = 'On3A08F31';

$conn = mysqli_connect($host, $username, $password, $dbname);

if (!$conn) {
    die('Error de conexión a la base de datos: ' . mysqli_connect_error());
}

mysqli_set_charset($conn, 'utf8mb4');

<?php
/**
 * fix_passwords.php
 * ─────────────────────────────────────────────────────────────
 * Ejecuta este archivo UNA SOLA VEZ después de importar el SQL.
 * Actualiza los hashes de contraseña de los admins con bcrypt real.
 *
 * Acceso: http://localhost/fix_passwords.php
 * (Elimina o mueve este archivo después de usarlo por seguridad)
 * ─────────────────────────────────────────────────────────────
 */

$servername = "localhost";
$username   = "root";
$password   = "";
$dbname     = "onepiece_preventas";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("❌ Conexión fallida: " . $conn->connect_error);
}

// ── Usuarios y contraseñas a fijar ───────────────────────────
$admins = [
    ['nombre_usuario' => 'chino', 'pass_plain' => 'aldo'],
    ['nombre_usuario' => 'Fede',  'pass_plain' => 'Fede'],
];

echo "<pre style='font-family:monospace;font-size:14px;padding:20px'>";
echo "🔧 <strong>fix_passwords.php — One Piece Preventas</strong>\n";
echo str_repeat("─", 50) . "\n\n";

$todos_ok = true;

foreach ($admins as $admin) {
    $hash = password_hash($admin['pass_plain'], PASSWORD_BCRYPT, ['cost' => 10]);
    $user = $conn->real_escape_string($admin['nombre_usuario']);

    $sql  = "UPDATE clientes SET password = '$hash' WHERE nombre_usuario = '$user'";
    $ok   = $conn->query($sql);
    $rows = $conn->affected_rows;

    if ($ok && $rows > 0) {
        echo "✅ Usuario <strong>{$admin['nombre_usuario']}</strong> → hash actualizado correctamente.\n";
    } elseif ($ok && $rows === 0) {
        echo "⚠️  Usuario <strong>{$admin['nombre_usuario']}</strong> → no encontrado en la BD. ¿Ya importaste el SQL?\n";
        $todos_ok = false;
    } else {
        echo "❌ Error al actualizar <strong>{$admin['nombre_usuario']}</strong>: " . $conn->error . "\n";
        $todos_ok = false;
    }
}

echo "\n" . str_repeat("─", 50) . "\n";

if ($todos_ok) {
    echo "\n✅ <strong>¡Todo listo!</strong> Ahora puedes iniciar sesión con:\n\n";
    echo "   👤 Usuario: <strong>chino</strong>   🔑 Contraseña: <strong>aldo</strong>   🏷 Rol: admin\n";
    echo "   👤 Usuario: <strong>Fede</strong>    🔑 Contraseña: <strong>Fede</strong>   🏷 Rol: admin\n\n";
    echo "⚠️  <strong>IMPORTANTE:</strong> Elimina o renombra este archivo después de usarlo.\n";
} else {
    echo "\n⚠️  Algunos usuarios no se pudieron actualizar. Revisa los errores arriba.\n";
}

echo "</pre>";
$conn->close();
?>

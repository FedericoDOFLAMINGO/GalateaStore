<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 *
 * admin/gestionar_pedidos.php — Admin gestiona todos los pedidos y estados de entrega
 */

session_start();
include __DIR__ . '/../db.php';
include __DIR__ . '/../seguridad/auth.php';
requireRole('admin');

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'admin') {
    header("Location: ../login.php");
    exit;
}

$admin_nombre = $_SESSION['usuario']['nombre_usuario'] ?? 'admin';
$msg_ok  = "";
$msg_err = "";

// ── Procesar acciones del admin ───────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pedido_id = intval($_POST['pedido_id'] ?? 0);

    // Verificar que el pedido exista
    $chk = $conn->prepare("SELECT id, estado, cliente_id FROM pedidos WHERE id=?");
    $chk->bind_param("i", $pedido_id);
    $chk->execute();
    $ped = $chk->get_result()->fetch_assoc();
    $chk->close();

    if (!$ped) {
        $msg_err = "Pedido #$pedido_id no encontrado.";
    } else {
        $estado_previo = $ped['estado'];
        $action = $_POST['action'] ?? '';

        // ── Confirmar pago del producto ──────────────────────────────
        if ($action === 'confirmar_pago') {
            $upd = $conn->prepare("UPDATE pedidos SET estado='pagado' WHERE id=?");
            $upd->bind_param("i", $pedido_id);
            $upd->execute(); $upd->close();
            registrar_historial($conn, $pedido_id, $estado_previo, 'pagado', $admin_nombre, 'Admin confirmó el pago del producto.');
            $msg_ok = "Pedido #$pedido_id marcado como pagado.";

        // ── Registrar costo de envío cotizado ────────────────────────
        } elseif ($action === 'cotizar_envio') {
            $costo = floatval($_POST['costo_envio'] ?? 0);
            $notas = trim($_POST['notas_admin'] ?? '');
            if ($costo <= 0) {
                $msg_err = "El costo del envío debe ser mayor a $0.";
            } else {
                $upd = $conn->prepare("UPDATE pedidos SET costo_envio=?, estado='envio_cotizado', notas_admin=? WHERE id=?");
                $upd->bind_param("dsi", $costo, $notas, $pedido_id);
                $upd->execute(); $upd->close();
                registrar_historial($conn, $pedido_id, $estado_previo, 'envio_cotizado', $admin_nombre, "Costo envío cotizado: \$$costo. $notas");
                $msg_ok = "Costo de envío registrado para pedido #$pedido_id.";
            }

        // ── Confirmar pago del envío ─────────────────────────────────
        } elseif ($action === 'confirmar_pago_envio') {
            $upd = $conn->prepare("UPDATE pedidos SET estado='envio_pagado' WHERE id=?");
            $upd->bind_param("i", $pedido_id);
            $upd->execute(); $upd->close();
            registrar_historial($conn, $pedido_id, $estado_previo, 'envio_pagado', $admin_nombre, 'Admin confirmó el pago del envío.');
            $msg_ok = "Pago de envío confirmado para pedido #$pedido_id.";

        // ── Marcar en camino ─────────────────────────────────────────
        } elseif ($action === 'en_camino') {
            $guia = trim($_POST['num_guia'] ?? '');
            $nota = 'Pedido enviado.' . ($guia ? " Guía: $guia" : '');
            $upd = $conn->prepare("UPDATE pedidos SET estado='en_camino', notas_admin=? WHERE id=?");
            $upd->bind_param("si", $nota, $pedido_id);
            $upd->execute(); $upd->close();
            registrar_historial($conn, $pedido_id, $estado_previo, 'en_camino', $admin_nombre, $nota);
            $msg_ok = "Pedido #$pedido_id marcado como EN CAMINO.";

        // ── Marcar entregado ─────────────────────────────────────────
        } elseif ($action === 'entregado') {
            $upd = $conn->prepare("UPDATE pedidos SET estado='entregado' WHERE id=?");
            $upd->bind_param("i", $pedido_id);
            $upd->execute(); $upd->close();
            registrar_historial($conn, $pedido_id, $estado_previo, 'entregado', $admin_nombre, 'Pedido entregado al cliente.');
            $msg_ok = "Pedido #$pedido_id marcado como ENTREGADO.";

        // ── Cancelar ─────────────────────────────────────────────────
        } elseif ($action === 'cancelar') {
            $motivo = trim($_POST['motivo_cancelacion'] ?? '');
            $upd = $conn->prepare("UPDATE pedidos SET estado='cancelado', notas_admin=? WHERE id=?");
            $upd->bind_param("si", $motivo, $pedido_id);
            $upd->execute(); $upd->close();
            registrar_historial($conn, $pedido_id, $estado_previo, 'cancelado', $admin_nombre, "Cancelado: $motivo");
            $msg_ok = "Pedido #$pedido_id cancelado.";

        // ── Marcar recogida en tienda lista ──────────────────────────
        } elseif ($action === 'entregado_tienda') {
            $upd = $conn->prepare("UPDATE pedidos SET estado='entregado' WHERE id=?");
            $upd->bind_param("i", $pedido_id);
            $upd->execute(); $upd->close();
            registrar_historial($conn, $pedido_id, $estado_previo, 'entregado', $admin_nombre, 'Recogido en tienda.');
            $msg_ok = "Pedido #$pedido_id marcado como entregado en tienda.";
        }
    }
}

function registrar_historial($conn, $pedido_id, $estado_previo, $estado_nuevo, $por, $nota) {
    $h = $conn->prepare(
        "INSERT INTO pedidos_historial (pedido_id, estado_previo, estado_nuevo, cambiado_por, nota) VALUES (?,?,?,?,?)"
    );
    $h->bind_param("issss", $pedido_id, $estado_previo, $estado_nuevo, $por, $nota);
    $h->execute();
    $h->close();
}

// ── Filtros ────────────────────────────────────────────────────────────
$filtro_estado = trim($_GET['estado'] ?? '');
$filtro_buscar = trim($_GET['buscar'] ?? '');

$where = "WHERE 1=1";
$params = [];
$types  = "";
if ($filtro_estado) { $where .= " AND p.estado = ?"; $params[] = $filtro_estado; $types .= "s"; }
if ($filtro_buscar) { $where .= " AND (c.nombre_usuario LIKE ? OR p.id = ? OR pr.nombre_producto LIKE ?)";
    $like = "%$filtro_buscar%";
    $num  = intval($filtro_buscar);
    $params[] = $like; $params[] = $num; $params[] = $like;
    $types .= "sis";
}

$sql = "SELECT p.*, c.nombre_usuario, c.email, pr.nombre_producto, pr.imagen_url, pr.precio
        FROM pedidos p
        JOIN clientes c  ON p.cliente_id  = c.id
        JOIN preventas pr ON p.preventa_id = pr.id
        $where
        ORDER BY p.fecha_pedido DESC";

$stmt = $conn->prepare($sql);
if ($params) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$pedidos = $stmt->get_result();
$stmt->close();

// Contadores rápidos
function contar($conn, $estado) {
    $r = $conn->query("SELECT COUNT(*) as n FROM pedidos WHERE estado='$estado'");
    return $r ? $r->fetch_assoc()['n'] : 0;
}

$cnt = [
    'pendiente_pago'       => contar($conn,'pendiente_pago'),
    'pagado'               => contar($conn,'pagado'),
    'pendiente_pago_envio' => contar($conn,'pendiente_pago_envio'),
    'envio_cotizado'       => contar($conn,'envio_cotizado'),
    'envio_pagado'         => contar($conn,'envio_pagado'),
    'en_camino'            => contar($conn,'en_camino'),
    'recogida_en_tienda'   => contar($conn,'recogida_en_tienda'),
];

function badge_estado(string $e): array {
    return match($e) {
        'pendiente_pago'        => ['⏳ Pendiente pago',       '#c8982a'],
        'pagado'                => ['✅ Pagado',                '#4caf6a'],
        'pendiente_tipo_entrega'=> ['📦 Elige entrega',        '#4caf6a'],
        'recogida_en_tienda'    => ['🏪 Recoger tienda',       '#5ba4e6'],
        'pendiente_pago_envio'  => ['🚚 Cotizar envío',        '#e6a03a'],
        'envio_cotizado'        => ['💰 Envío cotizado',       '#e6a03a'],
        'envio_pagado'          => ['🧾 Envío pagado',         '#5ba4e6'],
        'en_camino'             => ['🚀 En camino',             '#4caf6a'],
        'entregado'             => ['🎉 Entregado',             '#4caf6a'],
        'cancelado'             => ['❌ Cancelado',              '#e55'],
        default                 => ['❓ '.$e,                   '#999'],
    };
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestionar Pedidos — Admin | One Piece Preventas</title>
  <link rel="stylesheet" href="../css/estilos.css">
  <link rel="stylesheet" href="../css/animations.css">
  <style>
    /* ── Tarjetas resumen ── */
    .cnt-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
      gap: 12px;
      margin-bottom: 28px;
    }
    .cnt-card {
      background: rgba(30,20,10,.7);
      border: 1.5px solid rgba(247,214,122,.2);
      border-radius: 12px;
      padding: 14px 12px;
      text-align: center;
      cursor: pointer;
      transition: border-color .2s, transform .15s;
      text-decoration: none;
      display: block;
    }
    .cnt-card:hover { border-color: rgba(247,214,122,.5); transform: translateY(-2px); }
    .cnt-card .num { font-size: 1.8rem; font-weight: 800; color: var(--gold-bright); }
    .cnt-card .lbl { font-size: .75rem; color: rgba(247,214,122,.65); margin-top: 4px; }

    /* ── Filtros ── */
    .filtros-wrap {
      display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px;
      background: rgba(30,20,10,.6);
      border: 1px solid rgba(247,214,122,.15);
      border-radius: 12px;
      padding: 14px 16px;
    }
    .filtros-wrap input,
    .filtros-wrap select {
      background: rgba(255,255,255,.07);
      border: 1px solid rgba(247,214,122,.25);
      color: #fff;
      border-radius: 8px;
      padding: 9px 14px;
      font-size: .88rem;
      flex: 1; min-width: 160px;
    }
    .filtros-wrap select option { background: #2a1a0d; }
    .filtros-wrap button {
      padding: 9px 20px;
      background: var(--gold-bright);
      color: var(--dark-brown);
      font-weight: 700;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }

    /* ── Pedido card ── */
    .pedido-card {
      background: rgba(30,20,10,.75);
      border: 1.5px solid rgba(247,214,122,.18);
      border-radius: 16px;
      margin-bottom: 20px;
      overflow: hidden;
      transition: border-color .2s;
    }
    .pedido-card:hover { border-color: rgba(247,214,122,.4); }

    .pedido-head {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 16px 20px;
      background: rgba(0,0,0,.2);
      flex-wrap: wrap;
    }
    .pedido-head img {
      width: 56px; height: 56px;
      object-fit: cover;
      border-radius: 8px;
      border: 1px solid rgba(247,214,122,.25);
    }
    .pedido-head-info { flex: 1; min-width: 120px; }
    .pedido-head-info h3 {
      font-family: 'Pirata One', serif;
      color: var(--gold-bright);
      margin: 0 0 4px;
      font-size: 1rem;
    }
    .pedido-head-info small { color: rgba(247,214,122,.5); font-size: .78rem; }

    .estado-badge {
      padding: 5px 14px;
      border-radius: 20px;
      font-size: .78rem;
      font-weight: 700;
      color: #fff;
    }

    .pedido-body { padding: 18px 20px; }

    .info-row { display: flex; gap: 8px; font-size: .84rem; color: rgba(247,214,122,.7); margin: 3px 0; }
    .info-row strong { color: #fff; }

    /* Acciones */
    .acciones-wrap { margin-top: 16px; display: flex; flex-wrap: wrap; gap: 10px; align-items: flex-start; }

    .action-form { display: inline-flex; flex-direction: column; gap: 6px; }
    .action-form input[type=number],
    .action-form input[type=text],
    .action-form textarea {
      background: rgba(255,255,255,.08);
      border: 1px solid rgba(247,214,122,.3);
      color: #fff;
      border-radius: 8px;
      padding: 7px 12px;
      font-size: .83rem;
      min-width: 180px;
    }

    .btn-acc {
      padding: 9px 18px;
      border-radius: 9px;
      border: none;
      cursor: pointer;
      font-size: .85rem;
      font-weight: 700;
      transition: opacity .2s;
    }
    .btn-acc:hover { opacity: .85; }
    .btn-verde  { background: #2d9348; color: #fff; }
    .btn-azul   { background: #2979b8; color: #fff; }
    .btn-naranja{ background: #c87820; color: #fff; }
    .btn-rojo   { background: #b83228; color: #fff; }
    .btn-wa     { background: #25D366; color: #fff; }

    .sep { width: 100%; border: none; border-top: 1px solid rgba(247,214,122,.1); margin: 12px 0; }

    .section-head {
      font-family: 'Pirata One', serif;
      color: var(--gold-bright);
      font-size: 1.35rem;
      margin: 28px 0 14px;
      border-bottom: 1.5px solid rgba(247,214,122,.2);
      padding-bottom: 8px;
    }

    .msg-ok  { background:rgba(80,200,100,.15); border:1.5px solid rgba(80,200,100,.4); color:#7ee8a0; padding:14px 18px; border-radius:10px; margin:14px 0; }
    .msg-err { background:rgba(220,60,60,.15);  border:1.5px solid rgba(220,60,60,.4);  color:#f88;    padding:14px 18px; border-radius:10px; margin:14px 0; }

    .envio-detalle {
      background: rgba(60,100,180,.08);
      border: 1px solid rgba(60,100,180,.25);
      border-radius: 10px;
      padding: 12px 16px;
      margin: 10px 0;
      font-size: .84rem;
    }
    .envio-detalle h5 { margin: 0 0 8px; color: #7ec8f8; }

    .comp-link {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      background: rgba(247,214,122,.1);
      border: 1px solid rgba(247,214,122,.3);
      color: var(--gold-bright);
      border-radius: 8px;
      padding: 6px 12px;
      text-decoration: none;
      font-size: .82rem;
    }
    .comp-link:hover { background: rgba(247,214,122,.2); }
  </style>
</head>
<body class="dashboard-body">

<?php include '../navbar.php'; ?>
<?php
include '../breadcrumbs.php';
$bc = [
  'Inicio' => '/dashboard.php',
  'Admin'  => '/admin/panel_admin.php',
  'Gestionar Pedidos' => ''
];
generarBreadcrumbs($bc);
?>

<div class="page-content">
  <h1 class="page-title">📋 Gestionar Pedidos</h1>

  <?php if ($msg_ok): ?>
    <div class="msg-ok">✅ <?php echo htmlspecialchars($msg_ok); ?></div>
  <?php endif; ?>
  <?php if ($msg_err): ?>
    <div class="msg-err">❌ <?php echo htmlspecialchars($msg_err); ?></div>
  <?php endif; ?>

  <!-- ── Contadores ── -->
  <div class="cnt-grid">
    <a class="cnt-card" href="?estado=pendiente_pago">
      <div class="num"><?php echo $cnt['pendiente_pago']; ?></div>
      <div class="lbl">⏳ Pendiente pago</div>
    </a>
    <a class="cnt-card" href="?estado=pagado">
      <div class="num"><?php echo $cnt['pagado']; ?></div>
      <div class="lbl">✅ Pagados</div>
    </a>
    <a class="cnt-card" href="?estado=pendiente_pago_envio">
      <div class="num"><?php echo $cnt['pendiente_pago_envio']; ?></div>
      <div class="lbl">🚚 Cotizar envío</div>
    </a>
    <a class="cnt-card" href="?estado=envio_cotizado">
      <div class="num"><?php echo $cnt['envio_cotizado']; ?></div>
      <div class="lbl">💰 Envío cotizado</div>
    </a>
    <a class="cnt-card" href="?estado=envio_pagado">
      <div class="num"><?php echo $cnt['envio_pagado']; ?></div>
      <div class="lbl">🧾 Envío pagado</div>
    </a>
    <a class="cnt-card" href="?estado=en_camino">
      <div class="num"><?php echo $cnt['en_camino']; ?></div>
      <div class="lbl">🚀 En camino</div>
    </a>
    <a class="cnt-card" href="?estado=recogida_en_tienda">
      <div class="num"><?php echo $cnt['recogida_en_tienda']; ?></div>
      <div class="lbl">🏪 Tienda</div>
    </a>
    <a class="cnt-card" href="gestionar_pedidos.php" style="border-style:dashed;">
      <div class="num" style="font-size:1.3rem;">🔄</div>
      <div class="lbl">Ver todos</div>
    </a>
  </div>

  <!-- ── Filtros ── -->
  <form method="GET" class="filtros-wrap">
    <input type="text" name="buscar" value="<?php echo htmlspecialchars($filtro_buscar); ?>"
           placeholder="Buscar por #ID, usuario o producto…">
    <select name="estado">
      <option value="">— Todos los estados —</option>
      <?php
      $estados_ops = [
        'pendiente_pago'       => '⏳ Pendiente pago',
        'pagado'               => '✅ Pagado',
        'pendiente_tipo_entrega'=> '📦 Elige entrega',
        'recogida_en_tienda'   => '🏪 Recoger en tienda',
        'pendiente_pago_envio' => '🚚 Cotizar envío',
        'envio_cotizado'       => '💰 Envío cotizado',
        'envio_pagado'         => '🧾 Envío pagado',
        'en_camino'            => '🚀 En camino',
        'entregado'            => '🎉 Entregado',
        'cancelado'            => '❌ Cancelado',
      ];
      foreach ($estados_ops as $val => $lbl):
        $sel = $filtro_estado === $val ? 'selected' : '';
      ?>
        <option value="<?php echo $val; ?>" <?php echo $sel; ?>><?php echo $lbl; ?></option>
      <?php endforeach; ?>
    </select>
    <button type="submit">🔍 Filtrar</button>
    <?php if ($filtro_estado || $filtro_buscar): ?>
      <a href="gestionar_pedidos.php" style="padding:9px 16px;color:rgba(247,214,122,.7);text-decoration:none;font-size:.85rem;align-self:center;">✕ Limpiar</a>
    <?php endif; ?>
  </form>

  <!-- ── Lista de pedidos ── -->
  <div class="section-head">
    📦 Pedidos
    <?php if ($filtro_estado || $filtro_buscar): ?>
      <small style="font-family:sans-serif;font-size:.8rem;font-weight:400;color:rgba(247,214,122,.5);">
        (filtrado)
      </small>
    <?php endif; ?>
  </div>

  <?php if ($pedidos->num_rows === 0): ?>
    <div style="text-align:center;padding:40px;color:rgba(247,214,122,.45);">No hay pedidos con esos filtros.</div>
  <?php else: ?>
    <?php while ($p = $pedidos->fetch_assoc()):
      [$label_est, $color_est] = badge_estado($p['estado'] ?? 'pendiente_pago');
      $subtotal = ($p['precio'] ?? 0) * ($p['cantidad'] ?? 1);
      $wa_cliente = '';
      if ($p['env_telefono']) {
          $num = preg_replace('/\D/', '', $p['env_telefono']);
          if (strlen($num) === 10) $num = '52' . $num;
          $wa_cliente = "https://wa.me/$num";
      }
    ?>
    <div class="pedido-card">

      <!-- Cabecera -->
      <div class="pedido-head">
        <img src="<?php echo htmlspecialchars($p['imagen_url'] ?? ''); ?>"
             alt="" onerror="this.src='../img/op13.jpeg'">
        <div class="pedido-head-info">
          <h3>#<?php echo $p['id']; ?> — <?php echo htmlspecialchars($p['nombre_producto']); ?></h3>
          <small>
            👤 <?php echo htmlspecialchars($p['nombre_usuario']); ?>
            (<?php echo htmlspecialchars($p['email']); ?>) ·
            📅 <?php echo date('d/m/Y H:i', strtotime($p['fecha_pedido'])); ?>
          </small>
        </div>
        <span class="estado-badge" style="background:<?php echo $color_est; ?>22;color:<?php echo $color_est; ?>;border:1px solid <?php echo $color_est; ?>55;">
          <?php echo $label_est; ?>
        </span>
      </div>

      <!-- Cuerpo -->
      <div class="pedido-body">
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px;margin-bottom:10px;">
          <div class="info-row">Cantidad: <strong><?php echo $p['cantidad']; ?> ud.</strong></div>
          <div class="info-row">Subtotal: <strong>$<?php echo number_format($subtotal, 2); ?> MXN</strong></div>
          <div class="info-row">Entrega: <strong><?php echo $p['tipo_entrega'] ?: 'sin definir'; ?></strong></div>
          <?php if ($p['costo_envio']): ?>
            <div class="info-row">Costo envío: <strong>$<?php echo number_format($p['costo_envio'], 2); ?> MXN</strong></div>
          <?php endif; ?>
        </div>

        <!-- Comprobantes -->
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px;">
          <?php if ($p['comprobante_pago']): ?>
            <a class="comp-link" href="../uploads/comprobantes/<?php echo htmlspecialchars($p['comprobante_pago']); ?>" target="_blank">
              📄 Comprobante producto
            </a>
          <?php endif; ?>
          <?php if ($p['comprobante_envio']): ?>
            <a class="comp-link" href="../uploads/comprobantes/<?php echo htmlspecialchars($p['comprobante_envio']); ?>" target="_blank">
              📄 Comprobante envío
            </a>
          <?php endif; ?>
        </div>

        <!-- Datos de envío si aplica -->
        <?php if ($p['tipo_entrega'] === 'envio' && $p['env_nombre']): ?>
          <div class="envio-detalle">
            <h5>📦 Datos de envío</h5>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:5px;">
              <div class="info-row">Destinatario: <strong><?php echo htmlspecialchars($p['env_nombre']); ?></strong></div>
              <div class="info-row">Tel: <strong><?php echo htmlspecialchars($p['env_telefono']); ?></strong></div>
              <div class="info-row">Estado: <strong><?php echo htmlspecialchars($p['env_estado']); ?></strong></div>
              <div class="info-row">Ciudad: <strong><?php echo htmlspecialchars($p['env_ciudad']); ?></strong></div>
              <div class="info-row">Dir: <strong><?php echo htmlspecialchars($p['env_calle'] . ' ' . $p['env_colonia']); ?></strong></div>
              <div class="info-row">CP: <strong><?php echo htmlspecialchars($p['env_cp']); ?></strong></div>
              <div class="info-row">Paquetería: <strong><?php echo htmlspecialchars($p['env_paqueteria'] ?? '—'); ?></strong></div>
              <?php if ($p['env_referencias']): ?>
                <div class="info-row" style="grid-column:1/-1;">Refs: <strong><?php echo htmlspecialchars($p['env_referencias']); ?></strong></div>
              <?php endif; ?>
            </div>
            <?php if ($wa_cliente): ?>
              <a href="<?php echo $wa_cliente; ?>?text=Hola%20<?php echo urlencode($p['env_nombre']); ?>%2C%20te%20contactamos%20sobre%20tu%20pedido%20%23<?php echo $p['id']; ?>"
                 target="_blank" class="btn-acc btn-wa" style="display:inline-flex;align-items:center;gap:5px;margin-top:8px;text-decoration:none;font-size:.82rem;">
                📲 WhatsApp al cliente
              </a>
            <?php endif; ?>
          </div>
        <?php endif; ?>

        <?php if ($p['notas_admin']): ?>
          <div style="background:rgba(247,214,122,.06);border-radius:8px;padding:9px 14px;font-size:.82rem;color:rgba(247,214,122,.7);margin-bottom:10px;">
            📝 Nota: <?php echo htmlspecialchars($p['notas_admin']); ?>
          </div>
        <?php endif; ?>

        <hr class="sep">

        <!-- ══ ACCIONES SEGÚN ESTADO ══ -->
        <div class="acciones-wrap">

          <?php $est = $p['estado'] ?? ''; ?>

          <!-- Confirmar pago del producto -->
          <?php if ($est === 'pendiente_pago'): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="confirmar_pago">
              <button type="submit" class="btn-acc btn-verde"
                      onclick="return confirm('¿Confirmar que el pago del producto fue recibido?')">
                ✅ Confirmar pago del producto
              </button>
            </form>
          <?php endif; ?>

          <!-- Registrar costo de envío -->
          <?php if ($est === 'pendiente_pago_envio'): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="cotizar_envio">
              <label style="font-size:.8rem;color:rgba(247,214,122,.7);">Costo de envío (MXN) *</label>
              <input type="number" name="costo_envio" placeholder="Ej: 150" step="0.01" min="1" required>
              <input type="text" name="notas_admin" placeholder="Nota para el cliente (opcional)">
              <button type="submit" class="btn-acc btn-naranja">💰 Registrar costo de envío</button>
            </form>
            <?php if ($wa_cliente): ?>
              <a href="<?php echo $wa_cliente; ?>?text=Hola%20<?php echo urlencode($p['env_nombre'] ?? ''); ?>%2C%20tu%20env%C3%ADo%20para%20el%20pedido%20%23<?php echo $p['id']; ?>%20(<?php echo urlencode($p['nombre_producto']); ?>)%20tiene%20un%20costo%20de%20%24___MXN%20por%20<?php echo urlencode($p['env_paqueteria'] ?? 'paquetería'); ?>.%20%C2%BFConfirmamos%3F"
                 target="_blank" class="btn-acc btn-wa" style="text-decoration:none;">
                📲 Notificar cliente por WA
              </a>
            <?php endif; ?>
          <?php endif; ?>

          <!-- Confirmar pago de envío -->
          <?php if ($est === 'envio_cotizado'): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="confirmar_pago_envio">
              <button type="submit" class="btn-acc btn-azul"
                      onclick="return confirm('¿Confirmar pago de envío recibido?')">
                🧾 Confirmar pago de envío
              </button>
            </form>
          <?php endif; ?>

          <!-- Marcar en camino -->
          <?php if ($est === 'envio_pagado'): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="en_camino">
              <input type="text" name="num_guia" placeholder="Número de guía (opcional)">
              <button type="submit" class="btn-acc btn-azul">🚀 Marcar como EN CAMINO</button>
            </form>
          <?php endif; ?>

          <!-- Recoger en tienda → Entregado -->
          <?php if ($est === 'recogida_en_tienda'): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="entregado_tienda">
              <button type="submit" class="btn-acc btn-verde"
                      onclick="return confirm('¿Confirmar que el cliente recogió en tienda?')">
                🏪 Confirmar recogida en tienda
              </button>
            </form>
          <?php endif; ?>

          <!-- Marcar entregado (envío) -->
          <?php if ($est === 'en_camino'): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="entregado">
              <button type="submit" class="btn-acc btn-verde"
                      onclick="return confirm('¿Confirmar entrega al cliente?')">
                🎉 Marcar como ENTREGADO
              </button>
            </form>
          <?php endif; ?>

          <!-- Cancelar (cualquier estado activo) -->
          <?php if (!in_array($est, ['entregado','cancelado'])): ?>
            <form method="POST" class="action-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="cancelar">
              <input type="text" name="motivo_cancelacion" placeholder="Motivo (opcional)">
              <button type="submit" class="btn-acc btn-rojo"
                      onclick="return confirm('¿Cancelar pedido #<?php echo $p['id']; ?>?')">
                ❌ Cancelar pedido
              </button>
            </form>
          <?php endif; ?>

        </div><!-- /acciones-wrap -->
      </div><!-- /pedido-body -->
    </div><!-- /pedido-card -->
    <?php endwhile; ?>
  <?php endif; ?>

</div><!-- /page-content -->

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="../js/menu-scripts.js"></script>
</body>
</html>

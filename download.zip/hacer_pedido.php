<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 *
 * hacer_pedido.php — El usuario paga primero, después elige entrega
 */

session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';
requireRole('cliente');

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

$cliente_id = $_SESSION['usuario']['id'];
$preventa_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($preventa_id <= 0) {
    header("Location: preventas_activas.php");
    exit;
}

// Obtener preventa
$stmt = $conn->prepare("SELECT * FROM preventas WHERE id = ? AND activo = 1");
$stmt->bind_param("i", $preventa_id);
$stmt->execute();
$preventa = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$preventa) {
    header("Location: preventas_activas.php");
    exit;
}

$msg_ok  = "";
$msg_err = "";

// ── Procesar pedido ────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cantidad   = max(1, intval($_POST['cantidad'] ?? 1));
    $comprobante_nombre = null;

    // Validar stock
    if ($cantidad > $preventa['stock_disponible']) {
        $msg_err = "No hay suficiente stock disponible.";
    } else {
        // Subir comprobante de pago (opcional al hacer el pedido)
        if (isset($_FILES['comprobante']) && $_FILES['comprobante']['error'] === UPLOAD_ERR_OK) {
            $ext_permitidas = ['jpg','jpeg','png','pdf','webp'];
            $ext = strtolower(pathinfo($_FILES['comprobante']['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, $ext_permitidas)) {
                $msg_err = "Formato de comprobante no válido. Usa JPG, PNG o PDF.";
            } elseif ($_FILES['comprobante']['size'] > 5 * 1024 * 1024) {
                $msg_err = "El archivo es muy grande (máx. 5 MB).";
            } else {
                $dir = __DIR__ . '/uploads/comprobantes/';
                if (!is_dir($dir)) mkdir($dir, 0755, true);
                $comprobante_nombre = 'pago_' . $cliente_id . '_' . time() . '.' . $ext;
                move_uploaded_file($_FILES['comprobante']['tmp_name'], $dir . $comprobante_nombre);
            }
        }

        if (!$msg_err) {
            // Verificar que no tenga ya un pedido activo de esta preventa
            $chk = $conn->prepare(
                "SELECT id FROM pedidos WHERE cliente_id=? AND preventa_id=? AND estado NOT IN ('cancelado','entregado') LIMIT 1"
            );
            $chk->bind_param("ii", $cliente_id, $preventa_id);
            $chk->execute();
            $ya_existe = $chk->get_result()->fetch_assoc();
            $chk->close();

            if ($ya_existe) {
                $msg_err = "Ya tienes un pedido activo para esta preventa.";
            } else {
                $ins = $conn->prepare(
                    "INSERT INTO pedidos (cliente_id, preventa_id, cantidad, estado, comprobante_pago, fecha_pedido)
                     VALUES (?, ?, ?, 'pagado', ?, NOW())"
                );
                $ins->bind_param("iiis", $cliente_id, $preventa_id, $cantidad, $comprobante_nombre);
                if ($ins->execute()) {
                    // Reducir stock
                    $conn->query("UPDATE preventas SET stock_disponible = stock_disponible - $cantidad WHERE id = $preventa_id");
                    $msg_ok = "¡Pedido registrado! Ahora ve a <strong>Mis Pedidos</strong> para elegir cómo recibir tu producto.";
                } else {
                    $msg_err = "Error al registrar el pedido. Intenta de nuevo.";
                }
                $ins->close();
            }
        }
    }
}

$precio_total_base = $preventa['precio'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hacer Pedido — <?php echo htmlspecialchars($preventa['nombre_producto']); ?></title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
  <style>
    /* ── Sección de pago ── */
    .pago-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin: 20px 0;
    }
    .pago-card {
      background: rgba(30,20,10,0.7);
      border: 1.5px solid rgba(247,214,122,0.25);
      border-radius: 14px;
      padding: 18px 16px;
      transition: border-color .2s;
    }
    .pago-card:hover { border-color: var(--gold); }
    .pago-card h4 {
      font-family: 'Pirata One', serif;
      color: var(--gold-bright);
      margin: 0 0 10px;
      font-size: 1rem;
    }
    .pago-card .dato {
      font-size: 0.88rem;
      color: rgba(247,214,122,0.85);
      margin: 4px 0;
    }
    .pago-card .dato strong {
      color: #fff;
      display: block;
      font-size: 1rem;
      letter-spacing: .5px;
    }
    .pago-icon { font-size: 1.6rem; margin-bottom: 8px; display: block; }

    /* ── Formulario de pedido ── */
    .pedido-wrap {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 28px;
      align-items: start;
    }
    @media(max-width:680px){ .pedido-wrap { grid-template-columns:1fr; } }

    .product-preview {
      background: rgba(30,20,10,0.7);
      border: 1.5px solid rgba(247,214,122,0.25);
      border-radius: 14px;
      padding: 24px;
      text-align: center;
    }
    .product-preview img {
      max-width: 200px;
      border-radius: 12px;
      border: 2px solid var(--gold);
      margin-bottom: 14px;
    }
    .product-preview .precio-badge {
      background: var(--gold-bright);
      color: var(--dark-brown);
      font-weight: 800;
      font-size: 1.3rem;
      border-radius: 8px;
      padding: 6px 18px;
      display: inline-block;
      margin: 10px 0;
    }

    .form-box {
      background: rgba(30,20,10,0.7);
      border: 1.5px solid rgba(247,214,122,0.25);
      border-radius: 14px;
      padding: 28px 24px;
    }
    .form-box label {
      display: block;
      color: var(--gold-bright);
      font-size: .88rem;
      margin-bottom: 6px;
      font-weight: 600;
    }
    .form-box input[type=file],
    .form-box textarea {
      width: 100%;
      background: rgba(255,255,255,.07);
      border: 1px solid rgba(247,214,122,.3);
      color: #fff;
      border-radius: 8px;
      padding: 10px 12px;
      font-size: .92rem;
      margin-bottom: 16px;
    }

    /* Contador cantidad */
    .qty-wrap {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 16px;
    }
    .qty-btn {
      width: 36px; height: 36px;
      background: rgba(247,214,122,.15);
      border: 1.5px solid rgba(247,214,122,.4);
      color: var(--gold-bright);
      font-size: 1.2rem;
      border-radius: 8px;
      cursor: pointer;
      display: flex; align-items: center; justify-content: center;
      transition: background .15s;
    }
    .qty-btn:hover { background: rgba(247,214,122,.3); }
    .qty-display {
      font-size: 1.4rem;
      font-weight: 800;
      color: #fff;
      min-width: 36px;
      text-align: center;
    }

    /* Total */
    .total-line {
      background: rgba(247,214,122,.1);
      border: 1.5px solid rgba(247,214,122,.3);
      border-radius: 10px;
      padding: 12px 16px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    .total-line .label { color: rgba(247,214,122,.7); font-size:.9rem; }
    .total-line .amount {
      color: var(--gold-bright);
      font-size: 1.5rem;
      font-weight: 800;
    }

    .btn-submit {
      width: 100%;
      padding: 14px;
      background: var(--gold-bright);
      color: var(--dark-brown);
      font-weight: 800;
      font-size: 1rem;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: opacity .2s, transform .15s;
    }
    .btn-submit:hover { opacity: .9; transform: translateY(-1px); }

    /* Aviso importante */
    .aviso-box {
      background: rgba(247,214,122,.08);
      border-left: 4px solid var(--gold-bright);
      border-radius: 0 10px 10px 0;
      padding: 14px 18px;
      margin: 20px 0;
      font-size: .9rem;
      color: rgba(247,214,122,.9);
    }
    .aviso-box strong { color: #fff; }

    /* Mensajes */
    .msg-ok  { background:rgba(80,200,100,.15); border:1.5px solid rgba(80,200,100,.4); color:#7ee8a0; padding:14px 18px; border-radius:10px; margin:16px 0; }
    .msg-err { background:rgba(220,60,60,.15);  border:1.5px solid rgba(220,60,60,.4);  color:#f88;    padding:14px 18px; border-radius:10px; margin:16px 0; }

    .section-title {
      font-family: 'Pirata One', serif;
      color: var(--gold-bright);
      font-size: 1.4rem;
      margin: 32px 0 14px;
      border-bottom: 1.5px solid rgba(247,214,122,.2);
      padding-bottom: 8px;
    }
  </style>
</head>
<body class="dashboard-body">

<?php include 'navbar.php'; ?>
<?php
include 'breadcrumbs.php';
$bc = [
  'Inicio'   => '/dashboard.php',
  'Preventas' => '/preventas_activas.php',
  'Hacer Pedido' => ''
];
generarBreadcrumbs($bc);
?>

<div class="page-content">
  <h1 class="page-title">🛒 Hacer Pedido</h1>

  <?php if ($msg_ok): ?>
    <div class="msg-ok">✅ <?php echo $msg_ok; ?>
      <br><a href="mis_pedidos.php" style="color:var(--gold-bright);font-weight:700;">→ Ir a Mis Pedidos</a>
    </div>
  <?php endif; ?>
  <?php if ($msg_err): ?>
    <div class="msg-err">❌ <?php echo htmlspecialchars($msg_err); ?></div>
  <?php endif; ?>

  <!-- ══ AVISO DE FLUJO ══ -->
  <div class="aviso-box">
    <strong>📋 ¿Cómo funciona?</strong><br>
    <strong>1.</strong> Paga el producto mediante uno de los métodos de abajo.<br>
    <strong>2.</strong> Llena este formulario y adjunta tu comprobante de pago.<br>
    <strong>3.</strong> En <strong>Mis Pedidos</strong> podrás elegir si recoges en tienda o quieres envío.<br>
    <strong>4.</strong> Si es envío, cotizamos el flete por WhatsApp antes de que pagues el paquete.
  </div>

  <!-- ══ MÉTODOS DE PAGO ══ -->
  <div class="section-title">💳 Métodos de Pago del Producto</div>

  <div class="pago-grid">

    <div class="pago-card">
      <span class="pago-icon">🏦</span>
      <h4>SPEI / Transferencia BBVA</h4>
      <div class="dato">CLABE Interbancaria
        <strong>012320001234567890</strong>
      </div>
      <div class="dato">Banco: BBVA</div>
      <div class="dato">Titular
        <strong>Fernando Ledesma</strong>
      </div>
      <div class="dato" style="margin-top:8px;font-size:.8rem;color:rgba(247,214,122,.5);">
        ⚠️ Cambia estos datos por los tuyos reales
      </div>
    </div>

    <div class="pago-card">
      <span class="pago-icon">📱</span>
      <h4>CoDi / OXXO Pay</h4>
      <div class="dato">Número de celular (CoDi)
        <strong>449 105 9872</strong>
      </div>
      <div class="dato">OXXO Pay — Pide la referencia por WhatsApp antes de ir a pagar.</div>
      <div class="dato" style="margin-top:8px;">
        <a href="https://wa.me/524491059872?text=Hola%2C%20quiero%20la%20referencia%20OXXO%20para%20mi%20pedido%20de%20<?php echo urlencode($preventa['nombre_producto']); ?>"
           target="_blank"
           style="color:var(--gold-bright);font-size:.85rem;text-decoration:none;">
          📲 Pedir referencia OXXO →
        </a>
      </div>
    </div>

    <div class="pago-card">
      <span class="pago-icon">💸</span>
      <h4>PayPal</h4>
      <div class="dato">Cuenta
        <strong>pagos@tudominio.com</strong>
      </div>
      <div class="dato">Envía el pago como "amigos y familia" para evitar comisiones extra.</div>
      <div class="dato" style="margin-top:8px;font-size:.8rem;color:rgba(247,214,122,.5);">
        ⚠️ Cambia estos datos por los tuyos reales
      </div>
    </div>

  </div><!-- /pago-grid -->

  <!-- ══ FORMULARIO DE PEDIDO ══ -->
  <div class="section-title">📝 Registrar mi Pedido</div>

  <div class="pedido-wrap">

    <!-- Vista previa del producto -->
    <div class="product-preview">
      <img src="<?php echo htmlspecialchars($preventa['imagen_url'] ?? ''); ?>"
           alt="<?php echo htmlspecialchars($preventa['nombre_producto']); ?>"
           onerror="this.src='img/op13.jpeg'">
      <h3 style="font-family:'Pirata One',serif;color:var(--gold-bright);margin:8px 0;">
        <?php echo htmlspecialchars($preventa['nombre_producto']); ?>
      </h3>
      <p style="font-size:.88rem;color:rgba(247,214,122,.65);margin:0 0 12px;">
        <?php echo htmlspecialchars($preventa['descripcion'] ?? ''); ?>
      </p>
      <div class="precio-badge">
        $<?php echo number_format($preventa['precio'], 2); ?> MXN
      </div>
      <div style="font-size:.82rem;color:rgba(247,214,122,.5);margin-top:8px;">
        Stock disponible: <?php echo $preventa['stock_disponible']; ?> unidades
      </div>
    </div>

    <!-- Formulario -->
    <div class="form-box">
      <form method="POST" enctype="multipart/form-data">

        <label>Cantidad</label>
        <div class="qty-wrap">
          <button type="button" class="qty-btn" onclick="cambiarCantidad(-1)">−</button>
          <div class="qty-display" id="qty-display">1</div>
          <button type="button" class="qty-btn" onclick="cambiarCantidad(1)">+</button>
          <input type="hidden" name="cantidad" id="cantidad-hidden" value="1">
          <span style="color:rgba(247,214,122,.5);font-size:.82rem;">
            (máx. <?php echo $preventa['stock_disponible']; ?>)
          </span>
        </div>

        <div class="total-line">
          <span class="label">Total del producto</span>
          <span class="amount" id="total-display">
            $<?php echo number_format($preventa['precio'], 2); ?> MXN
          </span>
        </div>

        <label>📎 Adjuntar comprobante de pago <span style="font-weight:400;color:rgba(247,214,122,.5);">(recomendado)</span></label>
        <input type="file" name="comprobante" accept=".jpg,.jpeg,.png,.pdf,.webp">
        <div style="font-size:.78rem;color:rgba(247,214,122,.45);margin-top:-10px;margin-bottom:16px;">
          JPG, PNG o PDF · máx. 5 MB. Si no tienes el comprobante ahora, puedes subirlo después desde Mis Pedidos.
        </div>

        <div style="background:rgba(247,214,122,.06);border-radius:10px;padding:12px 14px;margin-bottom:18px;font-size:.83rem;color:rgba(247,214,122,.7);">
          ⚠️ <strong style="color:#fff;">Importante:</strong> Una vez confirmado tu pedido aparecerá en
          <strong>"Mis Pedidos"</strong> donde podrás elegir si lo recoges en tienda o necesitas envío.
          El costo del envío se cotiza por separado vía WhatsApp y se paga después.
        </div>

        <button type="submit" class="btn-submit">
          ✅ Confirmar Pedido
        </button>
      </form>
    </div>

  </div><!-- /pedido-wrap -->
</div><!-- /page-content -->

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="js/menu-scripts.js"></script>
<script>
const precioUnit = <?php echo floatval($preventa['precio']); ?>;
const stockMax   = <?php echo intval($preventa['stock_disponible']); ?>;
let qty = 1;

function cambiarCantidad(delta) {
  qty = Math.max(1, Math.min(stockMax, qty + delta));
  document.getElementById('qty-display').textContent = qty;
  document.getElementById('cantidad-hidden').value   = qty;
  const total = (precioUnit * qty).toLocaleString('es-MX', {minimumFractionDigits:2, maximumFractionDigits:2});
  document.getElementById('total-display').textContent = '$' + total + ' MXN';
}
</script>
</body>
</html>

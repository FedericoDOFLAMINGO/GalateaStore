/**
 * animations.js — Motor de animaciones y transiciones
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Implementa: IntersectionObserver, animaciones escalonadas,
 *             transiciones sin display:none, parallax mousemove,
 *             efecto magnético en botones, hover lift, throttle,
 *             requestAnimationFrame
 */
'use strict';

const OnePieceAnimations = (() => {

  // ── Throttle ──────────────────────────────────────────
  function throttle(fn, limit = 16) {
    let inThrottle = false;
    return function (...args) {
      if (!inThrottle) {
        fn.apply(this, args);
        inThrottle = true;
        setTimeout(() => { inThrottle = false; }, limit);
      }
    };
  }

  // ── Debounce ──────────────────────────────────────────
  function debounce(fn, delay = 300) {
    let timeoutId = null;
    return function (...args) {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => fn.apply(this, args), delay);
    };
  }

  // ═══════════════════════════════════════════════════
  // 1. ANIMACIONES CON SCROLL — IntersectionObserver
  // ═══════════════════════════════════════════════════

  function initScrollAnimations() {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const el = entry.target;
          const delay = el.dataset.animDelay || 0;

          // requestAnimationFrame para sincronizar con refresco
          requestAnimationFrame(() => {
            setTimeout(() => {
              el.classList.add('anim-visible');
            }, parseInt(delay));
          });

          observer.unobserve(el); // solo animar una vez
        }
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px',
    });

    // Seleccionar todos los elementos animables
    document.querySelectorAll(
      '.tarjeta-preventa, .quick-card, .form-card, ' +
      '.tabla-container, .perfil-card, .ayuda-section, ' +
      '.welcome-feature, [data-anim]'
    ).forEach((el, index) => {
      el.classList.add('anim-hidden');
      // Animaciones escalonadas: delay incremental por grupo
      if (!el.dataset.animDelay) {
        el.dataset.animDelay = (index % 6) * 80; // máx 480ms
      }
      observer.observe(el);
    });
  }

  // ═══════════════════════════════════════════════════
  // 2. MOSTRAR / OCULTAR SIN display:none
  // ═══════════════════════════════════════════════════

  // Mostrar con transición suave (opacity + translateY)
  function show(el, duration = 300) {
    if (!el) return;
    el.style.opacity = '0';
    el.style.transform = 'translateY(10px)';
    el.style.pointerEvents = 'none';
    el.style.transition = `opacity ${duration}ms ease, transform ${duration}ms ease`;

    // Forzar reflow antes de aplicar el estado final
    el.getBoundingClientRect();

    requestAnimationFrame(() => {
      el.style.opacity = '1';
      el.style.transform = 'translateY(0)';
      el.style.pointerEvents = '';
    });
  }

  // Ocultar con transición suave
  function hide(el, duration = 250, callback) {
    if (!el) return;
    el.style.transition = `opacity ${duration}ms ease, transform ${duration}ms ease`;
    el.style.opacity = '0';
    el.style.transform = 'translateY(8px)';
    el.style.pointerEvents = 'none';

    setTimeout(() => {
      if (callback) callback();
      el.style.pointerEvents = '';
    }, duration);
  }

  // Slide down: altura animada (para acordeones)
  function slideDown(el, duration = 300) {
    if (!el) return;
    el.style.overflow = 'hidden';
    el.style.height = '0';
    el.style.opacity = '0';
    el.style.transition = `height ${duration}ms ease, opacity ${duration}ms ease`;

    // Medir altura real
    const targetH = el.scrollHeight + 'px';

    requestAnimationFrame(() => {
      el.style.height = targetH;
      el.style.opacity = '1';
    });

    setTimeout(() => {
      el.style.height = '';
      el.style.overflow = '';
    }, duration);
  }

  // Slide up: colapsar con altura animada
  function slideUp(el, duration = 250) {
    if (!el) return;
    el.style.overflow = 'hidden';
    el.style.height = el.scrollHeight + 'px';
    el.style.transition = `height ${duration}ms ease, opacity ${duration}ms ease`;

    requestAnimationFrame(() => {
      el.style.height = '0';
      el.style.opacity = '0';
    });

    setTimeout(() => {
      el.style.height = '';
      el.style.opacity = '';
      el.style.overflow = '';
      el.style.transition = '';
    }, duration);
  }

  // ═══════════════════════════════════════════════════
  // 3. EVENTOS DEL MOUSE
  // ═══════════════════════════════════════════════════

  // 3a. Parallax suave con mousemove
  function initParallax() {
    const bg = document.querySelector('.dashboard-body, .login-body');
    if (!bg) return;

    const onMove = throttle((e) => {
      requestAnimationFrame(() => {
        const cx = window.innerWidth  / 2;
        const cy = window.innerHeight / 2;
        const dx = (e.clientX - cx) / cx; // -1 a 1
        const dy = (e.clientY - cy) / cy;
        const strength = 12;
        bg.style.backgroundPosition = `calc(50% + ${dx * strength}px) calc(50% + ${dy * strength}px)`;
      });
    }, 16); // ~60fps

    document.addEventListener('mousemove', onMove);
  }

  // 3b. Efecto magnético en botones
  function initMagneticButtons() {
    const selectors = '.btn-primary, .btn-submit, .btn-pedido, .btn-welcome, .btn-accion';

    document.querySelectorAll(selectors).forEach(btn => {
      btn.addEventListener('mousemove', function (e) {
        const rect = this.getBoundingClientRect();
        const cx = rect.left + rect.width  / 2;
        const cy = rect.top  + rect.height / 2;
        const dx = (e.clientX - cx) * 0.3;
        const dy = (e.clientY - cy) * 0.3;

        requestAnimationFrame(() => {
          this.style.transform = `translate(${dx}px, ${dy}px) scale(1.04)`;
        });
      });

      btn.addEventListener('mouseleave', function () {
        requestAnimationFrame(() => {
          this.style.transform = '';
          this.style.transition = 'transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
        });
        // Limpiar transition después para no interferir con otros hovers
        setTimeout(() => { this.style.transition = ''; }, 400);
      });
    });
  }

  // 3c. Hover lift en tarjetas (adicional al CSS, para entradas animadas)
  function initHoverLift() {
    document.querySelectorAll('.tarjeta-preventa, .quick-card').forEach(card => {
      card.addEventListener('mouseenter', function () {
        requestAnimationFrame(() => {
          this.style.willChange = 'transform';
        });
      });
      card.addEventListener('mouseleave', function () {
        requestAnimationFrame(() => {
          this.style.willChange = '';
        });
      });
    });
  }

  // 3d. Efecto ripple en click
  function initRipple() {
    document.querySelectorAll('.btn-primary, .btn-submit, .btn-welcome').forEach(btn => {
      btn.style.position = 'relative';
      btn.style.overflow = 'hidden';

      btn.addEventListener('click', function (e) {
        const rect = this.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const ripple = document.createElement('span');
        ripple.className = 'op-ripple';
        ripple.style.cssText = `
          position:absolute; border-radius:50%;
          background:rgba(255,255,255,0.35);
          transform:scale(0); animation:opRipple 0.55s linear;
          width:100px; height:100px;
          left:${x - 50}px; top:${y - 50}px;
          pointer-events:none;
        `;
        this.appendChild(ripple);
        setTimeout(() => ripple.remove(), 600);
      });
    });
  }

  // ═══════════════════════════════════════════════════
  // 4. TOAST NOTIFICATIONS
  // ═══════════════════════════════════════════════════

  let _toastCooldowns = {};

  function toast(message, type = 'info', duration = 3500) {
    // Cooldown: evitar spam del mismo tipo
    if (_toastCooldowns[type]) return;
    _toastCooldowns[type] = true;
    setTimeout(() => { delete _toastCooldowns[type]; }, 2000);

    let container = document.getElementById('op-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'op-toast-container';
      container.style.cssText = `
        position:fixed; top:80px; right:20px; z-index:9999;
        display:flex; flex-direction:column; gap:10px; pointer-events:none;
      `;
      document.body.appendChild(container);
    }

    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️', new: '🆕' };
    const colors = {
      success: '#2ecc71', error: '#e74c3c',
      warning: '#e67e22', info: '#3498db', new: '#f7d67a'
    };

    const toast = document.createElement('div');
    toast.style.cssText = `
      background: rgba(44,31,20,0.97); border: 2px solid ${colors[type] || colors.info};
      color: var(--gold, #f7d67a); padding: 12px 18px; border-radius: 10px;
      font-size: 0.9rem; display:flex; align-items:center; gap:10px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.5); pointer-events:all;
      opacity:0; transform:translateX(60px);
      transition: opacity 0.3s ease, transform 0.3s ease;
      max-width: 320px;
    `;
    toast.innerHTML = `<span>${icons[type] || icons.info}</span><span>${message}</span>`;
    container.appendChild(toast);

    // Animar entrada
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
      });
    });

    // Animar salida
    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(60px)';
      setTimeout(() => toast.remove(), 320);
    }, duration);
  }

  // ═══════════════════════════════════════════════════
  // 5. HIGHLIGHT DE FILA NUEVA (para polling)
  // ═══════════════════════════════════════════════════

  function highlightNewRow(row) {
    row.style.transition = 'background 0s';
    row.style.background = 'rgba(247,214,122,0.25)';

    setTimeout(() => {
      row.style.transition = 'background 1.5s ease';
      row.style.background = '';
    }, 50);
  }

  // ═══════════════════════════════════════════════════
  // INIT GLOBAL
  // ═══════════════════════════════════════════════════

  function init() {
    initScrollAnimations();
    initParallax();
    initMagneticButtons();
    initHoverLift();
    initRipple();
    console.log('✅ animations.js inicializado');
  }

  // Inicializar cuando el DOM esté listo
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  // ── API pública ───────────────────────────────────────
  return { show, hide, slideDown, slideUp, toast, highlightNewRow, throttle, debounce };
})();

window.OnePieceAnimations = OnePieceAnimations;

/**
 * api.js — Módulo de peticiones HTTP asíncronas
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Implementa: async/await, AbortController, Promise.allSettled(),
 *             reintentos automáticos, timeout, manejo de errores
 */
'use strict';

const OnePieceAPI = (() => {

  // ── Configuración privada ──────────────────────────────
  const CONFIG = {
    baseURL:    window.location.origin + window.location.pathname.replace(/\/[^/]*$/, ''),
    timeout:    8000,   // ms antes de abortar
    retries:    3,
    retryDelay: 800,    // ms entre reintentos
  };

  // Mapa de controladores activos para cancelación
  const _controllers = new Map();

  // ── Utilidad: espera N ms ──────────────────────────────
  const _sleep = ms => new Promise(r => setTimeout(r, ms));

  // ── Fetch con timeout y AbortController ───────────────
  async function _fetchWithTimeout(url, options = {}, requestId = null) {
    const controller = new AbortController();
    const id = requestId || url;

    // Cancelar petición anterior del mismo id
    if (_controllers.has(id)) {
      _controllers.get(id).abort();
    }
    _controllers.set(id, controller);

    const timer = setTimeout(() => controller.abort(), CONFIG.timeout);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
      });
      clearTimeout(timer);
      _controllers.delete(id);
      return response;
    } catch (err) {
      clearTimeout(timer);
      _controllers.delete(id);
      if (err.name === 'AbortError') {
        throw new Error(`Petición cancelada o timeout: ${url}`);
      }
      throw err;
    }
  }

  // ── Fetch con reintentos automáticos ──────────────────
  async function _fetchWithRetry(url, options = {}, requestId = null, attempt = 1) {
    try {
      const response = await _fetchWithTimeout(url, options, requestId);
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      return response;
    } catch (err) {
      if (attempt < CONFIG.retries) {
        console.warn(`[API] Reintento ${attempt}/${CONFIG.retries - 1} para: ${url}`);
        await _sleep(CONFIG.retryDelay * attempt);
        return _fetchWithRetry(url, options, requestId, attempt + 1);
      }
      throw err;
    }
  }

  // ── GET genérico ──────────────────────────────────────
  async function get(endpoint, params = {}, requestId = null) {
    const url = new URL(CONFIG.baseURL + '/' + endpoint, window.location.href);
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));

    console.time(`[API] GET ${endpoint}`);
    try {
      const response = await _fetchWithRetry(url.toString(), {
        headers: { 'Accept': 'application/json' }
      }, requestId || endpoint);
      const data = await response.json();
      console.timeEnd(`[API] GET ${endpoint}`);
      return data;
    } catch (err) {
      console.timeEnd(`[API] GET ${endpoint}`);
      console.error(`[API] Error en GET ${endpoint}:`, err.message);
      throw err;
    }
  }

  // ── POST con FormData o JSON ───────────────────────────
  async function post(endpoint, body = {}, isFormData = false) {
    const url = CONFIG.baseURL + '/' + endpoint;
    const options = {
      method: 'POST',
      body: isFormData ? body : JSON.stringify(body),
    };
    if (!isFormData) {
      options.headers = { 'Content-Type': 'application/json' };
    }

    console.time(`[API] POST ${endpoint}`);
    try {
      const response = await _fetchWithRetry(url, options, `POST:${endpoint}`);
      const data = await response.json();
      console.timeEnd(`[API] POST ${endpoint}`);
      return data;
    } catch (err) {
      console.timeEnd(`[API] POST ${endpoint}`);
      console.error(`[API] Error en POST ${endpoint}:`, err.message);
      throw err;
    }
  }

  // ── Múltiples peticiones simultáneas ──────────────────
  // Usa Promise.allSettled → no falla si una se rechaza
  async function fetchMultiple(requests) {
    const promises = requests.map(({ endpoint, params, id }) =>
      get(endpoint, params || {}, id)
        .then(data => ({ ok: true, data, endpoint }))
        .catch(err => ({ ok: false, error: err.message, endpoint }))
    );

    const results = await Promise.allSettled(promises);

    const output = {};
    results.forEach(result => {
      if (result.status === 'fulfilled') {
        const { ok, data, error, endpoint } = result.value;
        output[endpoint] = ok ? { data } : { error };
      } else {
        // Rechazada a nivel de allSettled (no debería ocurrir por el catch interno)
        output['unknown'] = { error: result.reason?.message || 'Error desconocido' };
      }
    });

    return output;
  }

  // ── Cancelar todas las peticiones activas ─────────────
  function cancelAll() {
    _controllers.forEach(controller => controller.abort());
    _controllers.clear();
    console.log('[API] Todas las peticiones canceladas.');
  }

  // ── API pública ───────────────────────────────────────
  return { get, post, fetchMultiple, cancelAll };
})();

window.OnePieceAPI = OnePieceAPI;
console.log('✅ api.js cargado');

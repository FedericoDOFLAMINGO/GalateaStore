/**
 * cache.js — Caché en memoria con TTL
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Implementa: TTL configurable, LRU eviction, hit/miss stats,
 *             limpieza automática, invalidación por patrón
 */
'use strict';

const OnePieceCache = (() => {

  // ── Config privada ─────────────────────────────────────
  const CONFIG = {
    defaultTTL:  60_000,  // 60 segundos
    maxEntries:  100,     // máximo de entradas (LRU)
    cleanupInterval: 30_000, // limpieza cada 30s
  };

  // ── Almacén interno ───────────────────────────────────
  // Map mantiene orden de inserción → facilita LRU
  const _store = new Map();

  // ── Estadísticas ──────────────────────────────────────
  const _stats = { hits: 0, misses: 0, sets: 0, evictions: 0 };

  // ── Helpers ───────────────────────────────────────────
  function _now() { return Date.now(); }

  function _isExpired(entry) {
    return entry.expiresAt !== null && _now() > entry.expiresAt;
  }

  // Eliminar la entrada más antigua (LRU = primero en el Map)
  function _evictOldest() {
    const firstKey = _store.keys().next().value;
    if (firstKey !== undefined) {
      _store.delete(firstKey);
      _stats.evictions++;
    }
  }

  // ── Limpieza automática de entradas expiradas ─────────
  setInterval(() => {
    let removed = 0;
    _store.forEach((entry, key) => {
      if (_isExpired(entry)) { _store.delete(key); removed++; }
    });
    if (removed > 0) console.log(`[Cache] Limpieza automática: ${removed} entradas expiradas eliminadas.`);
  }, CONFIG.cleanupInterval);

  // ── SET ───────────────────────────────────────────────
  function set(key, value, ttl = CONFIG.defaultTTL) {
    // Evictar si llegamos al límite
    if (_store.size >= CONFIG.maxEntries && !_store.has(key)) {
      _evictOldest();
    }

    _store.set(key, {
      value,
      createdAt: _now(),
      expiresAt: ttl === null ? null : _now() + ttl,
    });
    _stats.sets++;
  }

  // ── GET ───────────────────────────────────────────────
  function get(key) {
    const entry = _store.get(key);
    if (!entry) { _stats.misses++; return null; }

    if (_isExpired(entry)) {
      _store.delete(key);
      _stats.misses++;
      return null;
    }

    // Mover al final para LRU (más recientemente usado)
    _store.delete(key);
    _store.set(key, entry);

    _stats.hits++;
    return entry.value;
  }

  // ── HAS ───────────────────────────────────────────────
  function has(key) {
    return get(key) !== null;
  }

  // ── DELETE ────────────────────────────────────────────
  function del(key) {
    return _store.delete(key);
  }

  // ── Invalidar por patrón (prefijo) ────────────────────
  function invalidate(pattern) {
    let removed = 0;
    _store.forEach((_, key) => {
      if (key.startsWith(pattern)) { _store.delete(key); removed++; }
    });
    console.log(`[Cache] Invalidadas ${removed} entradas con patrón: "${pattern}"`);
    return removed;
  }

  // ── Vaciar todo el caché ──────────────────────────────
  function clear() {
    _store.clear();
    console.log('[Cache] Caché vaciado.');
  }

  // ── Estadísticas ──────────────────────────────────────
  function getStats() {
    const total = _stats.hits + _stats.misses;
    return {
      ..._stats,
      size:    _store.size,
      hitRate: total > 0 ? (((_stats.hits / total) * 100).toFixed(1) + '%') : '0%',
    };
  }

  // ── Wrapper: get-or-fetch ─────────────────────────────
  // Si está en caché lo retorna; si no, ejecuta fetchFn, guarda y retorna
  async function remember(key, fetchFn, ttl = CONFIG.defaultTTL) {
    const cached = get(key);
    if (cached !== null) return cached;

    const value = await fetchFn();
    set(key, value, ttl);
    return value;
  }

  // ── API pública ───────────────────────────────────────
  return { set, get, has, del, invalidate, clear, getStats, remember };
})();

window.OnePieceCache = OnePieceCache;
console.log('✅ cache.js cargado');

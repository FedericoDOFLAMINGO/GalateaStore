/**
 * carousel.js — Carrusel avanzado sin librerías
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Implementa: autoplay, controles manuales, indicadores dinámicos,
 *             transform:translateX, loop infinito simulado,
 *             soporte táctil, responsive, barra de progreso, dots pill
 */
'use strict';

const OnePieceCarousel = (() => {

  function create(containerSelector, options = {}) {

    const container = document.querySelector(containerSelector);
    if (!container) return null;

    const cfg = {
      autoplayDelay: options.autoplayDelay || 4500,
      transitionMs:  options.transitionMs  || 450,
      pauseOnHover:  options.pauseOnHover  !== false,
    };

    const track      = container.querySelector('.carousel-track');
    const origSlides = Array.from(track.querySelectorAll('.carousel-slide'));
    const total      = origSlides.length;

    if (total < 2) return null;

    // Loop infinito: clonar primer y último slide
    const firstClone = origSlides[0].cloneNode(true);
    const lastClone  = origSlides[total - 1].cloneNode(true);
    firstClone.classList.add('clone');
    lastClone.classList.add('clone');
    track.appendChild(firstClone);
    track.insertBefore(lastClone, origSlides[0]);

    let currentIndex   = 1;
    let isTransitioning = false;
    let autoplayId     = null;

    function _setPosition(index, animated = true) {
      track.style.transition = animated
        ? `transform ${cfg.transitionMs}ms cubic-bezier(0.25,0.46,0.45,0.94)`
        : 'none';
      track.style.transform = `translateX(-${index * 100}%)`;
    }

    _setPosition(currentIndex, false);

    // Indicadores dinámicos (dots pill)
    const indicators = container.querySelector('.carousel-indicators');
    if (indicators) {
      indicators.innerHTML = '';
      origSlides.forEach((_, i) => {
        const dot = document.createElement('button');
        dot.className = 'carousel-dot';
        dot.setAttribute('aria-label', `Slide ${i + 1}`);
        dot.addEventListener('click', () => { goTo(i + 1); resetAutoplay(); });
        indicators.appendChild(dot);
      });
    }

    function _updateIndicators() {
      if (!indicators) return;
      const realIndex = currentIndex - 1;
      indicators.querySelectorAll('.carousel-dot').forEach((dot, i) => {
        dot.classList.toggle('active', i === realIndex);
      });
    }

    _updateIndicators();

    // Barra de progreso
    let progressBar = container.querySelector('.carousel-progress-bar');
    if (!progressBar) {
      progressBar = document.createElement('div');
      progressBar.className = 'carousel-progress-bar';
      container.appendChild(progressBar);
    }

    function _startProgress() {
      progressBar.style.transition = 'none';
      progressBar.style.width = '0%';
      requestAnimationFrame(() => requestAnimationFrame(() => {
        progressBar.style.transition = `width ${cfg.autoplayDelay}ms linear`;
        progressBar.style.width = '100%';
      }));
    }

    function _stopProgress() {
      progressBar.style.transition = 'none';
      progressBar.style.width = '0%';
    }

    // Fin de transición
    track.addEventListener('transitionend', () => {
      if (currentIndex === total + 1) { currentIndex = 1; _setPosition(currentIndex, false); }
      if (currentIndex === 0)         { currentIndex = total; _setPosition(currentIndex, false); }
      isTransitioning = false;
    });

    function goTo(index) {
      if (isTransitioning) return;
      isTransitioning = true;
      currentIndex = index;
      _setPosition(currentIndex);
      _updateIndicators();
    }

    function next() { goTo(currentIndex + 1); }
    function prev() { goTo(currentIndex - 1); }

    const btnNext = container.querySelector('.carousel-btn-next');
    const btnPrev = container.querySelector('.carousel-btn-prev');
    if (btnNext) btnNext.addEventListener('click', () => { next(); resetAutoplay(); });
    if (btnPrev) btnPrev.addEventListener('click', () => { prev(); resetAutoplay(); });

    function startAutoplay() {
      if (autoplayId) return;
      _startProgress();
      autoplayId = setInterval(() => { next(); _startProgress(); }, cfg.autoplayDelay);
    }

    function stopAutoplay() {
      clearInterval(autoplayId);
      autoplayId = null;
      _stopProgress();
    }

    function resetAutoplay() { stopAutoplay(); startAutoplay(); }

    startAutoplay();

    if (cfg.pauseOnHover) {
      container.addEventListener('mouseenter', stopAutoplay);
      container.addEventListener('mouseleave', startAutoplay);
    }

    // Touch
    let touchStartX = 0, touchStartY = 0;
    container.addEventListener('touchstart', e => {
      touchStartX = e.changedTouches[0].clientX;
      touchStartY = e.changedTouches[0].clientY;
    }, { passive: true });
    container.addEventListener('touchend', e => {
      const dx = e.changedTouches[0].clientX - touchStartX;
      const dy = e.changedTouches[0].clientY - touchStartY;
      if (Math.abs(dx) > Math.abs(dy) && Math.abs(dx) > 40) {
        dx < 0 ? next() : prev();
        resetAutoplay();
      }
    }, { passive: true });

    // Responsive
    const _onResize = (typeof OnePieceAnimations !== 'undefined' && OnePieceAnimations.debounce)
      ? OnePieceAnimations.debounce(() => _setPosition(currentIndex, false), 300)
      : () => _setPosition(currentIndex, false);
    window.addEventListener('resize', _onResize);

    // Teclado
    container.setAttribute('tabindex', '0');
    container.addEventListener('keydown', e => {
      if (e.key === 'ArrowLeft')  { prev(); resetAutoplay(); }
      if (e.key === 'ArrowRight') { next(); resetAutoplay(); }
    });

    return { next, prev, goTo, startAutoplay, stopAutoplay };
  }

  function init() {
    document.querySelectorAll('[data-carousel]').forEach(c => {
      if (c.id) create('#' + c.id);
    });
    if (document.querySelector('#carousel-preventas')) {
      create('#carousel-preventas', { autoplayDelay: 4500 });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  return { create, init };
})();

window.OnePieceCarousel = OnePieceCarousel;
console.log('✅ carousel.js cargado');

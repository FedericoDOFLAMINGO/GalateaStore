/**
 * dom.js — Utilidades de manipulación del DOM y optimización
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Implementa: lazy loading manual con IntersectionObserver,
 *             batch de lecturas/escrituras (minimización de reflows),
 *             DocumentFragment para render de listas,
 *             console.time para medición de rendimiento,
 *             utilidades de creación y búsqueda de elementos
 */
'use strict';

const OnePieceDOM = (() => {

  // ════════════════════════════════════════════
  // 1. LAZY LOADING con IntersectionObserver
  // ════════════════════════════════════════════

  /**
   * Activar lazy loading en imágenes que usen data-src.
   * Más potente que el atributo loading="lazy" nativo porque
   * permite controlar exactamente el umbral y la animación.
   */
  function lazyLoadImages(selector = '[data-src]') {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const img = entry.target;
          const src = img.dataset.src;
          if (!src) return;

          // Precargar en objeto Image para no mostrar parpadeo
          const preload = new Image();
          preload.onload = () => {
            img.src = src;
            img.removeAttribute('data-src');
            img.classList.add('lazy-loaded');
          };
          preload.onerror = () => {
            img.src = 'img/op13.jpeg'; // fallback
            img.removeAttribute('data-src');
          };
          preload.src = src;

          observer.unobserve(img);
        }
      });
    }, {
      rootMargin: '100px 0px',  // cargar 100px antes de entrar al viewport
      threshold: 0,
    });

    document.querySelectorAll(selector).forEach(img => observer.observe(img));
  }

  // ════════════════════════════════════════════
  // 2. MINIMIZACIÓN DE REFLOWS
  //    Batch de lecturas antes de escrituras
  // ════════════════════════════════════════════

  /**
   * Ejecutar lecturas del DOM en batch y luego escrituras,
   * evitando que el navegador recalcule el layout entre operaciones.
   *
   * @param {Function} readFn  - función que SOLO lee propiedades del DOM
   * @param {Function} writeFn - función que recibe los valores y SOLO escribe
   */
  function batchDOM(readFn, writeFn) {
    // Paso 1: todas las lecturas (puede causar reflow una sola vez)
    const measurements = readFn();
    // Paso 2: todas las escrituras con los valores ya leídos
    requestAnimationFrame(() => writeFn(measurements));
  }

  /**
   * Igualizar alturas de un grupo de elementos en 1 solo reflow.
   * ❌ MAL: leer y escribir alternados causan N reflows
   * ✅ BIEN: leer todo, luego escribir todo
   */
  function equalizeHeights(selector) {
    const els = Array.from(document.querySelectorAll(selector));
    if (els.length === 0) return;

    batchDOM(
      () => els.map(el => el.offsetHeight),           // leer todo
      heights => {                                      // escribir todo
        const max = Math.max(...heights);
        els.forEach(el => { el.style.minHeight = max + 'px'; });
      }
    );
  }

  // ════════════════════════════════════════════
  // 3. DOCUMENTFRAGMENT — render de listas
  //    Genera N nodos y los inserta en 1 reflow
  // ════════════════════════════════════════════

  /**
   * Renderizar un array de datos en un contenedor usando
   * DocumentFragment para un solo reflow.
   *
   * @param {Element}  container  - elemento donde insertar
   * @param {Array}    items      - datos a renderizar
   * @param {Function} createEl   - fn(item, index) → HTMLElement
   * @param {Boolean}  append     - true=añadir, false=reemplazar
   */
  function renderList(container, items, createEl, append = false) {
    if (!container) return;

    console.time('[DOM] renderList');

    const fragment = document.createDocumentFragment();
    items.forEach((item, index) => {
      const el = createEl(item, index);
      if (el) fragment.appendChild(el);
    });

    if (!append) container.innerHTML = '';
    container.appendChild(fragment);

    console.timeEnd('[DOM] renderList');
  }

  // ════════════════════════════════════════════
  // 4. CREAR TARJETA DE PREVENTA
  //    Usado por el buscador en tiempo real
  // ════════════════════════════════════════════

  function crearTarjetaPreventa(item) {
    const div = document.createElement('div');
    div.className = 'tarjeta-preventa anim-hidden';

    const imgSrc = item.imagen_url || 'img/op13.jpeg';
    const precio = parseFloat(item.precio).toFixed(2);

    div.innerHTML = `
      <img data-src="${escHtml(imgSrc)}"
           src="img/op13.jpeg"
           alt="${escHtml(item.nombre_producto)}"
           class="imagen-preventa"
           onerror="this.src='img/op13.jpeg'">
      <div class="tarjeta-body">
        <h3 class="nombre-preventa">${escHtml(item.nombre_producto)}</h3>
        <div class="preventa-info">
          <span class="precio">$${precio}</span>
          <span class="stock">Stock: ${parseInt(item.stock_disponible)}</span>
        </div>
        <a href="hacer_pedido.php?id=${parseInt(item.id)}" class="btn-pedido">Ordenar ahora</a>
      </div>`;

    return div;
  }

  function crearFilaPreventa(item) {
    const tr = document.createElement('tr');
    const imgSrc = item.imagen_url || 'img/op13.jpeg';
    const precio = parseFloat(item.precio).toFixed(2);
    const badgeClass = parseInt(item.stock_disponible) > 0 ? 'badge-active' : 'badge-inactive';

    tr.innerHTML = `
      <td><img data-src="${escHtml(imgSrc)}" src="img/op13.jpeg"
               style="max-width:70px;border-radius:8px;" onerror="this.src='img/op13.jpeg'"></td>
      <td><strong>${escHtml(item.nombre_producto)}</strong></td>
      <td style="font-size:0.85rem;">${escHtml(item.descripcion || '')}</td>
      <td style="color:var(--green-ok);font-weight:700;">$${precio}</td>
      <td><span class="badge ${badgeClass}">${parseInt(item.stock_disponible)} uds.</span></td>
      <td style="font-size:0.85rem;">${escHtml(item.fecha_inicio || '')}</td>
      <td style="font-size:0.85rem;">${escHtml(item.fecha_fin || '')}</td>
      <td><a href="hacer_pedido.php?id=${parseInt(item.id)}" class="btn-accion btn-inspeccionar">🛒 Ordenar</a></td>`;

    return tr;
  }

  // ════════════════════════════════════════════
  // 5. MOSTRAR / OCULTAR LOADER
  // ════════════════════════════════════════════

  function showLoader(container, message = 'Cargando...') {
    if (!container) return;
    container.innerHTML = `
      <div style="text-align:center;padding:40px;">
        <div class="op-spinner" style="margin:0 auto 14px;"></div>
        <p style="color:rgba(247,214,122,0.6);font-size:0.9rem;">${escHtml(message)}</p>
      </div>`;
  }

  function showEmpty(container, message = 'No se encontraron resultados.') {
    if (!container) return;
    container.innerHTML = `
      <div style="text-align:center;padding:60px 20px;grid-column:1/-1;">
        <p style="font-size:1.1rem;color:rgba(247,214,122,0.6);">⚓ ${escHtml(message)}</p>
      </div>`;
  }

  function showError(container, message = 'Error al cargar los datos.') {
    if (!container) return;
    container.innerHTML = `
      <div style="text-align:center;padding:40px;grid-column:1/-1;">
        <p style="color:var(--red-err);">❌ ${escHtml(message)}</p>
      </div>`;
  }

  // ════════════════════════════════════════════
  // 6. UTILIDADES
  // ════════════════════════════════════════════

  function escHtml(str) {
    if (str == null) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function $(selector, ctx = document) { return ctx.querySelector(selector); }
  function $$(selector, ctx = document) { return Array.from(ctx.querySelectorAll(selector)); }

  // ── API pública ───────────────────────────────────────
  return {
    lazyLoadImages,
    batchDOM,
    equalizeHeights,
    renderList,
    crearTarjetaPreventa,
    crearFilaPreventa,
    showLoader,
    showEmpty,
    showError,
    escHtml,
    $, $$,
  };
})();

window.OnePieceDOM = OnePieceDOM;
console.log('✅ dom.js cargado');

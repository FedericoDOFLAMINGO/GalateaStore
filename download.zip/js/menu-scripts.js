/**
 * menu-scripts.js — Manejo de eventos del DOM para navegación
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 * Matrícula: 221181 | Grupo: IDGS 8B | Periodo: Enero-Abril 2026
 *
 * Implementa: eventos click, delegación, toggle de clases, animaciones CSS,
 *             debounce en resize/búsqueda, throttle en scroll,
 *             accesibilidad ARIA, teclado ESC, highlight enlace activo
 */
'use strict';

// ── Debounce ──────────────────────────────────────────────
function debounce(fn, delay = 300) {
  let timeoutId = null;
  return function (...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn.apply(this, args), delay);
  };
}

// ── Throttle ──────────────────────────────────────────────
function throttle(fn, limit = 100) {
  let inThrottle = false;
  return function (...args) {
    if (!inThrottle) {
      fn.apply(this, args);
      inThrottle = true;
      setTimeout(() => { inThrottle = false; }, limit);
    }
  };
}

// ─────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function () {

  // === MENÚ MÓVIL (HAMBURGUESA) ===
  const navToggle = document.getElementById('navToggle');
  const navMenu   = document.getElementById('navMenu');

  if (navToggle && navMenu) {
    navToggle.addEventListener('click', function () {
      navMenu.classList.toggle('active');
      navToggle.classList.toggle('active');
      const isExpanded = navMenu.classList.contains('active');
      navToggle.setAttribute('aria-expanded', isExpanded);
    });
  }

  // === SUBMENÚS EN MÓVIL ===
  const submenuParents = document.querySelectorAll('.has-submenu');
  submenuParents.forEach(parent => {
    const link = parent.querySelector('.nav-link');
    if (link) {
      link.addEventListener('click', function (e) {
        if (window.innerWidth <= 768) {
          e.preventDefault();
          parent.classList.toggle('active');
          submenuParents.forEach(other => {
            if (other !== parent) other.classList.remove('active');
          });
        }
      });
    }
  });

  // === CERRAR MENÚ AL HACER CLIC FUERA ===
  document.addEventListener('click', function (e) {
    if (window.innerWidth <= 768 && navMenu && navToggle) {
      if (!navMenu.contains(e.target) && !navToggle.contains(e.target)) {
        navMenu.classList.remove('active');
        navToggle.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    }
  });

  // === RESALTAR ENLACE ACTIVO ===
  highlightActiveLink();

  // === MENÚ DE USUARIO ===
  const userProfile = document.getElementById('userProfile');
  if (userProfile) {
    userProfile.addEventListener('click', function (e) {
      e.stopPropagation();
      const submenu = this.nextElementSibling;
      if (submenu) submenu.classList.toggle('active');
    });
    document.addEventListener('click', function (e) {
      const userMenu = document.querySelector('.user-menu');
      if (userMenu && !userMenu.contains(e.target)) {
        document.querySelectorAll('.user-submenu').forEach(s => s.classList.remove('active'));
      }
    });
  }

  // === ACCESIBILIDAD: ESC cierra menú ===
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') {
      if (navMenu && navMenu.classList.contains('active')) {
        navMenu.classList.remove('active');
        if (navToggle) {
          navToggle.classList.remove('active');
          navToggle.setAttribute('aria-expanded', 'false');
          navToggle.focus();
        }
      }
      document.querySelectorAll('.user-submenu').forEach(s => s.classList.remove('active'));
    }
  });

  // === RESIZE — debounced ===
  const handleResize = debounce(function () {
    if (window.innerWidth > 768 && navMenu) {
      navMenu.classList.remove('active');
      if (navToggle) {
        navToggle.classList.remove('active');
        navToggle.setAttribute('aria-expanded', 'false');
      }
    }
  }, 200);
  window.addEventListener('resize', handleResize);

  // === SCROLL — throttled ===
  const handleScroll = throttle(function () {
    const navbar = document.querySelector('.navbar-mejorado');
    if (navbar) {
      navbar.style.boxShadow = window.scrollY > 10
        ? '0 4px 20px rgba(0,0,0,0.7)'
        : '0 2px 10px rgba(0,0,0,0.5)';
    }
  }, 80);
  window.addEventListener('scroll', handleScroll, { passive: true });

  // === BUSCADOR CON DEBOUNCE ===
  document.querySelectorAll('.search-form input[type="text"], #buscador-preventas').forEach(input => {
    const handleSearch = debounce(function () {
      const q = input.value.trim();
      const form = input.closest('form');
      if (form && (q.length === 0 || q.length >= 3)) {
        form.submit();
      }
    }, 400);
    input.addEventListener('input', handleSearch);
  });

  // === ACORDEÓN DE AYUDA (sin display:none) ===
  document.querySelectorAll('.ayuda-header').forEach(header => {
    header.addEventListener('click', function () {
      const section = this.closest('.ayuda-section');
      const body    = section.querySelector('.ayuda-body');

      if (section.classList.contains('open')) {
        section.classList.remove('open');
        if (body) {
          body.style.overflow = 'hidden';
          body.style.height = body.scrollHeight + 'px';
          requestAnimationFrame(() => {
            body.style.transition = 'height 0.3s ease, opacity 0.3s ease';
            body.style.height = '0';
            body.style.opacity = '0';
          });
          setTimeout(() => {
            body.style.display = 'none';
            body.style.height = '';
            body.style.opacity = '';
            body.style.transition = '';
            body.style.overflow = '';
          }, 320);
        }
      } else {
        document.querySelectorAll('.ayuda-section.open').forEach(other => {
          const ob = other.querySelector('.ayuda-body');
          other.classList.remove('open');
          if (ob) ob.style.display = 'none';
        });
        section.classList.add('open');
        if (body) {
          body.style.display = 'block';
          body.style.overflow = 'hidden';
          body.style.height = '0';
          body.style.opacity = '0';
          body.style.transition = 'height 0.3s ease, opacity 0.3s ease';
          const targetH = body.scrollHeight + 'px';
          requestAnimationFrame(() => {
            body.style.height = targetH;
            body.style.opacity = '1';
          });
          setTimeout(() => {
            body.style.height = '';
            body.style.overflow = '';
          }, 320);
        }
      }
    });
  });

});

// ── Resaltar enlace activo ────────────────────────────────
function highlightActiveLink() {
  const currentPage = window.location.pathname.split('/').pop() || 'dashboard.php';
  document.querySelectorAll('.nav-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && href.includes(currentPage)) {
      link.style.backgroundColor = 'rgba(247,214,122,0.2)';
      link.style.fontWeight = 'bold';
      link.style.color = 'var(--gold-bright)';
    }
  });
}

console.log('✅ menu-scripts.js cargado (debounce + throttle activos)');

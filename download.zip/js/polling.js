/**
 * polling.js — Actualización en tiempo real con Polling Inteligente
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 *
 * Implementa: polling adaptativo, Page Visibility API,
 *             prevención de duplicados, animación de nuevos datos,
 *             notificación visual, setInterval controlado
 */
'use strict';

const OnePiecePolling = (() => {

  // ── Config ────────────────────────────────────────────
  const CONFIG = {
    intervalActive:   5_000,   // 5s cuando el usuario está activo
    intervalIdle:     15_000,  // 15s cuando está inactivo
    idleThreshold:    60_000,  // considerar inactivo tras 60s sin interacción
    notifyCooldown:   5_000,   // ms entre notificaciones del mismo tipo
  };

  let _pollId        = null;
  let _lastActivity  = Date.now();
  let _knownIds      = new Set();   // IDs ya renderizados (prevención duplicados)
  let _notifyCooldowns = {};

  // ── Registrar actividad del usuario ──────────────────
  ['click', 'keydown', 'mousemove', 'touchstart'].forEach(evt => {
    document.addEventListener(evt, () => { _lastActivity = Date.now(); }, { passive: true });
  });

  function _isIdle() {
    return (Date.now() - _lastActivity) > CONFIG.idleThreshold;
  }

  // ── Notificación visual (delegada a animations.js) ────
  function _notify(message, type = 'new') {
    if (_notifyCooldowns[type]) return;
    _notifyCooldowns[type] = true;
    setTimeout(() => { delete _notifyCooldowns[type]; }, CONFIG.notifyCooldown);

    if (window.OnePieceAnimations) {
      OnePieceAnimations.toast(message, type, 4000);
    }
  }

  // ── Registrar IDs existentes en tabla ────────────────
  function _scanExistingIds(tableBody, idAttr = 'data-id') {
    tableBody.querySelectorAll(`tr[${idAttr}]`).forEach(row => {
      _knownIds.add(row.getAttribute(idAttr));
    });
  }

  // ── Insertar fila nueva con animación ─────────────────
  function _insertNewRow(tableBody, rowHTML, rowId) {
    if (_knownIds.has(String(rowId))) return false; // duplicado
    _knownIds.add(String(rowId));

    const tr = document.createElement('tr');
    tr.setAttribute('data-id', rowId);
    tr.innerHTML = rowHTML;
    tr.style.opacity = '0';

    // Insertar al inicio de la tabla
    tableBody.insertBefore(tr, tableBody.firstChild);

    // Animar entrada + highlight
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        tr.style.transition = 'opacity 0.4s ease';
        tr.style.opacity = '1';
        if (window.OnePieceAnimations) {
          OnePieceAnimations.highlightNewRow(tr);
        }
      });
    });

    return true;
  }

  // ── Actualizar badge de notificaciones ────────────────
  function _pulseBadge(badgeEl, count) {
    if (!badgeEl) return;
    badgeEl.textContent = count;
    badgeEl.style.transition = 'none';
    badgeEl.style.transform = 'scale(1.5)';
    badgeEl.style.background = '#e74c3c';

    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        badgeEl.style.transition = 'transform 0.4s cubic-bezier(0.34,1.56,0.64,1)';
        badgeEl.style.transform = 'scale(1)';
      });
    });
  }

  // ═══════════════════════════════════════════════════
  // POLLING PRINCIPAL — Nuevos pedidos (admin)
  // ═══════════════════════════════════════════════════

  function startPedidosPolling(tableBodyId, badgeId) {
    const tableBody = document.getElementById(tableBodyId);
    const badge     = document.getElementById(badgeId);
    if (!tableBody) return;

    // Registrar IDs actuales para no duplicar
    _scanExistingIds(tableBody);

    async function _poll() {
      const interval = _isIdle() ? CONFIG.intervalIdle : CONFIG.intervalActive;

      try {
        const response = await fetch('api_pedidos.php?action=nuevos&since=' + Date.now(), {
          headers: { 'Accept': 'application/json' },
        });

        if (!response.ok) throw new Error('HTTP ' + response.status);
        const data = await response.json();

        if (data.nuevos && data.nuevos.length > 0) {
          let insertados = 0;
          data.nuevos.forEach(pedido => {
            const inserted = _insertNewRow(tableBody, pedido.rowHTML, pedido.id);
            if (inserted) insertados++;
          });

          if (insertados > 0) {
            _pulseBadge(badge, data.total_pendientes || insertados);
            _notify(
              `${insertados} nuevo${insertados > 1 ? 's' : ''} pedido${insertados > 1 ? 's' : ''} recibido${insertados > 1 ? 's' : ''}`,
              'new'
            );
          }
        }
      } catch (err) {
        // Silencioso: el polling no debe mostrar errores al usuario
        console.warn('[Polling] Error al consultar nuevos pedidos:', err.message);
      }

      // Reprogramar con intervalo adaptativo
      _pollId = setTimeout(_poll, interval);
    }

    // Iniciar
    _pollId = setTimeout(_poll, CONFIG.intervalActive);
    console.log('[Polling] Iniciado para pedidos.');
  }

  // ═══════════════════════════════════════════════════
  // POLLING PARA ESTADO DE PEDIDO (cliente)
  // ═══════════════════════════════════════════════════

  function startEstadoPedidoPolling(pedidoId, statusCellId) {
    const cell = document.getElementById(statusCellId);
    if (!cell) return;

    let lastEstado = cell.dataset.estado || '';

    async function _poll() {
      try {
        const response = await fetch(`api_pedidos.php?action=estado&id=${pedidoId}`);
        if (!response.ok) throw new Error('HTTP ' + response.status);
        const data = await response.json();

        if (data.estado && data.estado !== lastEstado) {
          lastEstado = data.estado;
          cell.dataset.estado = data.estado;
          cell.innerHTML = data.badgeHTML || data.estado;

          if (window.OnePieceAnimations) {
            OnePieceAnimations.highlightNewRow(cell.closest('tr'));
          }

          const msgs = {
            confirmado: '✅ ¡Tu pedido fue confirmado!',
            cancelado:  '❌ Tu pedido fue cancelado.',
            enviado:    '📦 Tu pedido está en camino.',
          };
          if (msgs[data.estado]) _notify(msgs[data.estado], data.estado === 'confirmado' ? 'success' : 'warning');
        }
      } catch (err) {
        console.warn('[Polling] Error al consultar estado:', err.message);
      }

      _pollId = setTimeout(_poll, _isIdle() ? CONFIG.intervalIdle : CONFIG.intervalActive);
    }

    _pollId = setTimeout(_poll, CONFIG.intervalActive);
  }

  // ── Page Visibility API ───────────────────────────────
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      // Pausar polling cuando la pestaña está oculta
      clearTimeout(_pollId);
      _pollId = null;
      console.log('[Polling] Pausado (pestaña oculta).');
    } else {
      // Reanudar inmediatamente al volver
      console.log('[Polling] Reanudado (pestaña visible).');
      // Los polls se reactivarán al llamar start* de nuevo si es necesario
    }
  });

  // ── Detener todo ──────────────────────────────────────
  function stop() {
    clearTimeout(_pollId);
    _pollId = null;
    _knownIds.clear();
    console.log('[Polling] Detenido.');
  }

  return { startPedidosPolling, startEstadoPedidoPolling, stop };
})();

window.OnePiecePolling = OnePiecePolling;
console.log('✅ polling.js cargado');

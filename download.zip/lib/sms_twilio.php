<?php
/**
 * lib/sms_twilio.php — Envío de SMS con Twilio REST API (sin SDK)
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */

function enviarSMSTwilio(string $to, string $mensaje): bool {
    if (!defined('TWILIO_SID') || TWILIO_SID === 'TU_ACCOUNT_SID_AQUI') {
        error_log("[SMS SIMULADO] Para: $to | Mensaje: $mensaje");
        return false;
    }

    $url  = 'https://api.twilio.com/2010-04-01/Accounts/' . TWILIO_SID . '/Messages.json';
    $data = http_build_query([
        'From' => TWILIO_FROM,
        'To'   => $to,
        'Body' => $mensaje,
    ]);

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $data,
        CURLOPT_USERPWD        => TWILIO_SID . ':' . TWILIO_TOKEN,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/x-www-form-urlencoded'],
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $result = json_decode($response, true);
    return isset($result['sid']) && $httpCode === 201;
}

function enviarOTPSMS(string $telefono, string $codigo, string $nombre = 'Usuario'): bool {
    $msg = "Hola $nombre, tu código de verificación para One Piece Preventas es: $codigo. Válido por 10 minutos.";
    return enviarSMSTwilio($telefono, $msg);
}

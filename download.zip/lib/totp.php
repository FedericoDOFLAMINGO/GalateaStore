<?php
/**
 * lib/totp.php — Implementación TOTP (RFC 6238) sin librerías externas
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 *
 * Compatible con Google Authenticator, Authy y cualquier app TOTP.
 */
class TOTP {

    const DIGITS   = 6;
    const PERIOD   = 30;
    const WINDOW   = 1;   // ±1 intervalo de tolerancia

    /**
     * Genera un secreto Base32 aleatorio (16 caracteres = 80 bits).
     */
    public static function generateSecret(int $length = 16): string {
        $chars  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $secret = '';
        for ($i = 0; $i < $length; $i++) {
            $secret .= $chars[random_int(0, 31)];
        }
        return $secret;
    }

    /**
     * Decodifica Base32 a bytes.
     */
    private static function base32Decode(string $input): string {
        $map  = array_flip(str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'));
        $input = strtoupper($input);
        $binary = '';
        foreach (str_split($input) as $char) {
            if (!isset($map[$char])) continue;
            $binary .= str_pad(decbin($map[$char]), 5, '0', STR_PAD_LEFT);
        }
        $output = '';
        foreach (str_split($binary, 8) as $byte) {
            if (strlen($byte) === 8) {
                $output .= chr(bindec($byte));
            }
        }
        return $output;
    }

    /**
     * Genera el código TOTP para un timestamp dado.
     */
    public static function getCode(string $secret, ?int $timestamp = null): string {
        $timestamp = $timestamp ?? time();
        $counter   = (int)floor($timestamp / self::PERIOD);
        $key       = self::base32Decode($secret);
        $msg       = pack('N*', 0) . pack('N*', $counter);
        $hash      = hash_hmac('sha1', $msg, $key, true);
        $offset    = ord($hash[19]) & 0x0F;
        $code      = (
            ((ord($hash[$offset])   & 0x7F) << 24) |
            ((ord($hash[$offset+1]) & 0xFF) << 16) |
            ((ord($hash[$offset+2]) & 0xFF) << 8)  |
            ( ord($hash[$offset+3]) & 0xFF)
        ) % (10 ** self::DIGITS);
        return str_pad((string)$code, self::DIGITS, '0', STR_PAD_LEFT);
    }

    /**
     * Verifica un código TOTP con ventana de tolerancia.
     */
    public static function verify(string $secret, string $code): bool {
        $code = trim($code);
        if (!preg_match('/^\d{6}$/', $code)) return false;
        $t = time();
        for ($i = -self::WINDOW; $i <= self::WINDOW; $i++) {
            if (hash_equals(self::getCode($secret, $t + $i * self::PERIOD), $code)) {
                return true;
            }
        }
        return false;
    }
}

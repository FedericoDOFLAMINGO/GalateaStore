
Copiar

<?php
    ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
/**
 * login.php — Autenticación con Google OAuth + login tradicional
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/seguridad/auth.php';
 
if (isset($_SESSION['usuario'])) {
    header('Location: dashboard.php');
    exit;
}
 
$error = '';
$ip    = getClientIP();
 
$msgs = [
    'sesion_expirada'  => '⏰ Tu sesión expiró o fue cerrada desde otro dispositivo.',
    'google_cancelado' => '⚠️ Inicio con Google cancelado.',
    'error_google'     => '❌ Error al conectar con Google. Intenta de nuevo.',
];
if (isset($_GET['msg']) && isset($msgs[$_GET['msg']])) {
    $error = $msgs[$_GET['msg']];
}
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();
    $usuario  = trim($_POST['nombre_usuario'] ?? '');
    $password = $_POST['password'] ?? '';
 
    if (estaBloqueado($conn, $usuario, $ip)) {
        $mins  = minutosBloqueo($conn, $usuario);
        $error = "⛔ Demasiados intentos fallidos. Intenta en {$mins} minuto(s).";
    } else {
        $stmt = $conn->prepare("SELECT * FROM clientes WHERE nombre_usuario = ? OR email = ?");
        $stmt->bind_param('ss', $usuario, $usuario);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();
 
        if ($user && password_verify($password, $user['password'])) {
            registrarIntento($conn, $usuario, $ip, true);
 
            if ($user['mfa_enabled']) {
                $_SESSION['mfa_pending'] = [
                    'user_id'        => $user['id'],
                    'nombre_usuario' => $user['nombre_usuario'],
                    'rol'            => $user['rol'],
                    'correo'         => $user['email'],
                ];
                header('Location: mfa_verificar.php');
                exit;
            }
 
            session_regenerate_id(true);
            $sessionToken = crearSesionBD($conn, $user['id'], $ip, getUserAgent());
            $sessionId    = (int)$conn->insert_id;
            $refreshToken = generarRefreshToken($conn, $user['id'], $sessionId);
 
            $_SESSION['usuario'] = [
                'id'             => $user['id'],
                'nombre_usuario' => $user['nombre_usuario'],
                'rol'            => $user['rol'],
                'correo'         => $user['email'],
            ];
            $_SESSION['session_token'] = $sessionToken;
            $_SESSION['refresh_token'] = $refreshToken;
            $_SESSION['show_welcome']  = true;
 
            header('Location: dashboard.php');
            exit;
        } else {
            registrarIntento($conn, $usuario, $ip, false);
            usleep(random_int(300000, 700000));
            $error = '❌ Usuario o contraseña incorrectos.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar Sesión — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
  <style>
    .btn-google {
      display:flex;align-items:center;justify-content:center;gap:10px;
      width:100%;padding:11px;border-radius:8px;border:1px solid rgba(255,255,255,0.2);
      background:rgba(255,255,255,0.07);color:#fff;font-size:0.95rem;
      text-decoration:none;transition:background 0.2s;cursor:pointer;margin-bottom:6px;
    }
    .btn-google:hover { background:rgba(255,255,255,0.15); }
    .btn-google svg { width:20px;height:20px;flex-shrink:0; }
    .divider-o { display:flex;align-items:center;gap:10px;margin:14px 0;color:rgba(255,255,255,0.3);font-size:0.82rem; }
    .divider-o::before,.divider-o::after { content:'';flex:1;height:1px;background:rgba(255,255,255,0.15); }
    /* QR Login */
    .qr-tab-btns { display:flex;gap:0;margin-bottom:18px;border-radius:8px;overflow:hidden;border:1px solid rgba(247,214,122,0.25); }
    .qr-tab-btn  { flex:1;padding:9px;background:transparent;color:rgba(247,214,122,0.6);border:none;cursor:pointer;font-size:0.85rem;transition:all .2s; }
    .qr-tab-btn.active { background:rgba(247,214,122,0.15);color:#ffcb45;font-weight:bold; }
    .qr-panel    { display:none; }
    .qr-panel.active { display:block; }
    #qr-box { text-align:center;padding:18px 0 10px; }
    #qr-img-wrap { display:inline-block;padding:10px;background:#fff;border-radius:10px;border:3px solid #f7d67a;margin-bottom:10px; }
    #qr-img-wrap img { display:block;width:170px;height:170px; }
    #qr-status { font-size:0.82rem;color:rgba(247,214,122,0.6);margin:4px 0 0; }
    #qr-timer  { font-size:0.75rem;color:rgba(247,214,122,0.35);margin-top:3px; }
    .qr-scanning { animation:qr-pulse 1.2s infinite; }
    @keyframes qr-pulse { 0%,100%{border-color:#f7d67a} 50%{border-color:#22c55e} }
  </style>
</head>
<body class="login-body">
<div class="login-card">
  <img src="img/Sombrero.png" alt="Logo" style="width:70px;margin-bottom:10px;">
  <h2>Bienvenido</h2>
  <p class="subtitle">Inicia sesión para acceder a tus preventas</p>
 
  <?php if ($error): ?>
    <div class="alert-error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
 
  <!-- Tabs: Login / QR -->
  <div class="qr-tab-btns">
    <button class="qr-tab-btn active" onclick="switchTab('form')">🔐 Contraseña</button>
    <button class="qr-tab-btn" onclick="switchTab('qr')">📱 QR</button>
  </div>
 
  <!-- Panel: Login con contraseña -->
  <div id="panel-form" class="qr-panel active">
  <!-- Botón Google -->
  <a href="seguridad/google_oauth.php" class="btn-google">
    <svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg">
      <path fill="#FFC107" d="M43.611 20.083H42V20H24v8h11.303c-1.649 4.657-6.08 8-11.303 8-6.627 0-12-5.373-12-12s5.373-12 12-12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 12.955 4 4 12.955 4 24s8.955 20 20 20 20-8.955 20-20c0-1.341-.138-2.65-.389-3.917z"/>
      <path fill="#FF3D00" d="M6.306 14.691l6.571 4.819C14.655 15.108 18.961 12 24 12c3.059 0 5.842 1.154 7.961 3.039l5.657-5.657C34.046 6.053 29.268 4 24 4 16.318 4 9.656 8.337 6.306 14.691z"/>
      <path fill="#4CAF50" d="M24 44c5.166 0 9.86-1.977 13.409-5.192l-6.19-5.238A11.91 11.91 0 0 1 24 36c-5.202 0-9.619-3.317-11.283-7.946l-6.522 5.025C9.505 39.556 16.227 44 24 44z"/>
      <path fill="#1976D2" d="M43.611 20.083H42V20H24v8h11.303a12.04 12.04 0 0 1-4.087 5.571l.003-.002 6.19 5.238C36.971 39.205 44 34 44 24c0-1.341-.138-2.65-.389-3.917z"/>
    </svg>
    Continuar con Google
  </a>
 
  <div class="divider-o">o</div>
 
  <form method="POST" autocomplete="off">
    <?= csrf_field() ?>
    <div class="form-group">
      <label for="nombre_usuario">Usuario o correo</label>
      <input type="text" id="nombre_usuario" name="nombre_usuario"
             placeholder="Tu usuario o email" required
             value="<?= htmlspecialchars($_POST['nombre_usuario'] ?? '') ?>">
    </div>
    <div class="form-group">
      <label for="password">Contraseña</label>
      <input type="password" id="password" name="password"
             placeholder="••••••••" required autocomplete="current-password">
    </div>
    <button type="submit" class="btn-primary">⚓ Entrar</button>
  </form>
 
  <div style="text-align:center;margin-top:12px;">
    <a href="recuperar_password.php" style="font-size:0.82rem;color:rgba(247,214,122,0.6);text-decoration:none;">
      🔑 ¿Olvidaste tu contraseña?
    </a>
  </div>
  <div class="login-divider">¿No tienes cuenta?</div>
  <a href="register.php" class="btn-secondary">📝 Crear cuenta nueva</a>
  </div><!-- /panel-form -->
 
  <!-- Panel: Login con QR -->
  <div id="panel-qr" class="qr-panel">
    <div id="qr-box">
      <p class="subtitle" style="margin-bottom:12px;font-size:0.88rem;">
        Escanea con tu celular donde ya tienes sesión iniciada
      </p>
      <div id="qr-img-wrap">
        <img id="qr-img" src="" alt="QR">
      </div>
      <div id="qr-status">⏳ Generando código QR...</div>
      <div id="qr-timer"></div>
      <button onclick="generarQR()" class="btn-secondary" style="margin-top:14px;padding:8px 20px;font-size:0.82rem;">
        🔄 Regenerar QR
      </button>
    </div>
  </div><!-- /panel-qr -->
 
</div>
<script>
// ── Tabs ──────────────────────────────────────────
function switchTab(tab) {
  document.querySelectorAll('.qr-tab-btn').forEach((b,i) => {
    b.classList.toggle('active', (tab==='form' && i===0)||(tab==='qr' && i===1));
  });
  document.getElementById('panel-form').classList.toggle('active', tab==='form');
  document.getElementById('panel-qr').classList.toggle('active',  tab==='qr');
  if (tab === 'qr' && !window._qrToken) generarQR();
}
 
// ── QR Login ──────────────────────────────────────
let _qrToken   = null;
let _qrTimer   = null;
let _pollTimer = null;
let _segsLeft  = 120;
 
function generarQR() {
  clearInterval(_qrTimer);
  clearInterval(_pollTimer);
  _qrToken = null;
 
  document.getElementById('qr-status').textContent = '⏳ Generando código QR...';
  document.getElementById('qr-timer').textContent   = '';
  document.getElementById('qr-img').src = '';
 
  fetch('qr_login_generar.php')
    .then(r => r.json())
    .then(data => {
      _qrToken  = data.token;
      _segsLeft = data.expires;
 
      // ✅ FIX: imagen servida por nuestro propio servidor (evita bloqueo de InfinityFree)
      document.getElementById('qr-img').src = data.img_url;
      document.getElementById('qr-status').textContent = '📷 Escanea con tu celular';
 
      // Countdown
      _qrTimer = setInterval(() => {
        _segsLeft--;
        const m = Math.floor(_segsLeft/60);
        const s = String(_segsLeft%60).padStart(2,'0');
        document.getElementById('qr-timer').textContent = `Expira en ${m}:${s}`;
        if (_segsLeft <= 0) {
          clearInterval(_qrTimer);
          clearInterval(_pollTimer);
          document.getElementById('qr-status').textContent = '⌛ Código expirado. Regenera.';
          document.getElementById('qr-timer').textContent = '';
          document.getElementById('qr-img-wrap').classList.remove('qr-scanning');
        }
      }, 1000);
 
      // Polling: preguntar al servidor cada 2 segundos
      _pollTimer = setInterval(() => {
        if (!_qrToken) return;
        fetch('qr_login_verificar.php?token=' + _qrToken)
          .then(r => r.json())
          .then(res => {
            if (res.status === 'pendiente') return;
            if (res.status === 'expirado') {
              clearInterval(_pollTimer);
              clearInterval(_qrTimer);
              document.getElementById('qr-status').textContent = '⌛ Código expirado. Regenera.';
              document.getElementById('qr-img-wrap').classList.remove('qr-scanning');
            }
            if (res.status === 'ok') {
              clearInterval(_pollTimer);
              clearInterval(_qrTimer);
              document.getElementById('qr-status').textContent = '✅ ¡Autenticado! Redirigiendo...';
              document.getElementById('qr-img-wrap').classList.add('qr-scanning');
              setTimeout(() => { window.location = res.redirect; }, 800);
            }
          });
      }, 2000);
    })
    .catch(() => {
      document.getElementById('qr-status').textContent = '❌ Error al generar QR. Intenta de nuevo.';
    });
}
</script>
</body>
</html>
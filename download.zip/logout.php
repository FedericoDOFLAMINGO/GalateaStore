<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * logout.php — Cierre de sesión con revocación global en BD
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 *
 * FIX: Opción de revocar TODAS las sesiones del usuario (cierre global)
 *      o solo la sesión actual.
 *
 * GET ?todas=1  → cierra sesión en TODOS los navegadores/dispositivos
 * GET           → cierra solo la sesión actual
 */

session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

if (!empty($_SESSION['session_token']) && !empty($_SESSION['usuario']['id'])) {

    $tokenActual = $_SESSION['session_token'];
    $userId      = (int)$_SESSION['usuario']['id'];

    if (isset($_GET['todas'])) {
        // ── CIERRE GLOBAL: revocar TODAS las sesiones del usuario ──────
        $stmt = $conn->prepare(
            "UPDATE sessions SET revoked = 1
             WHERE user_id = ? AND revoked = 0"
        );
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $stmt->close();

        // También revocar refresh tokens activos
        $stmt2 = $conn->prepare(
            "UPDATE refresh_tokens SET revoked = 1
             WHERE user_id = ? AND revoked = 0"
        );
        $stmt2->bind_param('i', $userId);
        $stmt2->execute();
        $stmt2->close();

    } else {
        // ── CIERRE LOCAL: solo revocar la sesión actual ─────────────────
        revocarSesion($conn, $tokenActual);
    }
}

// Destruir sesión PHP local
session_unset();
session_destroy();

// Regenerar cookie de sesión (prevenir session fixation)
session_start();
session_regenerate_id(true);
session_destroy();

header('Location: login.php');
exit;

<?php
/**
 * mailer.php — Gmail SMTP con PHPMailer (standalone, sin Composer)
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181 | IDGS 8B
 *
 * PASOS PARA ACTIVAR:
 *  1. Pon tu App Password de Gmail en MAIL_PASS (16 chars sin espacios)
 *     Google → Seguridad → Verificación en 2 pasos → Contraseñas de aplicación
 *  2. Los archivos de PHPMailer ya están en /phpmailer/ (incluidos en el ZIP)
 */

define('MAIL_HOST',      'smtp.gmail.com');
define('MAIL_PORT',      587);
define('MAIL_USER',      'fed3lh@gmail.com');
define('MAIL_PASS',      'qsmwgmhcjnpitcnq');   // ← 16 chars SIN espacios
define('MAIL_FROM_NAME', 'One Piece Preventas');
define('MAIL_FROM_ADDR', MAIL_USER);

// Cargar PHPMailer standalone (carpeta /phpmailer/ en la raíz)
$_phpmailerPath = __DIR__ . '/phpmailer/PHPMailer.php';
if (!defined('MAILER_AVAILABLE')) {
    if (file_exists($_phpmailerPath)) {
        require_once __DIR__ . '/phpmailer/PHPMailer.php';
        require_once __DIR__ . '/phpmailer/SMTP.php';
        require_once __DIR__ . '/phpmailer/Exception.php';
        define('MAILER_AVAILABLE', true);
    } else {
        define('MAILER_AVAILABLE', false);
    }
}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function enviarCorreo(string $toEmail, string $toName, string $subject, string $htmlBody, string $plainBody = ''): bool {
    if (!MAILER_AVAILABLE) {
        error_log("[MAILER] PHPMailer no disponible. Correo NO enviado a: $toEmail");
        return false;
    }
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = MAIL_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = MAIL_USER;
        $mail->Password   = MAIL_PASS;
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = MAIL_PORT;
        $mail->CharSet    = 'UTF-8';
        $mail->Encoding   = 'base64';
        $mail->setFrom(MAIL_FROM_ADDR, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody = $plainBody ?: strip_tags($htmlBody);
        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("[MAILER ERROR] No se pudo enviar a $toEmail: " . $mail->ErrorInfo);
        return false;
    }
}

function mailTemplate(string $titulo, string $contenido): string {
    return <<<HTML
<!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>{$titulo}</title></head>
<body style="margin:0;padding:0;background:#1a0f08;font-family:'Segoe UI',sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#1a0f08;padding:40px 0;">
  <tr><td align="center">
    <table width="520" cellpadding="0" cellspacing="0"
      style="background:#2c1f14;border:2px solid #f7d67a;border-radius:12px;overflow:hidden;">
      <tr>
        <td style="background:linear-gradient(135deg,#422f1a,#2c1f14);padding:24px 32px;text-align:center;border-bottom:2px solid #f7d67a;">
          <div style="font-size:2rem;">☠️</div>
          <h1 style="color:#ffcb45;font-size:1.3rem;margin:4px 0 0;">One Piece Preventas</h1>
          <p style="color:rgba(247,214,122,0.5);font-size:0.8rem;margin:2px 0 0;">🏴‍☠️ Galatea Store</p>
        </td>
      </tr>
      <tr><td style="padding:28px 32px;color:#f7d67a;">{$contenido}</td></tr>
      <tr>
        <td style="background:#1a0f08;padding:14px 32px;text-align:center;border-top:1px solid rgba(247,214,122,0.15);">
          <p style="color:rgba(247,214,122,0.35);font-size:0.72rem;margin:0;">
            © 2026 One Piece Preventas · Galatea Store
          </p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body></html>
HTML;
}

function enviarOTPEmailReal(string $email, string $nombre, string $code): bool {
    $expMin  = defined('MFA_CODE_EXPIRY_MIN') ? MFA_CODE_EXPIRY_MIN : 10;
    $subject = 'Tu código de verificación — One Piece Preventas';
    $body    = <<<HTML
      <h2 style="color:#ffcb45;font-size:1.1rem;margin:0 0 14px;">🔐 Código de verificación</h2>
      <p style="color:rgba(247,214,122,0.85);font-size:0.9rem;margin:0 0 18px;">
        Hola <strong style="color:#ffcb45;">{$nombre}</strong>, tu código OTP es:
      </p>
      <div style="text-align:center;margin:20px 0;">
        <span style="display:inline-block;background:#422f1a;border:2px solid #f7d67a;
          border-radius:10px;padding:14px 28px;font-size:2rem;font-weight:bold;
          color:#ffcb45;letter-spacing:12px;">{$code}</span>
      </div>
      <p style="color:rgba(247,214,122,0.5);font-size:0.8rem;text-align:center;">
        ⏱️ Expira en <strong>{$expMin} minutos</strong>. Si no fuiste tú, ignora este correo.
      </p>
HTML;
    return enviarCorreo($email, $nombre, $subject, mailTemplate($subject, $body),
        "Tu código OTP: $code — Expira en {$expMin} min.");
}

function enviarEmailRecuperacion(string $email, string $nombre, string $token, string $baseUrl = ''): bool {
    if (empty($baseUrl)) {
        $proto   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $baseUrl = $proto . '://' . ($_SERVER['HTTP_HOST'] ?? 'galateastore.infinityfreeapp.com');
    }
    $link    = $baseUrl . '/reset_password.php?token=' . $token;
    $subject = 'Recupera tu contraseña — One Piece Preventas';
    $body    = <<<HTML
      <h2 style="color:#ffcb45;font-size:1.1rem;margin:0 0 14px;">🔑 Recuperación de contraseña</h2>
      <p style="color:rgba(247,214,122,0.85);font-size:0.9rem;margin:0 0 18px;">
        Hola <strong style="color:#ffcb45;">{$nombre}</strong>, haz clic para restablecer tu contraseña:
      </p>
      <div style="text-align:center;margin:24px 0;">
        <a href="{$link}" style="display:inline-block;background:linear-gradient(135deg,#b07a20,#f7d67a);
          color:#1a0f08;text-decoration:none;font-weight:bold;padding:13px 28px;
          border-radius:8px;font-size:0.95rem;">🔑 Restablecer contraseña</a>
      </div>
      <p style="color:rgba(247,214,122,0.4);font-size:0.75rem;text-align:center;">
        ⏱️ Válido por <strong>30 minutos</strong>.
      </p>
HTML;
    return enviarCorreo($email, $nombre, $subject, mailTemplate($subject, $body),
        "Enlace: $link — Válido 30 min.");
}

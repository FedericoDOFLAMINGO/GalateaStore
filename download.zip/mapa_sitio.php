<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */

session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}
$rol = $_SESSION['usuario']['rol'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mapa del Sitio — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
</head>
<body class="dashboard-body">

<?php include 'navbar.php'; ?>
<?php
include 'breadcrumbs.php';
$bc = ['Inicio' => '/dashboard.php', 'Mapa del Sitio' => ''];
generarBreadcrumbs($bc);
?>

<div class="sitemap-container">
  <h1 class="page-title">🗺️ Mapa del Sitio</h1>

  <div class="sitemap-section">
    <h2>🏠 Páginas Principales</h2>
    <ul class="sitemap-tree">
      <li>📄 <a href="dashboard.php">Inicio / Dashboard</a></li>
      <li>📄 <a href="preventas_activas.php">Preventas Activas</a></li>
      <li>📄 <a href="ayuda.php">Centro de Ayuda</a></li>
      <li>📄 <a href="mapa_sitio.php">Mapa del Sitio</a></li>
    </ul>
  </div>

  <div class="sitemap-section">
    <h2>👤 Mi Cuenta</h2>
    <ul class="sitemap-tree">
      <li>📄 <a href="perfil.php">Mi Perfil</a></li>
      <li>📄 <a href="mis_pedidos.php">Mis Pedidos</a></li>
      <li>📄 <a href="hacer_pedido.php">Hacer Pedido</a></li>
      <li>📄 <a href="logout.php">Cerrar Sesión</a></li>
    </ul>
  </div>

  <?php if ($rol === 'admin'): ?>
  <div class="sitemap-section">
    <h2>⚙️ Administración</h2>
    <ul class="sitemap-tree">
      <li>📄 <a href="admin/panel_admin.php">Panel de Control</a></li>
      <li>📄 <a href="admin/agregar_preventa.php">Agregar Preventa</a></li>
      <li>📄 <a href="admin/editar_preventa.php">Editar Preventas</a></li>
    </ul>
  </div>
  <?php endif; ?>

  <div class="sitemap-section">
    <h2>🔐 Autenticación</h2>
    <ul class="sitemap-tree">
      <li>📄 <a href="login.php">Iniciar Sesión</a></li>
      <li>📄 <a href="register.php">Registrarse</a></li>
    </ul>
  </div>

  <div class="sitemap-section">
    <h2>⚠️ Páginas de Error</h2>
    <ul class="sitemap-tree">
      <li>📄 <a href="404.html">Error 404 — Página no encontrada</a></li>
      <li>📄 <a href="500.html">Error 500 — Error del servidor</a></li>
    </ul>
  </div>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="js/menu-scripts.js"></script>
</body>
</html>

<?php
/**
 * mfa_verificar.php — Verificación MFA: Email OTP / SMS / TOTP
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/seguridad/auth.php';
require_once __DIR__ . '/lib/totp.php';
require_once __DIR__ . '/config.php';

if (!isset($_SESSION['mfa_pending'])) {
    header('Location: login.php');
    exit;
}

$pending = $_SESSION['mfa_pending'];
$error   = '';
$ip      = getClientIP();

// Verificar si usuario tiene TOTP activo
$stmt = $conn->prepare("SELECT totp_secret, phone FROM clientes WHERE id = ?");
$stmt->bind_param('i', $pending['user_id']);
$stmt->execute();
$userData = $stmt->get_result()->fetch_assoc();
$stmt->close();

$tieneTOTP = !empty($userData['totp_secret']);
$tienePhone = !empty($userData['phone']);

// Método activo (por defecto email, puede cambiar con GET ?metodo=)
$metodo = $_SESSION['mfa_metodo'] ?? 'email';
if (isset($_GET['metodo']) && in_array($_GET['metodo'], ['email', 'sms', 'totp'])) {
    $metodo = $_GET['metodo'];
    $_SESSION['mfa_metodo'] = $metodo;
}

// Enviar código si es email o SMS y no se ha enviado aún
if (in_array($metodo, ['email', 'sms']) && !isset($_SESSION['mfa_enviado_' . $metodo])) {
    $code = generarCodigoMFA($conn, $pending['user_id'], $metodo);

    if ($metodo === 'email') {
        enviarOTPEmail($pending['correo'], $code, $pending['nombre_usuario']);
    } elseif ($metodo === 'sms' && $tienePhone) {
        require_once __DIR__ . '/lib/sms_twilio.php';
        enviarOTPSMS($userData['phone'], $code, $pending['nombre_usuario']);
    }
    $_SESSION['mfa_enviado_' . $metodo] = true;
}

$demoCode = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();
    $code = trim($_POST['mfa_code'] ?? '');
    $ok   = false;

    if ($metodo === 'totp') {
        $ok = TOTP::verify($userData['totp_secret'], $code);
    } else {
        $ok = validarCodigoMFA($conn, $pending['user_id'], $code, $metodo);
    }

    if ($ok) {
        unset($_SESSION['mfa_pending'],
              $_SESSION['mfa_enviado_email'], $_SESSION['mfa_enviado_sms'], $_SESSION['mfa_metodo']);
        session_regenerate_id(true);
        $sessionToken = crearSesionBD($conn, $pending['user_id'], $ip, getUserAgent());
        $sessionId    = (int)$conn->insert_id;
        $refreshToken = generarRefreshToken($conn, $pending['user_id'], $sessionId);
        $_SESSION['usuario'] = [
            'id'             => $pending['user_id'],
            'nombre_usuario' => $pending['nombre_usuario'],
            'rol'            => $pending['rol'],
            'correo'         => $pending['correo'],
        ];
        $_SESSION['session_token'] = $sessionToken;
        $_SESSION['refresh_token'] = $refreshToken;
        $_SESSION['show_welcome']  = true;
        header('Location: dashboard.php');
        exit;
    } else {
        $error = '❌ Código incorrecto o expirado.';
    }
}

// Reenviar código
if (isset($_GET['reenviar']) && in_array($metodo, ['email', 'sms'])) {
    unset($_SESSION['mfa_enviado_' . $metodo]);
    header('Location: mfa_verificar.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verificación MFA — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="login-body">
<div class="login-card">
  <img src="img/Sombrero.png" alt="Logo" style="width:60px;margin-bottom:10px;">
  <h2>Verificación en dos pasos</h2>

  <!-- Selector de método -->
  <div style="display:flex;gap:8px;justify-content:center;margin-bottom:16px;flex-wrap:wrap;">
    <a href="?metodo=email" class="btn-secondary" style="padding:6px 14px;font-size:0.82rem;<?= $metodo==='email'?'opacity:1;':'opacity:0.5;' ?>">📧 Email</a>
    <?php if ($tienePhone): ?>
    <a href="?metodo=sms" class="btn-secondary" style="padding:6px 14px;font-size:0.82rem;<?= $metodo==='sms'?'opacity:1;':'opacity:0.5;' ?>">📱 SMS</a>
    <?php endif; ?>
    <?php if ($tieneTOTP): ?>
    <a href="?metodo=totp" class="btn-secondary" style="padding:6px 14px;font-size:0.82rem;<?= $metodo==='totp'?'opacity:1;':'opacity:0.5;' ?>">🔑 Authenticator</a>
    <?php endif; ?>
  </div>

  <p class="subtitle" style="font-size:0.88rem;">
    <?php if ($metodo === 'totp'): ?>
      Ingresa el código de tu app <strong>Google Authenticator</strong>
    <?php elseif ($metodo === 'sms'): ?>
      Código enviado por SMS a tu teléfono registrado
    <?php else: ?>
      Código enviado a <strong style="color:var(--gold-bright);"><?= htmlspecialchars($pending['correo']) ?></strong>
    <?php endif; ?>
  </p>



  <?php if ($error): ?>
    <div class="alert-error"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>

  <form method="POST">
    <?= csrf_field() ?>
    <div class="form-group">
      <label>Código de verificación</label>
      <input type="text" name="mfa_code" placeholder="000000"
             maxlength="6" minlength="6" pattern="\d{6}" required autofocus
             style="letter-spacing:8px;font-size:1.4rem;text-align:center;">
    </div>
    <button type="submit" class="btn-primary">✅ Verificar</button>
  </form>

  <?php if (in_array($metodo, ['email', 'sms'])): ?>
  <div style="text-align:center;margin-top:12px;font-size:0.82rem;">
    <a href="?reenviar=1" style="color:rgba(247,214,122,0.6);text-decoration:none;">🔄 Reenviar código</a>
  </div>
  <?php endif; ?>

  <div style="text-align:center;margin-top:8px;">
    <a href="login.php" style="font-size:0.8rem;color:rgba(247,214,122,0.4);text-decoration:none;">← Cancelar</a>
  </div>
</div>
</body>
</html>

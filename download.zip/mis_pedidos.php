<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 *
 * mis_pedidos.php — El usuario ve sus pedidos y elige tipo de entrega
 *                   (solo disponible cuando estado = 'pagado')
 */

session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';
requireRole('cliente');

if (!isset($_SESSION['usuario'])) {
    header("Location: login.php");
    exit;
}

$cliente_id = $_SESSION['usuario']['id'];
$msg_ok  = "";
$msg_err = "";

// ── Guardar tipo de entrega ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {

    $pedido_id = intval($_POST['pedido_id'] ?? 0);

    // Verificar que este pedido pertenece al cliente
    $chk = $conn->prepare("SELECT id, estado FROM pedidos WHERE id=? AND cliente_id=?");
    $chk->bind_param("ii", $pedido_id, $cliente_id);
    $chk->execute();
    $ped = $chk->get_result()->fetch_assoc();
    $chk->close();

    if (!$ped) {
        $msg_err = "Pedido no encontrado.";
    } elseif ($ped['estado'] !== 'pagado' && $ped['estado'] !== 'pendiente_tipo_entrega') {
        $msg_err = "Este pedido no está listo para configurar la entrega.";
    } else {

        // ── Opción: Recoger en tienda ──────────────────────────────────
        if ($_POST['action'] === 'tienda') {
            $upd = $conn->prepare(
                "UPDATE pedidos SET tipo_entrega='tienda', estado='recogida_en_tienda' WHERE id=? AND cliente_id=?"
            );
            $upd->bind_param("ii", $pedido_id, $cliente_id);
            $upd->execute();
            $upd->close();

            // Historial
            $hist = $conn->prepare(
                "INSERT INTO pedidos_historial (pedido_id, estado_previo, estado_nuevo, cambiado_por, nota) VALUES (?,?,?,'cliente','Eligió recoger en tienda')"
            );
            $ep = $ped['estado']; $en = 'recogida_en_tienda';
            $hist->bind_param("iss", $pedido_id, $ep, $en);
            $hist->execute();
            $hist->close();

            $msg_ok = "¡Perfecto! Tu pedido está marcado para <strong>recoger en tienda</strong>. Te contactaremos para coordinar.";

        // ── Opción: Envío a domicilio ──────────────────────────────────
        } elseif ($_POST['action'] === 'envio') {
            $env_nombre    = trim($_POST['env_nombre']    ?? '');
            $env_telefono  = trim($_POST['env_telefono']  ?? '');
            $env_estado    = trim($_POST['env_estado']    ?? '');
            $env_ciudad    = trim($_POST['env_ciudad']    ?? '');
            $env_colonia   = trim($_POST['env_colonia']   ?? '');
            $env_calle     = trim($_POST['env_calle']     ?? '');
            $env_cp        = trim($_POST['env_cp']        ?? '');
            $env_paqueteria= trim($_POST['env_paqueteria']?? '');
            $env_refs      = trim($_POST['env_referencias']?? '');

            if (!$env_nombre || !$env_telefono || !$env_estado || !$env_ciudad || !$env_calle || !$env_cp) {
                $msg_err = "Completa todos los campos obligatorios del formulario de envío.";
            } else {
                $upd = $conn->prepare(
                    "UPDATE pedidos SET
                       tipo_entrega='envio', estado='pendiente_pago_envio',
                       env_nombre=?, env_telefono=?, env_estado=?, env_ciudad=?,
                       env_colonia=?, env_calle=?, env_cp=?, env_paqueteria=?, env_referencias=?
                     WHERE id=? AND cliente_id=?"
                );
                $upd->bind_param(
                    "sssssssssii",
                    $env_nombre, $env_telefono, $env_estado, $env_ciudad,
                    $env_colonia, $env_calle, $env_cp, $env_paqueteria, $env_refs,
                    $pedido_id, $cliente_id
                );
                $upd->execute();
                $upd->close();

                $hist = $conn->prepare(
                    "INSERT INTO pedidos_historial (pedido_id, estado_previo, estado_nuevo, cambiado_por, nota) VALUES (?,?,?,'cliente','Eligió envío a domicilio')"
                );
                $ep = $ped['estado']; $en = 'pendiente_pago_envio';
                $hist->bind_param("iss", $pedido_id, $ep, $en);
                $hist->execute();
                $hist->close();

                $msg_ok = "¡Datos de envío guardados! Cotiza el flete por WhatsApp para continuar.";
            }

        // ── Subir comprobante de envío ─────────────────────────────────
        } elseif ($_POST['action'] === 'comprobante_envio') {
            if (isset($_FILES['comprobante_envio']) && $_FILES['comprobante_envio']['error'] === UPLOAD_ERR_OK) {
                $ext_ok = ['jpg','jpeg','png','pdf','webp'];
                $ext    = strtolower(pathinfo($_FILES['comprobante_envio']['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, $ext_ok) || $_FILES['comprobante_envio']['size'] > 5 * 1024 * 1024) {
                    $msg_err = "Formato inválido o archivo muy grande (máx 5MB, JPG/PNG/PDF).";
                } else {
                    $dir = __DIR__ . '/uploads/comprobantes/';
                    if (!is_dir($dir)) mkdir($dir, 0755, true);
                    $nombre_comp = 'envio_' . $cliente_id . '_' . $pedido_id . '_' . time() . '.' . $ext;
                    move_uploaded_file($_FILES['comprobante_envio']['tmp_name'], $dir . $nombre_comp);

                    $upd = $conn->prepare(
                        "UPDATE pedidos SET comprobante_envio=?, estado='envio_pagado' WHERE id=? AND cliente_id=?"
                    );
                    $upd->bind_param("sii", $nombre_comp, $pedido_id, $cliente_id);
                    $upd->execute();
                    $upd->close();

                    $hist = $conn->prepare(
                        "INSERT INTO pedidos_historial (pedido_id, estado_previo, estado_nuevo, cambiado_por, nota) VALUES (?,?,'envio_pagado','cliente','Subió comprobante de pago de envío')"
                    );
                    $ep = $ped['estado'];
                    $hist->bind_param("is", $pedido_id, $ep);
                    $hist->execute();
                    $hist->close();

                    $msg_ok = "¡Comprobante de envío recibido! El admin procesará tu pedido pronto.";
                }
            } else {
                $msg_err = "No se recibió ningún archivo.";
            }
        }
    }
}

// ── Cargar pedidos del cliente ─────────────────────────────────────────
$pedidos_result = $conn->prepare("
    SELECT p.*, pr.nombre_producto, pr.imagen_url, pr.precio
    FROM pedidos p
    JOIN preventas pr ON p.preventa_id = pr.id
    WHERE p.cliente_id = ?
    ORDER BY p.fecha_pedido DESC
");
$pedidos_result->bind_param("i", $cliente_id);
$pedidos_result->execute();
$pedidos = $pedidos_result->get_result();
$pedidos_result->close();

// Etiquetas de estado
function etiqueta_estado(string $est): array {
    return match($est) {
        'pendiente_pago'       => ['⏳ Pendiente de pago',        'badge-warn'],
        'pagado'               => ['✅ Pagado – Elige entrega',    'badge-active'],
        'pendiente_tipo_entrega'=> ['📦 Elige cómo recibir',       'badge-active'],
        'recogida_en_tienda'   => ['🏪 Recoger en tienda',        'badge-info'],
        'pendiente_pago_envio' => ['🚚 Cotizar/Pagar envío',      'badge-warn'],
        'envio_cotizado'       => ['💰 Envío cotizado – Pagar',   'badge-warn'],
        'envio_pagado'         => ['🧾 Envío pagado – En proceso','badge-info'],
        'en_camino'            => ['🚀 En camino',                 'badge-active'],
        'entregado'            => ['🎉 Entregado',                 'badge-active'],
        'cancelado'            => ['❌ Cancelado',                  'badge-inactive'],
        default                => ['❓ ' . $est,                   'badge-warn'],
    };
}

$estados_mx = [
    'Aguascalientes','Baja California','Baja California Sur','Campeche','Chiapas','Chihuahua',
    'Ciudad de México','Coahuila','Colima','Durango','Estado de México','Guanajuato','Guerrero',
    'Hidalgo','Jalisco','Michoacán','Morelos','Nayarit','Nuevo León','Oaxaca','Puebla',
    'Querétaro','Quintana Roo','San Luis Potosí','Sinaloa','Sonora','Tabasco','Tamaulipas',
    'Tlaxcala','Veracruz','Yucatán','Zacatecas'
];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Mis Pedidos — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
  <style>
    .pedido-card {
      background: rgba(30,20,10,.75);
      border: 1.5px solid rgba(247,214,122,.2);
      border-radius: 16px;
      padding: 22px 20px;
      margin-bottom: 24px;
      transition: border-color .2s;
    }
    .pedido-card:hover { border-color: rgba(247,214,122,.45); }

    .pedido-header {
      display: flex;
      align-items: center;
      gap: 16px;
      margin-bottom: 16px;
      flex-wrap: wrap;
    }
    .pedido-header img {
      width: 70px; height: 70px;
      object-fit: cover;
      border-radius: 10px;
      border: 1.5px solid rgba(247,214,122,.3);
    }
    .pedido-header-info { flex: 1; min-width: 140px; }
    .pedido-header-info h3 {
      font-family:'Pirata One',serif;
      color:var(--gold-bright);
      margin:0 0 4px;
      font-size:1.1rem;
    }

    /* Badges */
    .badge { padding:4px 12px; border-radius:20px; font-size:.78rem; font-weight:700; }
    .badge-active   { background:rgba(80,200,100,.15); color:#7ee8a0; border:1px solid rgba(80,200,100,.3); }
    .badge-inactive { background:rgba(220,60,60,.15);  color:#f88;    border:1px solid rgba(220,60,60,.3);  }
    .badge-warn     { background:rgba(247,180,60,.15); color:#f7d47a; border:1px solid rgba(247,180,60,.3); }
    .badge-info     { background:rgba(60,140,220,.15); color:#7ec8f8; border:1px solid rgba(60,140,220,.3); }

    /* Tabs de tipo entrega */
    .entrega-tabs {
      display: flex; gap: 10px; margin-bottom: 18px; flex-wrap: wrap;
    }
    .tab-btn {
      padding: 10px 20px;
      border-radius: 10px;
      border: 1.5px solid rgba(247,214,122,.3);
      background: transparent;
      color: rgba(247,214,122,.7);
      cursor: pointer;
      font-size: .9rem;
      transition: all .2s;
    }
    .tab-btn.active, .tab-btn:hover {
      background: rgba(247,214,122,.15);
      border-color: var(--gold-bright);
      color: #fff;
    }
    .tab-content { display: none; }
    .tab-content.active { display: block; }

    /* Formulario envío */
    .env-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px 16px;
    }
    @media(max-width:580px){ .env-grid { grid-template-columns: 1fr; } }
    .env-grid .full { grid-column: 1/-1; }

    .env-grid label { font-size:.83rem; color:var(--gold-bright); font-weight:600; display:block; margin-bottom:4px; }
    .env-grid input,
    .env-grid select,
    .env-grid textarea {
      width:100%;
      background:rgba(255,255,255,.07);
      border:1px solid rgba(247,214,122,.25);
      color:#fff;
      border-radius:8px;
      padding:9px 12px;
      font-size:.88rem;
    }
    .env-grid select option { background:#2a1a0d; }

    .btn-envio-submit {
      margin-top:14px;
      padding:12px 28px;
      background:var(--gold-bright);
      color:var(--dark-brown);
      font-weight:800;
      border:none;
      border-radius:10px;
      cursor:pointer;
      font-size:.95rem;
      transition:opacity .2s;
    }
    .btn-envio-submit:hover { opacity:.88; }

    /* WA button */
    .btn-wa {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      background: #25D366;
      color: #fff;
      font-weight: 700;
      padding: 10px 18px;
      border-radius: 10px;
      text-decoration: none;
      font-size: .9rem;
      transition: opacity .2s;
      margin-top: 10px;
    }
    .btn-wa:hover { opacity: .88; }

    /* Caja de costo cotizado */
    .costo-envio-box {
      background: rgba(247,214,122,.08);
      border: 1.5px solid rgba(247,214,122,.3);
      border-radius: 10px;
      padding: 14px 18px;
      margin: 12px 0;
    }

    /* Comprobante */
    .comp-form { margin-top: 12px; }
    .comp-form input[type=file] {
      background: rgba(255,255,255,.07);
      border: 1px solid rgba(247,214,122,.3);
      color: #fff;
      border-radius: 8px;
      padding: 9px 12px;
      width: 100%;
      margin-bottom: 10px;
    }

    .msg-ok  { background:rgba(80,200,100,.15); border:1.5px solid rgba(80,200,100,.4); color:#7ee8a0; padding:14px 18px; border-radius:10px; margin:16px 0; }
    .msg-err { background:rgba(220,60,60,.15);  border:1.5px solid rgba(220,60,60,.4);  color:#f88;    padding:14px 18px; border-radius:10px; margin:16px 0; }

    .seccion-entrega {
      border-top: 1px solid rgba(247,214,122,.15);
      padding-top: 16px;
      margin-top: 8px;
    }
    .seccion-entrega h4 {
      font-family:'Pirata One',serif;
      color:var(--gold-bright);
      margin:0 0 12px;
    }

    .info-row { display:flex; gap:10px; flex-wrap:wrap; font-size:.85rem; color:rgba(247,214,122,.75); margin:3px 0; }
    .info-row strong { color:#fff; }
  </style>
</head>
<body class="dashboard-body">

<?php include 'navbar.php'; ?>
<?php
include 'breadcrumbs.php';
$bc = ['Inicio' => '/dashboard.php', 'Mis Pedidos' => ''];
generarBreadcrumbs($bc);
?>

<div class="page-content">
  <h1 class="page-title">📦 Mis Pedidos</h1>

  <?php if ($msg_ok): ?>
    <div class="msg-ok">✅ <?php echo $msg_ok; ?></div>
  <?php endif; ?>
  <?php if ($msg_err): ?>
    <div class="msg-err">❌ <?php echo htmlspecialchars($msg_err); ?></div>
  <?php endif; ?>

  <?php if ($pedidos->num_rows === 0): ?>
    <div style="text-align:center;padding:50px;">
      <p style="color:rgba(247,214,122,.5);">Aún no tienes pedidos.</p>
      <a href="preventas_activas.php"
         style="display:inline-block;margin-top:14px;padding:12px 24px;background:var(--gold-bright);color:var(--dark-brown);border-radius:10px;text-decoration:none;font-weight:700;">
        🛒 Ver Preventas
      </a>
    </div>
  <?php else: ?>
    <?php while ($p = $pedidos->fetch_assoc()):
      [$label_est, $badge_cls] = etiqueta_estado($p['estado'] ?? 'pendiente_pago');
      $subtotal = ($p['precio'] ?? 0) * ($p['cantidad'] ?? 1);
    ?>

    <div class="pedido-card">

      <!-- ── Encabezado ── -->
      <div class="pedido-header">
        <img src="<?php echo htmlspecialchars($p['imagen_url'] ?? ''); ?>"
             alt="<?php echo htmlspecialchars($p['nombre_producto']); ?>"
             onerror="this.src='img/op13.jpeg'">
        <div class="pedido-header-info">
          <h3><?php echo htmlspecialchars($p['nombre_producto']); ?></h3>
          <div style="font-size:.82rem;color:rgba(247,214,122,.55);">
            Pedido #<?php echo $p['id']; ?> ·
            <?php echo date('d/m/Y H:i', strtotime($p['fecha_pedido'])); ?>
          </div>
        </div>
        <span class="badge <?php echo $badge_cls; ?>"><?php echo $label_est; ?></span>
      </div>

      <!-- ── Info básica ── -->
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin-bottom:14px;">
        <div class="info-row">Cantidad: <strong><?php echo $p['cantidad']; ?> ud.</strong></div>
        <div class="info-row">Subtotal: <strong>$<?php echo number_format($subtotal, 2); ?> MXN</strong></div>
        <?php if ($p['costo_envio']): ?>
          <div class="info-row">Costo envío: <strong>$<?php echo number_format($p['costo_envio'], 2); ?> MXN</strong></div>
        <?php endif; ?>
        <?php if ($p['comprobante_pago']): ?>
          <div class="info-row">
            Comprobante pago:
            <a href="uploads/comprobantes/<?php echo htmlspecialchars($p['comprobante_pago']); ?>"
               target="_blank" style="color:var(--gold-bright);">Ver archivo</a>
          </div>
        <?php endif; ?>
      </div>

      <!-- ══════════════════════════════════════════════════════════
           SECCIÓN DE ENTREGA — sólo si el pedido está pagado
           ══════════════════════════════════════════════════════════ -->
      <?php
        $puede_elegir = in_array($p['estado'] ?? '', ['pagado', 'pendiente_tipo_entrega']);
        $es_envio     = $p['tipo_entrega'] === 'envio';
        $es_tienda    = $p['tipo_entrega'] === 'tienda';
        $pend_pago_envio = $p['estado'] === 'pendiente_pago_envio';
        $costo_cotizado  = $p['estado'] === 'envio_cotizado';
        $envio_pagado    = in_array($p['estado'] ?? '', ['envio_pagado','en_camino','entregado']);
      ?>

      <?php if ($puede_elegir): ?>
      <!-- ── Tabs para elegir entrega ── -->
      <div class="seccion-entrega">
        <h4>📬 ¿Cómo deseas recibir tu pedido?</h4>
        <div class="entrega-tabs">
          <button class="tab-btn active" onclick="switchTab(<?php echo $p['id']; ?>, 'tienda', this)">
            🏪 Recoger en tienda
          </button>
          <button class="tab-btn" onclick="switchTab(<?php echo $p['id']; ?>, 'envio', this)">
            🚚 Envío a domicilio
          </button>
        </div>

        <!-- Tab: Tienda -->
        <div id="tab-tienda-<?php echo $p['id']; ?>" class="tab-content active">
          <div style="background:rgba(80,200,100,.08);border:1px solid rgba(80,200,100,.25);border-radius:10px;padding:14px 18px;font-size:.88rem;color:rgba(247,214,122,.85);">
            ✅ Recogerás tu pedido directamente en tienda.<br>
            Te contactaremos por WhatsApp para coordinar lugar y horario.<br>
            <br>
            <a class="btn-wa"
               href="https://wa.me/524491059872?text=Hola%2C%20quiero%20recoger%20mi%20pedido%20%23<?php echo $p['id']; ?>%20(%20<?php echo urlencode($p['nombre_producto']); ?>%20)%20en%20tienda.%20%C2%BFC%C3%B3mo%20coordinamos%3F"
               target="_blank">
              📲 Coordinar por WhatsApp
            </a>
          </div>
          <form method="POST" style="margin-top:14px;">
            <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
            <input type="hidden" name="action" value="tienda">
            <button type="submit" class="btn-envio-submit">✅ Confirmar — Recoger en tienda</button>
          </form>
        </div>

        <!-- Tab: Envío -->
        <div id="tab-envio-<?php echo $p['id']; ?>" class="tab-content">
          <div style="background:rgba(247,180,60,.07);border:1px solid rgba(247,180,60,.25);border-radius:10px;padding:12px 16px;margin-bottom:14px;font-size:.84rem;color:rgba(247,214,122,.8);">
            🚀 <strong style="color:#fff;">Envíos disponibles:</strong>
            Estafeta · DHL · FedEx · Redpack · J&T · Mercado Envíos<br>
            El costo del envío se cotiza por WhatsApp <strong>antes de pagar</strong>.
            Rango estimado: <strong style="color:#fff;">$80 – $350 MXN</strong> según peso y destino.
          </div>
          <form method="POST">
            <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
            <input type="hidden" name="action" value="envio">
            <div class="env-grid">
              <div>
                <label>Nombre completo *</label>
                <input type="text" name="env_nombre" placeholder="Tu nombre" required>
              </div>
              <div>
                <label>Teléfono *</label>
                <input type="tel" name="env_telefono" placeholder="10 dígitos" required>
              </div>
              <div>
                <label>Estado *</label>
                <select name="env_estado" required>
                  <option value="">— Elige —</option>
                  <?php foreach ($estados_mx as $emx): ?>
                    <option value="<?php echo $emx; ?>"><?php echo $emx; ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div>
                <label>Ciudad / Municipio *</label>
                <input type="text" name="env_ciudad" placeholder="Ciudad" required>
              </div>
              <div class="full">
                <label>Calle y número *</label>
                <input type="text" name="env_calle" placeholder="Ej. Av. Insurgentes 123 Int. 4B" required>
              </div>
              <div>
                <label>Colonia</label>
                <input type="text" name="env_colonia" placeholder="Colonia">
              </div>
              <div>
                <label>Código postal *</label>
                <input type="text" name="env_cp" placeholder="5 dígitos" maxlength="5" required>
              </div>
              <div class="full">
                <label>Preferencia de paquetería</label>
                <select name="env_paqueteria">
                  <option value="sin preferencia">Sin preferencia</option>
                  <option value="Estafeta">Estafeta</option>
                  <option value="DHL">DHL</option>
                  <option value="FedEx">FedEx</option>
                  <option value="Redpack">Redpack</option>
                  <option value="J&T Express">J&T Express</option>
                  <option value="Mercado Envíos">Mercado Envíos</option>
                </select>
              </div>
              <div class="full">
                <label>Referencias adicionales</label>
                <input type="text" name="env_referencias" placeholder="Ej. Casa blanca con reja negra, entre calle X y Y">
              </div>
            </div>
            <br>
            <!-- Botón WA para cotizar -->
            <a class="btn-wa"
               href="https://wa.me/524491059872?text=Hola%2C%20quiero%20cotizar%20el%20env%C3%ADo%20de%20mi%20pedido%20%23<?php echo $p['id']; ?>%20(<?php echo urlencode($p['nombre_producto']); ?>).%20Cantidad%3A%20<?php echo $p['cantidad']; ?>.%20CP%20destino%3A%20%5Bmi%20CP%5D"
               target="_blank">
              📲 Cotizar envío por WhatsApp antes de confirmar
            </a>
            <br>
            <button type="submit" class="btn-envio-submit" style="margin-top:14px;">
              🚚 Guardar datos y solicitar envío
            </button>
          </form>
        </div>
      </div><!-- /seccion-entrega -->

      <?php elseif ($es_tienda): ?>
        <!-- ── Ya eligió tienda ── -->
        <div class="seccion-entrega">
          <h4>🏪 Recoger en tienda</h4>
          <div style="font-size:.87rem;color:rgba(247,214,122,.75);">
            El admin coordinará contigo por WhatsApp para la entrega.<br>
            <a class="btn-wa" style="margin-top:10px;"
               href="https://wa.me/524491059872?text=Hola%2C%20soy%20<?php echo urlencode($_SESSION['usuario']['nombre_usuario'] ?? ''); ?>.%20Mi%20pedido%20%23<?php echo $p['id']; ?>%20est%C3%A1%20marcado%20para%20recoger%20en%20tienda.%20%C2%BFCu%C3%A1ndo%20lo%20puedo%20pasar%20a%20recoger%3F"
               target="_blank">
              📲 Preguntar sobre mi pedido
            </a>
          </div>
        </div>

      <?php elseif ($es_envio): ?>
        <!-- ── Ya eligió envío ── -->
        <div class="seccion-entrega">
          <h4>🚚 Envío a domicilio</h4>
          <!-- Datos guardados -->
          <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:8px;font-size:.85rem;margin-bottom:14px;">
            <?php if ($p['env_nombre']): ?>
              <div class="info-row">Destinatario: <strong><?php echo htmlspecialchars($p['env_nombre']); ?></strong></div>
            <?php endif; ?>
            <?php if ($p['env_telefono']): ?>
              <div class="info-row">Teléfono: <strong><?php echo htmlspecialchars($p['env_telefono']); ?></strong></div>
            <?php endif; ?>
            <?php if ($p['env_estado']): ?>
              <div class="info-row">Estado: <strong><?php echo htmlspecialchars($p['env_estado']); ?></strong></div>
            <?php endif; ?>
            <?php if ($p['env_ciudad']): ?>
              <div class="info-row">Ciudad: <strong><?php echo htmlspecialchars($p['env_ciudad']); ?></strong></div>
            <?php endif; ?>
            <?php if ($p['env_calle']): ?>
              <div class="info-row">Dirección: <strong><?php echo htmlspecialchars($p['env_calle'] . ' ' . $p['env_colonia']); ?></strong></div>
            <?php endif; ?>
            <?php if ($p['env_cp']): ?>
              <div class="info-row">CP: <strong><?php echo htmlspecialchars($p['env_cp']); ?></strong></div>
            <?php endif; ?>
            <?php if ($p['env_paqueteria']): ?>
              <div class="info-row">Paquetería: <strong><?php echo htmlspecialchars($p['env_paqueteria']); ?></strong></div>
            <?php endif; ?>
          </div>

          <?php if ($pend_pago_envio): ?>
            <!-- Sin cotización aún -->
            <div style="background:rgba(247,180,60,.08);border:1px solid rgba(247,180,60,.3);border-radius:10px;padding:14px;font-size:.87rem;color:rgba(247,214,122,.85);margin-bottom:12px;">
              ⏳ Esperando cotización del envío.<br>
              Cotiza el flete por WhatsApp para que el admin registre el costo.
            </div>
            <a class="btn-wa"
               href="https://wa.me/524491059872?text=Hola%2C%20soy%20<?php echo urlencode($_SESSION['usuario']['nombre_usuario'] ?? ''); ?>.%20Quiero%20cotizar%20el%20env%C3%ADo%20de%20mi%20pedido%20%23<?php echo $p['id']; ?>%20(<?php echo urlencode($p['nombre_producto']); ?>%20x<?php echo $p['cantidad']; ?>).%20CP%20destino%3A%20<?php echo urlencode($p['env_cp'] ?? ''); ?>.%20Paqueter%C3%ADa%20preferida%3A%20<?php echo urlencode($p['env_paqueteria'] ?? 'sin preferencia'); ?>"
               target="_blank">
              📲 Cotizar envío por WhatsApp
            </a>

          <?php elseif ($costo_cotizado): ?>
            <!-- Admin ya puso el costo, usuario paga -->
            <div class="costo-envio-box">
              💰 <strong>Costo de envío cotizado:</strong>
              <span style="color:var(--gold-bright);font-size:1.2rem;font-weight:800;margin-left:8px;">
                $<?php echo number_format($p['costo_envio'], 2); ?> MXN
              </span>
              <?php if ($p['notas_admin']): ?>
                <br><small style="color:rgba(247,214,122,.6);"><?php echo htmlspecialchars($p['notas_admin']); ?></small>
              <?php endif; ?>
            </div>
            <p style="font-size:.85rem;color:rgba(247,214,122,.75);margin:8px 0;">
              Realiza el pago del envío y sube tu comprobante:
            </p>
            <div style="display:flex;flex-wrap:wrap;gap:14px;margin-bottom:12px;font-size:.85rem;">
              <div style="background:rgba(30,20,10,.7);border:1px solid rgba(247,214,122,.2);border-radius:10px;padding:12px 16px;">
                🏦 SPEI — CLABE: <strong>012320001234567890</strong> (BBVA · Fernando Ledesma)
              </div>
              <div style="background:rgba(30,20,10,.7);border:1px solid rgba(247,214,122,.2);border-radius:10px;padding:12px 16px;">
                📱 CoDi — <strong>449 105 9872</strong>
              </div>
            </div>
            <form method="POST" enctype="multipart/form-data" class="comp-form">
              <input type="hidden" name="pedido_id" value="<?php echo $p['id']; ?>">
              <input type="hidden" name="action" value="comprobante_envio">
              <label style="color:var(--gold-bright);font-size:.85rem;font-weight:600;display:block;margin-bottom:6px;">
                📎 Subir comprobante de pago de envío
              </label>
              <input type="file" name="comprobante_envio" accept=".jpg,.jpeg,.png,.pdf,.webp" required>
              <button type="submit" class="btn-envio-submit">📤 Enviar comprobante</button>
            </form>

          <?php elseif ($envio_pagado): ?>
            <!-- Comprobante enviado / en camino -->
            <div style="background:rgba(60,140,220,.08);border:1px solid rgba(60,140,220,.3);border-radius:10px;padding:14px;font-size:.87rem;color:rgba(147,210,248,.9);">
              <?php if ($p['estado'] === 'en_camino'): ?>
                🚀 ¡Tu pedido está en camino! Rastreo disponible en WhatsApp.
              <?php elseif ($p['estado'] === 'entregado'): ?>
                🎉 ¡Entregado! Gracias por tu compra.
              <?php else: ?>
                🧾 Comprobante recibido. El admin procesará el envío pronto.
              <?php endif; ?>
            </div>
            <?php if ($p['estado'] === 'en_camino' || $p['estado'] === 'envio_pagado'): ?>
              <a class="btn-wa" style="margin-top:10px;"
                 href="https://wa.me/524491059872?text=Hola%2C%20quisiera%20el%20n%C3%BAmero%20de%20gu%C3%ADa%20de%20mi%20pedido%20%23<?php echo $p['id']; ?>"
                 target="_blank">
                📲 Pedir número de guía
              </a>
            <?php endif; ?>
          <?php endif; ?>

        </div><!-- /seccion-entrega envio -->
      <?php endif; ?>

    </div><!-- /pedido-card -->
    <?php endwhile; ?>
  <?php endif; ?>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="js/menu-scripts.js"></script>
<script>
function switchTab(pedidoId, tab, btn) {
  // Quitar active de todos los botones del card
  btn.closest('.entrega-tabs').querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  // Ocultar/mostrar tabs
  document.getElementById('tab-tienda-' + pedidoId).classList.remove('active');
  document.getElementById('tab-envio-'  + pedidoId).classList.remove('active');
  document.getElementById('tab-' + tab + '-' + pedidoId).classList.add('active');
}
</script>
</body>
</html>

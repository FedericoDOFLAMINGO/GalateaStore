<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
if (!isset($_SESSION)) session_start();

// ── Traducciones del navbar ───────────────────────────────────────────
if (!function_exists('getLang')) {
    $langFile = __DIR__ . '/lang/translations.php';
    if (!file_exists($langFile)) $langFile = __DIR__ . '/../lang/translations.php';
    if (file_exists($langFile)) require_once $langFile;
}
$_navLang  = $_SESSION['usuario']['language'] ?? 'es';
if (!function_exists('isValidLang') || !isValidLang($_navLang)) $_navLang = 'es';
$_navT     = function_exists('getLang') ? getLang($_navLang) : [];

// Helper local para evitar código verbose
function navT(string $key, array $t): string {
    return htmlspecialchars($t[$key] ?? $key);
}

$usuario    = $_SESSION['usuario']['nombre_usuario'] ?? '';
$rol        = $_SESSION['usuario']['rol'] ?? '';
$isLoggedIn = !empty($usuario);

// Determinar prefijo de ruta según si estamos en subdirectorio
$_navBase = strpos($_SERVER['PHP_SELF'] ?? '', '/admin/') !== false
            ? ''
            : '';
?>
<nav class="navbar-mejorado" id="mainNav">
  <div class="nav-container">
    <!-- Código desarrollado por Fernando Federico Ledesma Hernández,
         Estudiante de Ingeniería en Desarrollo y Gestión de Software,
         De la Universidad Tecnológica de Aguascalientes -->
    <a href="/dashboard.php" class="nav-logo">
      <img src="/img/Sombrero.png" alt="Logo" class="logo-img">
      <span class="logo-text">One Piece Preventas</span>
    </a>

    <!-- Logo de la tienda: Galatea Store -->
    <a href="/dashboard.php" class="galatea-logo-wrap" title="Galatea Store">
      <img src="/img/galatea_logo.jpeg" alt="Galatea Store" class="galatea-logo-img">
    </a>

    <button class="nav-toggle" id="navToggle" aria-label="Abrir menú" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>

    <ul class="nav-menu" id="navMenu">

      <!-- Búsqueda -->
      <li class="nav-item has-submenu">
        <a href="#" class="nav-link" onclick="return false;">
          🔍 <span><?= navT('nav_buscar',$_navT) ?></span><span class="arrow">▼</span>
        </a>
        <ul class="submenu search-dropdown">
          <form method="GET" action="/dashboard.php" class="search-form">
            <input type="text" name="q" placeholder="<?= navT('nav_buscar_ph',$_navT) ?>">
            <select name="categoria">
              <option value=""><?= navT('nav_todas_cat',$_navT) ?></option>
              <option value="accesorios">Accesorios</option>
              <option value="Starters">Starters</option>
              <option value="Expansiones">Expansiones</option>
              <option value="Figuras">Figuras</option>
            </select>
            <label>
              <input type="checkbox" name="disponible" value="1"> <?= navT('nav_solo_disp',$_navT) ?>
            </label>
            <button type="submit"><?= navT('nav_buscar_btn',$_navT) ?></button>
          </form>
        </ul>
      </li>

      <!-- Inicio -->
      <li class="nav-item">
        <a href="/dashboard.php" class="nav-link">
          <img src="/img/Sombrero.png" class="menu-icon-small" alt="">
          <span><?= navT('nav_inicio',$_navT) ?></span>
        </a>
      </li>

      <!-- Preventas -->
      <li class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <img src="/img/nami.png" class="menu-icon-small" alt="">
          <span><?= navT('nav_preventas',$_navT) ?></span><span class="arrow">▼</span>
        </a>
        <ul class="submenu">
          <li><a href="/preventas_activas.php">🛒 <?= navT('nav_ver_activas',$_navT) ?></a></li>
          <?php if ($isLoggedIn && $rol === 'cliente'): ?>
          <li><a href="/hacer_pedido.php">⚓ <?= navT('nav_hacer_pedido',$_navT) ?></a></li>
          <li><a href="/mis_pedidos.php">📦 <?= navT('nav_mis_pedidos',$_navT) ?></a></li>
          <?php endif; ?>
        </ul>
      </li>

      <!-- Admin -->
      <?php if ($rol === 'admin'): ?>
      <li class="nav-item has-submenu admin-only">
        <a href="#" class="nav-link">
          <img src="/img/usoop.png" class="menu-icon-small" alt="">
          <span><?= navT('nav_admin',$_navT) ?></span><span class="arrow">▼</span>
        </a>
        <ul class="submenu">
          <li><a href="/admin/panel_admin.php"><?= navT('nav_panel_admin',$_navT) ?></a></li>
          <li><a href="/admin/agregar_preventa.php"><?= navT('nav_agregar_prev',$_navT) ?></a></li>
          <li><a href="/admin/editar_preventa.php"><?= navT('nav_editar_prev',$_navT) ?></a></li>
          <li><a href="/admin/gestionar_usuarios.php"><?= navT('nav_gest_usuarios',$_navT) ?></a></li>
        </ul>
      </li>
      <?php endif; ?>

      <!-- Ayuda -->
      <li class="nav-item has-submenu">
        <a href="#" class="nav-link">
          <img src="/img/chooper.png" class="menu-icon-small" alt="">
          <span><?= navT('nav_ayuda',$_navT) ?></span><span class="arrow">▼</span>
        </a>
        <ul class="submenu">
          <li><a href="/ayuda.php#secMision"><?= navT('nav_mision',$_navT) ?></a></li>
          <li><a href="/ayuda.php#secVision"><?= navT('nav_vision',$_navT) ?></a></li>
          <li><a href="/ayuda.php#secQueSomos"><?= navT('nav_que_somos',$_navT) ?></a></li>
          <li><a href="/ayuda.php#secPedido"><?= navT('nav_como_pedido',$_navT) ?></a></li>
          <li><a href="/ayuda.php#secPagos"><?= navT('nav_pagos',$_navT) ?></a></li>
          <li><a href="/ayuda.php#secContacto"><?= navT('nav_contacto',$_navT) ?></a></li>
          <li><a href="/mapa_sitio.php"><?= navT('nav_mapa',$_navT) ?></a></li>
        </ul>
      </li>

      <!-- Usuario -->
      <?php if ($isLoggedIn): ?>
      <li class="nav-item user-menu">
        <div class="user-actions logged-user">
          <button class="user-profile" id="userProfile">
            <img src="/img/robin.png" alt="Perfil" class="user-avatar">
            <span><?php echo htmlspecialchars($usuario); ?></span>
            <span class="arrow">▼</span>
          </button>
          <ul class="user-submenu">
            <li><a href="/perfil.php"><?= navT('nav_mi_perfil',$_navT) ?></a></li>
            <li><a href="/mis_pedidos.php">📦 <?= navT('nav_mis_pedidos',$_navT) ?></a></li>
            <li><a href="/mapa_sitio.php">🗺️ Mapa del Sitio</a></li>
            <li><div class="divider"></div></li>
            <li>
              <a href="/logout.php" class="logout-link">
                <img src="/img/brook.png" class="menu-icon-small" alt="">
                <?= navT('nav_cerrar_sesion',$_navT) ?>
              </a>
            </li>
          </ul>
        </div>
      </li>
      <?php else: ?>
      <li class="nav-item user-menu">
        <div class="user-actions guest-user">
          <a href="/register.php" class="btn-register"><?= navT('nav_registrarse',$_navT) ?></a>
          <a href="/login.php" class="btn-login"><?= navT('nav_iniciar_sesion',$_navT) ?></a>
        </div>
      </li>
      <?php endif; ?>

    </ul>
  </div>
</nav>

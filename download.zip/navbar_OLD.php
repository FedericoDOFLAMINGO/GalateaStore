<?php
if (!isset($_SESSION)) session_start();

$usuario = $_SESSION['usuario']['nombre_usuario'] ?? '';
$rol = $_SESSION['usuario']['rol'] ?? '';
?>

<nav class="navbar">
  <ul class="menu">
    <li>
      <a href="/dashboard.php">
        <img src="/img/Sombrero.png" class="menu-icon">
        Inicio
      </a>
    </li>

    <?php if ($rol === 'admin'): ?>
      <li>
        <a href="/admin/agregar_preventa.php">
          <img src="/img/zoro.png" class="menu-icon">
         Agregar Preventa 
        </a>
      </li>
      <li>
        <a href="/preventas_activas.php">
          <img src="/img/nami.png" class="menu-icon">
            Ver Preventas
        </a>
      </li>
      <li>
        <a href="/admin/panel_admin.php">
          <img src="/img/usoop.png" class="menu-icon">
          Panel Admin
        </a>
      </li>
    <?php endif; ?>

    <li>
      <a href="/hacer_pedido.php">
        <img src="/img/chooper.png" class="menu-icon">
        Hacer Pedido
      </a>
    </li>
    <li>
      <a href="/mis_pedidos.php">
        <img src="/img/robin.png" class="menu-icon">
        Mis Pedidos
      </a>
    </li>
    <li>
      <a href="/logout.php">
        <img src="/img/brook.png" class="menu-icon">
        Cerrar Sesión
      </a>
    </li>
  </ul>
</nav>

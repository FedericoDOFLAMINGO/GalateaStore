<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * perfil.php — Módulo de configuración de usuario (Parte 3 de la práctica)
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 *
 * Funcionalidades (Parte 3):
 *  - Cambiar contraseña
 *  - Activar/desactivar MFA
 *  - Ver y cerrar sesiones activas (multisesiones)
 *  - Configurar preguntas secretas para recuperación
 *  - Configurar teléfono
 *  - Preferencias: tema y idioma (almacenados en BD)
 */

session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';
include __DIR__ . '/lang/translations.php';

$ip          = getClientIP();
$userId      = (int)$_SESSION['usuario']['id'];
$usuario     = $_SESSION['usuario']['nombre_usuario'];
$rol         = $_SESSION['usuario']['rol'];
$correo      = $_SESSION['usuario']['correo'] ?? '';
$tokenActual = $_SESSION['session_token'] ?? '';

// ── Idioma del usuario ───────────────────────────────────────────
$userLang = $_SESSION['usuario']['language'] ?? 'es';
if (!isValidLang($userLang)) $userLang = 'es';
$t = getLang($userLang);

$msg     = '';
$msgTipo = '';

// Mostrar mensaje de éxito tras redirección de preferencias
if (($_GET['saved'] ?? '') === '1') {
    $msg     = '✅ ' . ($t['perf_guardar_pref'] ?? 'Preferencias guardadas.');
    $msgTipo = 'ok';
}

// ── Cargar datos actuales del usuario desde BD ────────────────────────
$stmt = $conn->prepare(
    "SELECT mfa_enabled, phone, theme, language, secret_q1, secret_q2 FROM clientes WHERE id = ?"
);
$stmt->bind_param('i', $userId);
$stmt->execute();
$userData = $stmt->get_result()->fetch_assoc();
$stmt->close();

// ── PROCESAR ACCIONES POST ────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();
    $accion = $_POST['accion'] ?? '';

    // 1. Cambiar datos básicos de perfil
    if ($accion === 'perfil') {
        $nuevoNombre = trim($_POST['nombre_usuario'] ?? '');
        $nuevaPass   = $_POST['nueva_pass'] ?? '';
        $confirmar   = $_POST['confirmar_pass'] ?? '';
        $phone       = trim($_POST['phone'] ?? '');

        if (strlen($nuevoNombre) < 3) {
            $msg = 'El nombre debe tener al menos 3 caracteres.';
            $msgTipo = 'err';
        } elseif (!empty($nuevaPass) && $nuevaPass !== $confirmar) {
            $msg = 'Las contraseñas no coinciden.';
            $msgTipo = 'err';
        } elseif (!empty($nuevaPass) && strlen($nuevaPass) < 6) {
            $msg = 'La contraseña debe tener al menos 6 caracteres.';
            $msgTipo = 'err';
        } else {
            if (!empty($nuevaPass)) {
                $hash = password_hash($nuevaPass, PASSWORD_BCRYPT, ['cost' => 12]);
                $stmt = $conn->prepare("UPDATE clientes SET nombre_usuario=?, password=?, phone=? WHERE id=?");
                $stmt->bind_param('sssi', $nuevoNombre, $hash, $phone, $userId);
            } else {
                $stmt = $conn->prepare("UPDATE clientes SET nombre_usuario=?, phone=? WHERE id=?");
                $stmt->bind_param('ssi', $nuevoNombre, $phone, $userId);
            }
            if ($stmt->execute()) {
                $_SESSION['usuario']['nombre_usuario'] = $nuevoNombre;
                $usuario  = $nuevoNombre;
                $msg      = '✅ Perfil actualizado correctamente.';
                $msgTipo  = 'ok';
                $userData['phone'] = $phone;
            } else {
                $msg = '❌ Error al actualizar: ' . $stmt->error;
                $msgTipo = 'err';
            }
            $stmt->close();
        }
    }

    // 2. Activar/desactivar MFA
    elseif ($accion === 'toggle_mfa') {
        $nuevoEstado = $userData['mfa_enabled'] ? 0 : 1;
        $stmt = $conn->prepare("UPDATE clientes SET mfa_enabled = ? WHERE id = ?");
        $stmt->bind_param('ii', $nuevoEstado, $userId);
        $stmt->execute();
        $stmt->close();
        $userData['mfa_enabled'] = $nuevoEstado;
        $msg     = $nuevoEstado ? '✅ MFA activado. Se pedirá código OTP al iniciar sesión.' : '⚠️ MFA desactivado.';
        $msgTipo = 'ok';
    }

    // 3. Cerrar sesión específica (por ID)
    elseif ($accion === 'revocar_sesion') {
        $sid = (int)($_POST['sesion_id'] ?? 0);
        // Verificar que la sesión pertenece a este usuario
        $stmt = $conn->prepare("UPDATE sessions SET revoked=1 WHERE id=? AND user_id=?");
        $stmt->bind_param('ii', $sid, $userId);
        $stmt->execute();
        $stmt->close();
        $msg = '✅ Sesión cerrada correctamente.';
        $msgTipo = 'ok';
    }

    // 4. Cerrar todas las demás sesiones
    elseif ($accion === 'revocar_otras') {
        $afectadas = revocarOtrasSesiones($conn, $userId, $tokenActual);
        $msg = "✅ Se cerraron $afectadas sesión(es) en otros dispositivos.";
        $msgTipo = 'ok';
    }

    // 5. Preguntas secretas para recuperación
    elseif ($accion === 'preguntas_secretas') {
        $q1 = trim($_POST['secret_q1'] ?? '');
        $a1 = trim($_POST['secret_a1'] ?? '');
        $q2 = trim($_POST['secret_q2'] ?? '');
        $a2 = trim($_POST['secret_a2'] ?? '');

        if (!$q1 || !$a1 || !$q2 || !$a2) {
            $msg = '❌ Completa todas las preguntas y respuestas.';
            $msgTipo = 'err';
        } else {
            // Almacenar respuestas hasheadas con bcrypt (no en texto plano)
            $h1 = password_hash(strtolower($a1), PASSWORD_BCRYPT);
            $h2 = password_hash(strtolower($a2), PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE clientes SET secret_q1=?, secret_a1=?, secret_q2=?, secret_a2=? WHERE id=?");
            $stmt->bind_param('ssssi', $q1, $h1, $q2, $h2, $userId);
            $stmt->execute();
            $stmt->close();
            $userData['secret_q1'] = $q1;
            $userData['secret_q2'] = $q2;
            $msg = '✅ Preguntas secretas guardadas (respuestas cifradas con bcrypt).';
            $msgTipo = 'ok';
        }
    }

    // 6. Preferencias (tema / idioma)
    elseif ($accion === 'preferencias') {
        $theme    = in_array($_POST['theme'] ?? '', ['dark','light']) ? $_POST['theme'] : 'dark';
        $language = in_array($_POST['language'] ?? '', ['es','en','fr','ja','zh']) ? $_POST['language'] : 'es';
        $stmt = $conn->prepare("UPDATE clientes SET theme=?, language=? WHERE id=?");
        $stmt->bind_param('ssi', $theme, $language, $userId);
        $stmt->execute();
        $stmt->close();
        $userData['theme']    = $theme;
        $userData['language'] = $language;
        // Sync session so navbar and ALL pages use correct language/theme immediately
        $_SESSION['usuario']['language'] = $language;
        $_SESSION['usuario']['theme']    = $theme;
        // Redirect to reload page with new theme + language applied
        header('Location: perfil.php?saved=1');
        exit;
    }
}

// Listar sesiones activas
$sesionesActivas = listarSesiones($conn, $userId);
?>
<!DOCTYPE html>
<html lang="<?= $userLang ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($t['perf_title']) ?></title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
  <?php
  $userTheme = $userData['theme'] ?? 'dark';
  if ($userTheme === 'light'): ?>
  <style>
    body.theme-light .perfil-card h1 { color:#5a3010!important; }
  </style>
  <?php endif; ?>
</head>
<body class="dashboard-body<?= ($userData['theme'] ?? 'dark') === 'light' ? ' theme-light' : '' ?>">
<?php include 'navbar.php'; ?>
<?php include 'breadcrumbs.php'; $bc = ['Inicio' => '/dashboard.php', 'Mi Perfil' => '']; generarBreadcrumbs($bc); ?>

<div class="perfil-container">
  <div class="perfil-card">

    <?php if ($msg): ?>
      <div class="msg-box msg-<?= $msgTipo ?>"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <!-- Cabecera -->
    <div class="perfil-avatar-wrap">
      <img id="perfil-avatar" src="img/robin.png"
           data-usuario="<?= htmlspecialchars($usuario) ?>"
           alt="Avatar" style="border-radius:50%;width:110px;height:110px;object-fit:cover;border:3px solid var(--gold);">
    </div>
    <p id="avatar-personaje" style="font-size:0.8rem;color:rgba(247,214,122,0.5);text-align:center;margin-top:6px;"></p>
    <h1><?= htmlspecialchars($t['perf_h1']) ?></h1>
    <div class="info-row"><strong><?= htmlspecialchars($t['perf_usuario']) ?></strong> <?= htmlspecialchars($usuario) ?></div>
    <?php if ($correo): ?>
    <div class="info-row"><strong><?= htmlspecialchars($t['perf_correo']) ?></strong> <?= htmlspecialchars($correo) ?></div>
    <?php endif; ?>
    <div class="info-row"><strong><?= htmlspecialchars($t['perf_rol']) ?></strong> <?= ucfirst(htmlspecialchars($rol)) ?></div>
    <div class="info-row">
      <strong><?= htmlspecialchars($t['perf_mfa']) ?></strong>
      <span style="color:<?= $userData['mfa_enabled'] ? '#6ee89a' : 'rgba(247,214,122,0.5)' ?>">
        <?= $userData['mfa_enabled'] ? htmlspecialchars($t['perf_mfa_activo']) : htmlspecialchars($t['perf_mfa_inactivo']) ?>
      </span>
    </div>

    <hr class="section-divider">

    <!-- SECCIÓN 1: Editar perfil básico -->
    <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);font-size:1.3rem;"><?= htmlspecialchars($t['perf_edit_perfil']) ?></h2>
    <form method="POST" action="perfil.php">
      <?= csrf_field() ?>
      <input type="hidden" name="accion" value="perfil">
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_nombre_usr']) ?></label>
        <input type="text" name="nombre_usuario" value="<?= htmlspecialchars($usuario) ?>" required minlength="3">
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_telefono']) ?> <small style="color:rgba(247,214,122,0.5)"><?= htmlspecialchars($t['perf_tel_hint']) ?></small></label>
        <input type="text" name="phone" value="<?= htmlspecialchars($userData['phone'] ?? '') ?>" placeholder="+52 449 000 0000">
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_nueva_pass']) ?> <small style="color:rgba(247,214,122,0.5)"><?= htmlspecialchars($t['perf_pass_hint']) ?></small></label>
        <input type="password" name="nueva_pass" placeholder="Mínimo 6 caracteres" minlength="6">
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_confirmar']) ?></label>
        <input type="password" name="confirmar_pass" placeholder="Repite la contraseña">
      </div>
      <button type="submit" class="btn-submit"><?= htmlspecialchars($t['perf_guardar']) ?></button>
    </form>

    <hr class="section-divider">

    <!-- SECCIÓN 2: Control MFA -->
    <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);font-size:1.3rem;"><?= htmlspecialchars($t['perf_mfa_titulo']) ?></h2>
    <p style="font-size:0.85rem;color:rgba(247,214,122,0.6);margin-bottom:12px;">
      <?= htmlspecialchars($t['perf_mfa_desc']) ?>
    </p>
    <form method="POST" action="perfil.php">
      <?= csrf_field() ?>
      <input type="hidden" name="accion" value="toggle_mfa">
      <button type="submit" class="btn-submit" style="background:<?= $userData['mfa_enabled'] ? 'rgba(200,60,60,0.3)' : 'rgba(30,160,80,0.3)' ?>;">
        <?= $userData['mfa_enabled'] ? htmlspecialchars($t['perf_mfa_desact']) : htmlspecialchars($t['perf_mfa_activar']) ?>
      </button>
    </form>

    <hr class="section-divider">

    <!-- SECCIÓN 3: Preguntas secretas -->
    <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);font-size:1.3rem;"><?= htmlspecialchars($t['perf_preguntas']) ?></h2>
    <p style="font-size:0.85rem;color:rgba(247,214,122,0.6);margin-bottom:12px;">
      <?= htmlspecialchars($t['perf_preg_desc']) ?>
    </p>
    <form method="POST" action="perfil.php">
      <?= csrf_field() ?>
      <input type="hidden" name="accion" value="preguntas_secretas">
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_preg1']) ?></label>
        <select name="secret_q1">
          <option value="¿Cuál es el nombre de tu mascota?" <?= ($userData['secret_q1'] ?? '') === '¿Cuál es el nombre de tu mascota?' ? 'selected':'' ?>>¿Cuál es el nombre de tu mascota?</option>
          <option value="¿En qué ciudad naciste?" <?= ($userData['secret_q1'] ?? '') === '¿En qué ciudad naciste?' ? 'selected':'' ?>>¿En qué ciudad naciste?</option>
          <option value="¿Cuál es tu película favorita?" <?= ($userData['secret_q1'] ?? '') === '¿Cuál es tu película favorita?' ? 'selected':'' ?>>¿Cuál es tu película favorita?</option>
        </select>
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_resp1']) ?></label>
        <input type="text" name="secret_a1" placeholder="<?= htmlspecialchars($t['perf_resp1']) ?>" required>
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_preg2']) ?></label>
        <select name="secret_q2">
          <option value="¿Cuál fue tu primer trabajo?" <?= ($userData['secret_q2'] ?? '') === '¿Cuál fue tu primer trabajo?' ? 'selected':'' ?>>¿Cuál fue tu primer trabajo?</option>
          <option value="¿Cuál es el nombre de tu escuela primaria?" <?= ($userData['secret_q2'] ?? '') === '¿Cuál es el nombre de tu escuela primaria?' ? 'selected':'' ?>>¿Cuál es el nombre de tu escuela primaria?</option>
          <option value="¿Cuál es tu comida favorita?" <?= ($userData['secret_q2'] ?? '') === '¿Cuál es tu comida favorita?' ? 'selected':'' ?>>¿Cuál es tu comida favorita?</option>
        </select>
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_resp2']) ?></label>
        <input type="text" name="secret_a2" placeholder="<?= htmlspecialchars($t['perf_resp2']) ?>" required>
      </div>
      <button type="submit" class="btn-submit"><?= htmlspecialchars($t['perf_guardar_preg']) ?></button>
    </form>

    <hr class="section-divider">

    <!-- SECCIÓN 4: Sesiones activas -->
    <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);font-size:1.3rem;">
      <?= htmlspecialchars($t['perf_sesiones']) ?> (<?= count($sesionesActivas) ?>)
    </h2>
    <?php if (count($sesionesActivas) > 1): ?>
    <form method="POST" action="perfil.php" style="margin-bottom:16px;">
      <?= csrf_field() ?>
      <input type="hidden" name="accion" value="revocar_otras">
      <button type="submit" class="btn-submit" style="background:rgba(200,60,60,0.25);border-color:rgba(200,80,80,0.4);">
        <?= htmlspecialchars($t['perf_cerrar_otras']) ?>
      </button>
    </form>
    <?php endif; ?>
    <div style="display:flex;flex-direction:column;gap:10px;">
    <?php foreach ($sesionesActivas as $ses): ?>
      <?php $esActual = ($ses['session_token'] === $tokenActual); ?>
      <div style="background:rgba(30,18,10,0.7);border:1px solid rgba(247,214,122,<?= $esActual ? '0.4' : '0.15' ?>);border-radius:10px;padding:12px 14px;">
        <div style="font-size:0.8rem;color:var(--gold-bright);margin-bottom:4px;">
          <?= $esActual ? '✅ <strong>Sesión actual</strong>' : '💻 Otra sesión' ?>
        </div>
        <div style="font-size:0.75rem;color:rgba(247,214,122,0.6);">
          🌐 IP: <?= htmlspecialchars($ses['ip_address']) ?><br>
          🖥️ <?= htmlspecialchars(substr($ses['user_agent'], 0, 80)) ?>…<br>
          🕐 Iniciada: <?= $ses['created_at'] ?> | Última actividad: <?= $ses['last_activity'] ?>
        </div>
        <?php if (!$esActual): ?>
        <form method="POST" action="perfil.php" style="margin-top:8px;">
          <?= csrf_field() ?>
          <input type="hidden" name="accion" value="revocar_sesion">
          <input type="hidden" name="sesion_id" value="<?= $ses['id'] ?>">
          <button type="submit" style="font-size:0.75rem;background:rgba(200,60,60,0.2);border:1px solid rgba(200,80,80,0.4);color:#ff8a8a;border-radius:6px;padding:4px 10px;cursor:pointer;">
            <?= htmlspecialchars($t['perf_cerrar_ses']) ?>
          </button>
        </form>
        <?php endif; ?>
      </div>
    <?php endforeach; ?>
    </div>

    <hr class="section-divider">

    <!-- SECCIÓN 5: Preferencias -->
    <h2 style="font-family:'Pirata One',serif;color:var(--gold-bright);font-size:1.3rem;"><?= htmlspecialchars($t['perf_preferencias']) ?></h2>
    <form method="POST" action="perfil.php">
      <?= csrf_field() ?>
      <input type="hidden" name="accion" value="preferencias">
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_tema']) ?></label>
        <select name="theme">
          <option value="dark" <?= ($userData['theme'] ?? 'dark') === 'dark' ? 'selected':'' ?>><?= htmlspecialchars($t['perf_tema_oscuro']) ?></option>
          <option value="light" <?= ($userData['theme'] ?? 'dark') === 'light' ? 'selected':'' ?>><?= htmlspecialchars($t['perf_tema_claro']) ?></option>
        </select>
      </div>
      <div class="form-field">
        <label><?= htmlspecialchars($t['perf_idioma']) ?></label>
        <select name="language">
          <option value="es" <?= ($userData['language'] ?? 'es') === 'es' ? 'selected':'' ?>>🇲🇽 Español</option>
          <option value="en" <?= ($userData['language'] ?? 'es') === 'en' ? 'selected':'' ?>>🇺🇸 English</option>
          <option value="fr" <?= ($userData['language'] ?? 'es') === 'fr' ? 'selected':'' ?>>🇫🇷 Français</option>
          <option value="ja" <?= ($userData['language'] ?? 'es') === 'ja' ? 'selected':'' ?>>🇯🇵 日本語</option>
          <option value="zh" <?= ($userData['language'] ?? 'es') === 'zh' ? 'selected':'' ?>>🇨🇳 中文</option>
        </select>
      </div>
      <button type="submit" class="btn-submit"><?= htmlspecialchars($t['perf_guardar_pref']) ?></button>
    </form>

  </div>
</div>

<footer class="site-footer">
  <p><?= htmlspecialchars($t['footer_copy']) ?></p>
</footer>

<script src="js/cache.js"></script>
<script src="js/api.js"></script>
<script src="js/dom.js"></script>
<script src="js/animations.js"></script>
<script src="js/menu-scripts.js"></script>
<script>
(function () {
  'use strict';
  const NAKAMAS = [
    { nombre: 'Monkey D. Luffy',   seed: 'monkey-d-luffy'    },
    { nombre: 'Roronoa Zoro',      seed: 'roronoa-zoro'      },
    { nombre: 'Nami',              seed: 'nami-navigator'    },
    { nombre: 'Usopp',             seed: 'god-usopp'         },
    { nombre: 'Sanji',             seed: 'sanji-vinsmoke'    },
    { nombre: 'Tony Tony Chopper', seed: 'tony-chopper'      },
    { nombre: 'Nico Robin',        seed: 'nico-robin'        },
    { nombre: 'Franky',            seed: 'franky-shipwright' },
    { nombre: 'Brook',             seed: 'soul-king-brook'   },
    { nombre: 'Jinbe',             seed: 'jinbe-helmsman'    },
  ];
  const img     = document.getElementById('perfil-avatar');
  const labelEl = document.getElementById('avatar-personaje');
  if (!img) return;
  const username = img.dataset.usuario || 'usuario';
  let hash = 0;
  for (let i = 0; i < username.length; i++) hash += username.charCodeAt(i);
  const nakama = NAKAMAS[hash % NAKAMAS.length];
  const apiUrl = `https://api.dicebear.com/9.x/adventurer/svg?seed=${encodeURIComponent(nakama.seed)}&backgroundColor=b45309,92400e,78350f&radius=50`;
  img.style.opacity = '0.4';
  img.style.transition = 'opacity 0.4s ease';
  fetch(apiUrl).then(r => r.text()).then(svg => {
    const blob = new Blob([svg], { type: 'image/svg+xml' });
    img.src = URL.createObjectURL(blob);
    img.style.opacity = '1';
    if (labelEl) labelEl.textContent = '<?= addslashes(htmlspecialchars($t["perf_tu_nakama"])) ?>' + nakama.nombre;
  }).catch(() => { img.style.opacity = '1'; });
})();
</script>
</body>
</html>

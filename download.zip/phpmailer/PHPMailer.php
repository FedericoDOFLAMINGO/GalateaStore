<?php
namespace PHPMailer\PHPMailer;
class PHPMailer {
    const ENCRYPTION_STARTTLS = 'tls';
    const ENCRYPTION_SMTPS    = 'ssl';
    public $Host; public $Port; public $SMTPAuth; public $Username;
    public $Password; public $SMTPSecure; public $CharSet = 'UTF-8';
    public $Encoding = 'base64'; public $Subject; public $Body;
    public $AltBody; public $ErrorInfo = '';
    private $to = []; private $from = ['', '']; private $replyTo = [];
    public function isSMTP() {}
    public function isHTML(bool $v = true) {}
    public function setFrom(string $addr, string $name = '') { $this->from = [$addr, $name]; }
    public function addAddress(string $addr, string $name = '') { $this->to[] = [$addr, $name]; }
    public function addReplyTo(string $addr, string $name = '') { $this->replyTo = [$addr, $name]; }
    public function send(): bool {
        $secure = ($this->SMTPSecure === self::ENCRYPTION_SMTPS) ? 'ssl' : '';
        $host   = ($secure ? 'ssl://' : '') . $this->Host;
        $sock   = @fsockopen($host, $this->Port, $errno, $errstr, 10);
        if (!$sock) throw new Exception("No se pudo conectar a SMTP: $errstr");
        $this->_expect($sock, 220);
        $this->_send($sock, "EHLO " . gethostname());
        $resp = $this->_readAll($sock);
        if ($this->SMTPSecure === self::ENCRYPTION_STARTTLS) {
            $this->_send($sock, "STARTTLS");
            $this->_expect($sock, 220);
            stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $this->_send($sock, "EHLO " . gethostname());
            $this->_readAll($sock);
        }
        if ($this->SMTPAuth) {
            $this->_send($sock, "AUTH LOGIN");
            $this->_expect($sock, 334);
            $this->_send($sock, base64_encode($this->Username));
            $this->_expect($sock, 334);
            $this->_send($sock, base64_encode($this->Password));
            $this->_expect($sock, 235);
        }
        $this->_send($sock, "MAIL FROM:<{$this->from[0]}>");
        $this->_expect($sock, 250);
        foreach ($this->to as $t) {
            $this->_send($sock, "RCPT TO:<{$t[0]}>");
            $this->_expect($sock, 250);
        }
        $this->_send($sock, "DATA");
        $this->_expect($sock, 354);
        $headers  = "From: {$this->from[1]} <{$this->from[0]}>\r\n";
        $headers .= "To: {$this->to[0][1]} <{$this->to[0][0]}>\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($this->Subject) . "?=\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "Content-Transfer-Encoding: base64\r\n";
        $body = chunk_split(base64_encode($this->Body));
        fwrite($sock, $headers . "\r\n" . $body . "\r\n.\r\n");
        $this->_expect($sock, 250);
        $this->_send($sock, "QUIT");
        fclose($sock);
        return true;
    }
    private function _send($sock, string $cmd) { fwrite($sock, $cmd . "\r\n"); }
    private function _expect($sock, int $code) {
        $resp = fgets($sock, 512);
        if (substr($resp, 0, 3) != $code) throw new Exception("SMTP error esperando $code: $resp");
        return $resp;
    }
    private function _readAll($sock): string {
        $out = '';
        while (($line = fgets($sock, 512)) !== false) {
            $out .= $line;
            if (substr($line, 3, 1) === ' ') break;
        }
        return $out;
    }
}

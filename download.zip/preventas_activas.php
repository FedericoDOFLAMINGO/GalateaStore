<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * preventas_activas.php — Catálogo completo con buscador en tiempo real
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández
 */
session_start();
if (!isset($_SESSION['usuario'])) { header("Location: login.php"); exit; }

include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

$cats_res  = $conn->query("SELECT DISTINCT categoria FROM preventas WHERE categoria != '' ORDER BY categoria");
$categorias = [];
while ($cats_res && $c = $cats_res->fetch_assoc()) $categorias[] = $c['categoria'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Preventas Activas — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="dashboard-body">

<?php include 'navbar.php'; ?>
<?php include 'breadcrumbs.php'; generarBreadcrumbs($breadcrumbs_preventas_activas); ?>

<div class="page-content">
  <h1 class="page-title">🛒 Preventas Activas</h1>

  <!-- Buscador en tiempo real -->
  <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;margin-bottom:20px;">
    <input type="text" id="buscador-tabla"
           placeholder="🔍 Buscar por nombre o descripción..."
           autocomplete="off"
           style="flex:1;min-width:200px;padding:10px 16px;border:2px solid rgba(247,214,122,0.4);
                  border-radius:10px;background:rgba(44,31,20,0.8);color:var(--gold);font-size:0.95rem;">
    <select id="filtro-cat"
            style="padding:10px 14px;border:2px solid rgba(247,214,122,0.4);border-radius:10px;
                   background:rgba(44,31,20,0.8);color:var(--gold);font-size:0.9rem;">
      <option value="">— Todas las categorías —</option>
      <?php foreach ($categorias as $cat): ?>
      <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
      <?php endforeach; ?>
    </select>
    <span id="count-tabla" style="font-size:0.85rem;color:rgba(247,214,122,0.6);white-space:nowrap;"></span>
  </div>

  <div class="tabla-container">
    <table class="tabla-preventas">
      <thead>
        <tr>
          <th>Imagen</th><th>Producto</th><th>Descripción</th>
          <th>Precio</th><th>Stock</th><th>Inicio</th><th>Fin</th><th>Acción</th>
        </tr>
      </thead>
      <tbody id="tbody-preventas">
        <tr><td colspan="8" style="text-align:center;padding:40px;">
          <div class="op-spinner" style="margin:0 auto 10px;"></div>
          <span style="color:rgba(247,214,122,0.5);">Cargando...</span>
        </td></tr>
      </tbody>
    </table>
  </div>
</div>

<footer class="site-footer">
  <p>&copy; 2026 One Piece Preventas. Todos los derechos reservados.</p>
</footer>

<script src="js/cache.js"></script>
<script src="js/api.js"></script>
<script src="js/dom.js"></script>
<script src="js/animations.js"></script>
<script src="js/menu-scripts.js"></script>
<script>
(function () {
  'use strict';

  const tbody     = document.getElementById('tbody-preventas');
  const inputEl   = document.getElementById('buscador-tabla');
  const catEl     = document.getElementById('filtro-cat');
  const countEl   = document.getElementById('count-tabla');
  const esCliente = <?= json_encode($_SESSION['usuario']['rol'] === 'cliente') ?>;

  let abortController = null;

  // Carga inicial
  buscar('', '');

  // Debounce 400ms en el buscador
  inputEl.addEventListener('input', debounce(() => buscar(inputEl.value.trim(), catEl.value), 400));
  catEl.addEventListener('change', () => buscar(inputEl.value.trim(), catEl.value));

  async function buscar(q, categoria) {
    // Caché
    const key = `tabla:${q}:${categoria}`;
    if (window.OnePieceCache) {
      const hit = OnePieceCache.get(key);
      if (hit) { renderTabla(hit); return; }
    }

    // Cancelar petición anterior
    if (abortController) abortController.abort();
    abortController = new AbortController();

    tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:30px;">
      <div class="op-spinner" style="margin:0 auto 8px;"></div>
      <span style="color:rgba(247,214,122,0.4);font-size:0.85rem;">Buscando...</span>
    </td></tr>`;

    console.time('[PreventasActivas] fetch');
    try {
      const params = new URLSearchParams({ disponible: '1' });
      if (q)         params.set('q', q);
      if (categoria) params.set('categoria', categoria);

      const res  = await fetch(`api_preventas.php?${params}`, { signal: abortController.signal });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();

      console.timeEnd('[PreventasActivas] fetch');
      if (window.OnePieceCache) OnePieceCache.set(key, data, 60_000);
      renderTabla(data);
    } catch (err) {
      if (err.name === 'AbortError') return;
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:30px;color:var(--red-err);">❌ Error al cargar. Recarga la página.</td></tr>`;
    }
  }

  function renderTabla(data) {
    if (countEl) countEl.textContent = `${data.total} resultado${data.total !== 1 ? 's' : ''}`;

    if (data.total === 0) {
      tbody.innerHTML = `<tr><td colspan="8" style="text-align:center;padding:50px;color:rgba(247,214,122,0.5);">
        ⚓ No se encontraron preventas con ese criterio.</td></tr>`;
      return;
    }

    // DocumentFragment — 1 solo reflow
    const fragment = document.createDocumentFragment();
    data.items.forEach((item, i) => {
      const tr = document.createElement('tr');
      tr.style.opacity = '0';
      tr.style.transition = `opacity 0.35s ease ${(i % 8) * 50}ms`;
      const imgSrc   = item.imagen_url || 'img/op13.jpeg';
      const badge    = item.stock_disponible > 0 ? 'badge-active' : 'badge-inactive';
      const accion   = esCliente
        ? `<a href="hacer_pedido.php?id=${item.id}" class="btn-accion btn-inspeccionar">🛒 Ordenar</a>`
        : `<a href="admin/inspeccionar_preventa.php?id=${item.id}" class="btn-accion btn-inspeccionar">🔍 Ver</a>`;

      tr.innerHTML = `
        <td><img data-src="${escHtml(imgSrc)}" src="img/op13.jpeg"
             style="max-width:70px;border-radius:8px;" onerror="this.src='img/op13.jpeg'"></td>
        <td><strong>${escHtml(item.nombre_producto)}</strong></td>
        <td style="max-width:200px;font-size:0.85rem;">${escHtml(item.descripcion)}</td>
        <td style="color:var(--green-ok);font-weight:700;">$${parseFloat(item.precio).toFixed(2)}</td>
        <td><span class="badge ${badge}">${item.stock_disponible} uds.</span></td>
        <td style="font-size:0.85rem;">${escHtml(item.fecha_inicio)}</td>
        <td style="font-size:0.85rem;">${escHtml(item.fecha_fin)}</td>
        <td>${accion}</td>`;
      fragment.appendChild(tr);
    });

    tbody.innerHTML = '';
    tbody.appendChild(fragment);

    // Animar filas (fade in escalonado)
    requestAnimationFrame(() => {
      tbody.querySelectorAll('tr').forEach(tr => { tr.style.opacity = '1'; });
    });

    // Lazy loading en imágenes de la tabla
    if (window.OnePieceDOM) OnePieceDOM.lazyLoadImages('#tbody-preventas [data-src]');
  }

  function escHtml(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function debounce(fn, d) {
    let t; return function(...a) { clearTimeout(t); t = setTimeout(() => fn.apply(this,a), d); };
  }
})();
</script>
</body>
</html>

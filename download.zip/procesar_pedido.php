<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

if (!isset($_SESSION['usuario']) || $_SESSION['usuario']['rol'] !== 'cliente') {
    header("Location: login.php");
    exit;
}

$cliente_id = $_SESSION['usuario']['id'];
$preventa_id = intval($_POST['preventa_id'] ?? 0);
$cantidad = intval($_POST['cantidad'] ?? 0);

// Validaciones básicas
if ($preventa_id <= 0 || $cantidad <= 0) {
    die("❌ Datos inválidos.");
}

// Validar que se subió la captura
if (!isset($_FILES['captura']) || $_FILES['captura']['error'] != 0) {
    die("❌ Debes subir la captura de pago para confirmar el pedido.");
}

// Validar stock actual (solo para asegurar que haya stock disponible)
$sql = "SELECT stock_disponible FROM preventas WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $preventa_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("❌ La preventa no existe.");
}

$row = $result->fetch_assoc();

if ($cantidad > $row['stock_disponible']) {
    die("❌ No hay suficiente stock disponible.");
}

// === Subir la imagen de la captura ===
$carpetaDestino = __DIR__ . '/comprobantes/';
if (!is_dir($carpetaDestino)) {
    mkdir($carpetaDestino, 0777, true);
}

$extension = pathinfo($_FILES['captura']['name'], PATHINFO_EXTENSION);
$nombreArchivo = time() . "_{$cliente_id}." . $extension;
$rutaFinal = $carpetaDestino . $nombreArchivo;

if (!move_uploaded_file($_FILES['captura']['tmp_name'], $rutaFinal)) {
    die("❌ Error al guardar la captura.");
}

// Insertar pedido como pendiente
$sql = "INSERT INTO pedidos (cliente_id, preventa_id, cantidad, fecha_pedido, captura_pago, estado) 
        VALUES (?, ?, ?, NOW(), ?, 'pendiente')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("iiis", $cliente_id, $preventa_id, $cantidad, $nombreArchivo);
$stmt->execute();

// ✅ Ya NO actualizamos stock aquí
header("Location: dashboard_cliente.php?pedido=pendiente");
exit;
?>

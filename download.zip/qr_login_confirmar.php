<?php
/**
 * qr_login_confirmar.php — Página móvil para confirmar el login por QR
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */
session_start();
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/seguridad/auth.php';

$token = trim($_GET['token'] ?? '');

// Si no hay sesión activa, redirigir a login con el token guardado
if (!isset($_SESSION['usuario'])) {
    $_SESSION['qr_token_pendiente'] = $token;
    header('Location: login.php?qr=1');
    exit;
}

$userId = $_SESSION['usuario']['id'];
$error  = '';
$ok     = false;

if (!$token) {
    $error = 'Token inválido.';
} else {
    // Verificar que el token exista, esté pendiente y no haya expirado
    $stmt = $conn->prepare(
        "SELECT id FROM qr_login_tokens
         WHERE token = ? AND status = 'pendiente' AND expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$row) {
        $error = 'El código QR ya expiró o fue usado. Genera uno nuevo.';
    } else {
        // Marcar como confirmado y asociar al usuario
        $stmt = $conn->prepare(
            "UPDATE qr_login_tokens SET status = 'confirmado', user_id = ?, confirmed_at = NOW()
             WHERE token = ?"
        );
        $stmt->bind_param('is', $userId, $token);
        $stmt->execute();
        $stmt->close();
        $ok = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Confirmar acceso — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <style>
    .qr-confirm-card {
      max-width: 360px; margin: 60px auto; padding: 32px 28px;
      background: #2c1f14; border: 2px solid #f7d67a; border-radius: 14px;
      text-align: center; font-family: 'Segoe UI', sans-serif;
    }
    .qr-confirm-card h2 { color: #ffcb45; font-size: 1.3rem; margin: 12px 0 6px; }
    .qr-confirm-card p  { color: rgba(247,214,122,0.75); font-size: 0.9rem; margin: 0 0 20px; }
    .icon-big { font-size: 3.5rem; }
    .btn-confirm {
      display: block; width: 100%; padding: 13px;
      background: linear-gradient(135deg,#b07a20,#f7d67a);
      color: #1a0f08; font-weight: bold; font-size: 1rem;
      border: none; border-radius: 8px; cursor: pointer; text-decoration: none;
    }
    .btn-cancel {
      display: block; margin-top: 10px; font-size: 0.82rem;
      color: rgba(247,214,122,0.4); text-decoration: none;
    }
    .alert-ok  { background: rgba(34,197,94,0.15); border: 1px solid #22c55e; color: #86efac; padding: 12px; border-radius: 8px; margin-bottom: 14px; }
    .alert-err { background: rgba(239,68,68,0.15);  border: 1px solid #ef4444; color: #fca5a5; padding: 12px; border-radius: 8px; margin-bottom: 14px; }
  </style>
</head>
<body class="login-body">
<div class="qr-confirm-card">
  <img src="img/Sombrero.png" alt="Logo" style="width:55px;">

  <?php if ($error): ?>
    <div class="alert-err"><?= htmlspecialchars($error) ?></div>
    <a href="login.php" class="btn-confirm">← Volver al login</a>

  <?php elseif ($ok): ?>
    <div class="icon-big">✅</div>
    <h2>¡Acceso confirmado!</h2>
    <p>Sesión iniciada en el otro dispositivo.<br>Ya puedes cerrar esta ventana.</p>

  <?php else: ?>
    <div class="icon-big">📱</div>
    <h2>Confirmar acceso</h2>
    <p>
      Hola <strong style="color:#ffcb45;"><?= htmlspecialchars($_SESSION['usuario']['nombre_usuario']) ?></strong>,
      ¿confirmas el inicio de sesión desde otro dispositivo?
    </p>
    <a href="qr_login_confirmar.php?token=<?= urlencode($token) ?>&confirmar=1" class="btn-confirm">
      ✅ Sí, soy yo — Confirmar acceso
    </a>
    <a href="login.php" class="btn-cancel">❌ No fui yo — Cancelar</a>
  <?php endif; ?>

  <?php
  // Procesar confirmación real al hacer clic en el botón
  if (isset($_GET['confirmar']) && $_GET['confirmar'] === '1' && !$error && !$ok):
  ?>
  <script>window.location = 'qr_login_confirmar.php?token=<?= urlencode($token) ?>';</script>
  <?php endif; ?>
</div>
</body>
</html>

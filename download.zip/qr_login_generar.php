<?php
/**
 * qr_login_generar.php — Genera token QR e imagen QR server-side
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 *
 * CORRECCIÓN: La imagen QR ahora se genera en el servidor con cURL
 * para evitar bloqueos de InfinityFreeApp a APIs externas desde el browser.
 */
session_start();
require_once __DIR__ . '/db.php';
 
// ── Modo imagen: sirve el QR como PNG ────────────────────────────────────────
if (isset($_GET['img']) && isset($_GET['token'])) {
    $token = preg_replace('/[^a-f0-9]/', '', $_GET['token']);
    if (!$token) { http_response_code(400); exit; }
 
    $baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
             . '://' . ($_SERVER['HTTP_HOST'] ?? 'galateastore.infinityfreeapp.com');
    $qrData  = $baseUrl . '/qr_login_confirmar.php?token=' . $token;
 
    // Pedir imagen a qrserver desde el servidor (cURL), no desde el browser
    $apiUrl  = 'https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=' . urlencode($qrData);
    $imgData = null;
 
    if (function_exists('curl_init')) {
        $ch = curl_init($apiUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 8,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
        ]);
        $result = curl_exec($ch);
        $code   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code === 200 && $result) $imgData = $result;
    }
 
    // Fallback con GD si cURL falla
    if (!$imgData) {
        $imgData = qrFallbackGD($qrData, 200);
    }
 
    header('Content-Type: image/png');
    header('Cache-Control: no-store, no-cache');
    echo $imgData;
    exit;
}
 
// ── Modo JSON: genera token y devuelve URL de imagen ─────────────────────────
header('Content-Type: application/json');
 
$token   = bin2hex(random_bytes(24));
$expires = date('Y-m-d H:i:s', time() + 120);
$ip      = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
 
$stmt = $conn->prepare(
    "INSERT INTO qr_login_tokens (token, status, expires_at, ip_solicitante)
     VALUES (?, 'pendiente', ?, ?)"
);
$stmt->bind_param('sss', $token, $expires, $ip);
$stmt->execute();
$stmt->close();
 
$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
         . '://' . ($_SERVER['HTTP_HOST'] ?? 'galateastore.infinityfreeapp.com');
 
echo json_encode([
    'token'   => $token,
    'img_url' => $baseUrl . '/qr_login_generar.php?img=1&token=' . $token,
    'expires' => 120,
]);
 
// ── Fallback GD: genera imagen simple si no hay cURL ─────────────────────────
function qrFallbackGD(string $texto, int $size = 200): string {
    $im  = imagecreatetruecolor($size, $size);
    $bg  = imagecolorallocate($im, 255, 255, 255);
    $fg  = imagecolorallocate($im, 30, 30, 30);
    imagefill($im, 0, 0, $bg);
    imagerectangle($im, 8, 8, $size - 8, $size - 8, $fg);
    imagestring($im, 4, 30, $size / 2 - 20, 'Abre en movil:', $fg);
    imagestring($im, 2, 20, $size / 2 + 5, substr($texto, 0, 35), $fg);
    ob_start();
    imagepng($im);
    $data = ob_get_clean();
    imagedestroy($im);
    return $data;
}
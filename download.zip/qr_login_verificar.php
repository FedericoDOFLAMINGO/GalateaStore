<?php
/**
 * qr_login_verificar.php — Polling: la PC pregunta si el QR ya fue confirmado
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */
session_start();
header('Content-Type: application/json');
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/seguridad/auth.php';

$token = trim($_GET['token'] ?? '');
if (!$token) {
    echo json_encode(['status' => 'error', 'msg' => 'Token requerido']);
    exit;
}

$stmt = $conn->prepare(
    "SELECT t.status, t.user_id, t.expires_at,
            c.nombre_usuario, c.email, c.rol
     FROM qr_login_tokens t
     LEFT JOIN clientes c ON c.id = t.user_id
     WHERE t.token = ?"
);
$stmt->bind_param('s', $token);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    echo json_encode(['status' => 'error', 'msg' => 'Token inválido']);
    exit;
}

if ($row['status'] === 'pendiente') {
    // Verificar si expiró
    if (strtotime($row['expires_at']) < time()) {
        echo json_encode(['status' => 'expirado']);
    } else {
        echo json_encode(['status' => 'pendiente']);
    }
    exit;
}

if ($row['status'] === 'confirmado') {
    $userId = (int)$row['user_id'];
    $ip     = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';

    // Marcar token como usado para que no se pueda reutilizar
    $conn->query("UPDATE qr_login_tokens SET status='usado' WHERE token='" . $conn->real_escape_string($token) . "'");

    // Crear sesión en BD
    session_regenerate_id(true);
    $sessionToken = crearSesionBD($conn, $userId, $ip, getUserAgent());
    $sessionId    = (int)$conn->insert_id;
    $refreshToken = generarRefreshToken($conn, $userId, $sessionId);

    $_SESSION['usuario'] = [
        'id'             => $userId,
        'nombre_usuario' => $row['nombre_usuario'],
        'rol'            => $row['rol'],
        'correo'         => $row['email'],
    ];
    $_SESSION['session_token'] = $sessionToken;
    $_SESSION['refresh_token'] = $refreshToken;
    $_SESSION['show_welcome']  = true;

    echo json_encode(['status' => 'ok', 'redirect' => 'dashboard.php']);
    exit;
}

echo json_encode(['status' => $row['status']]);

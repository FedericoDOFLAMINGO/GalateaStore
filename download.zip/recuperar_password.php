<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * recuperar_password.php — Recuperación de contraseña (4 mecanismos)
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 * CORRECCIONES v2: Funciones con fallback, errores SMS/llamada corregidos
 */
session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';
if (file_exists(__DIR__ . '/lang/translations.php')) include_once __DIR__ . '/lang/translations.php';

// Fallbacks para funciones que pueden fallar si auth.php no las carga
if (!function_exists('enviarOTPSMS')) {
    function enviarOTPSMS(string $phone, string $code): void {
        error_log("[SMS SIMULADO] Tel: $phone | Código: $code");
    }
}
if (!function_exists('simularLlamada')) {
    function simularLlamada(string $phone, string $code): void {
        error_log("[LLAMADA SIMULADA] Tel: $phone | Código: $code");
    }
}
if (!function_exists('generarCodigoMFA')) {
    function generarCodigoMFA(mysqli $conn, int $userId, string $tipo = 'email'): string {
        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $exp  = date('Y-m-d H:i:s', time() + 600);
        $s = $conn->prepare("INSERT INTO mfa_codes (user_id, code, type, expires_at) VALUES (?,?,?,?)");
        $s->bind_param('isss', $userId, $code, $tipo, $exp);
        $s->execute(); $s->close();
        return $code;
    }
}
if (!function_exists('validarCodigoMFA')) {
    function validarCodigoMFA(mysqli $conn, int $userId, string $code, string $tipo = 'email'): bool {
        $s = $conn->prepare("SELECT id FROM mfa_codes WHERE user_id=? AND code=? AND type=? AND used=0 AND expires_at>NOW() ORDER BY id DESC LIMIT 1");
        $s->bind_param('iss', $userId, $code, $tipo); $s->execute();
        $r = $s->get_result()->fetch_assoc(); $s->close();
        if (!$r) return false;
        $u = $conn->prepare("UPDATE mfa_codes SET used=1 WHERE id=?");
        $u->bind_param('i', $r['id']); $u->execute(); $u->close();
        return true;
    }
}
if (!function_exists('generarTokenReset')) {
    function generarTokenReset(mysqli $conn, int $userId, string $tipo, string $ip): string {
        $conn->query("UPDATE password_resets SET used=1 WHERE user_id=$userId AND used=0");
        $token = bin2hex(random_bytes(32));
        $exp   = date('Y-m-d H:i:s', time() + 1800);
        $s = $conn->prepare("INSERT INTO password_resets (user_id,token,type,expires_at,ip_address) VALUES (?,?,?,?,?)");
        $s->bind_param('issss', $userId, $token, $tipo, $exp, $ip);
        $s->execute(); $s->close();
        return $token;
    }
}
if (!function_exists('csrf_validate')) {
    function csrf_validate(): void {
        $tok = $_POST['csrf_token'] ?? '';
        $exp = $_SESSION['csrf_token'] ?? '';
        if ($exp && !hash_equals($exp, $tok)) { http_response_code(403); die('Error CSRF'); }
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}
if (!function_exists('csrf_field')) {
    function csrf_field(): string {
        if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars($_SESSION['csrf_token']) . '">';
    }
}
if (!function_exists('getClientIP')) {
    function getClientIP(): string { return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'; }
}

// Idioma
$userLang = $_SESSION['usuario']['language'] ?? $_GET['lang'] ?? 'es';
if (!in_array($userLang, ['es','en','fr','ja','zh'])) $userLang = 'es';
$t = function_exists('getLang') ? getLang($userLang) : [];
$txt = array_merge([
    'rec_title'       => 'Recuperar Contraseña — One Piece Preventas',
    'rec_h2'          => 'Recuperar Contraseña',
    'rec_elegir'      => 'Elige un método de recuperación:',
    'rec_por_email'   => '📧 Por correo electrónico',
    'rec_preguntas'   => '❓ Preguntas secretas',
    'rec_sms'         => '📱 Por SMS (simulado)',
    'rec_llamada'     => '📞 Por llamada (simulado)',
    'rec_usr_o_email' => 'Usuario o correo electrónico',
    'rec_continuar'   => 'Continuar →',
    'rec_revisar_correo' => 'Revisa tu correo para continuar.',
    'rec_volver'      => '← Volver',
    'rec_enviar_codigo'  => '📤 Enviar código',
    'rec_codigo_recib'   => 'Código recibido',
    'rec_verificar'   => '✅ Verificar código',
    'rec_volver_login'=> '← Volver al login',
    'rec_sin_preg'    => 'No tienes preguntas secretas configuradas.',
    'rec_telefono_env'=> 'Se enviará un código a tu teléfono registrado.',
    'footer_copy'     => '© 2026 One Piece Preventas. Todos los derechos reservados.',
], $t);

$ip      = getClientIP();
$paso    = $_GET['paso'] ?? '1';
$metodo  = $_GET['metodo'] ?? 'email';
$msg     = '';
$msgTipo = '';

// PASO 1
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $paso === '1') {
    csrf_validate();
    $id = trim($_POST['identificador'] ?? '');
    $s = $conn->prepare("SELECT * FROM clientes WHERE email=? OR nombre_usuario=?");
    $s->bind_param('ss', $id, $id); $s->execute();
    $user = $s->get_result()->fetch_assoc(); $s->close();
    if ($user) {
        $_SESSION['reset_user_id']    = $user['id'];
        $_SESSION['reset_user_email'] = $user['email'];
        $_SESSION['reset_user_name']  = $user['nombre_usuario'];
    }
    header("Location: recuperar_password.php?paso=2&metodo=" . urlencode($metodo));
    exit;
}

// PASO 2
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $paso === '2') {
    csrf_validate();
    $userId = $_SESSION['reset_user_id'] ?? 0;
    if (!$userId) { header('Location: recuperar_password.php'); exit; }
    $s = $conn->prepare("SELECT * FROM clientes WHERE id=?");
    $s->bind_param('i', $userId); $s->execute();
    $user = $s->get_result()->fetch_assoc(); $s->close();
    if (!$user) { header('Location: recuperar_password.php'); exit; }
    $metodo = $_POST['metodo'] ?? 'email';

    if ($metodo === 'email') {
        $token = generarTokenReset($conn, $userId, 'email', $ip);
        $base  = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS']==='on' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'galateastore.infinityfreeapp.com');
        $sent  = false;
        if (file_exists(__DIR__ . '/mailer.php')) {
            include_once __DIR__ . '/mailer.php';
            if (function_exists('enviarEmailRecuperacion')) $sent = enviarEmailRecuperacion($user['email'], $user['nombre_usuario'], $token, $base);
        }
        if ($sent) {
            $msg = '✅ Enlace de recuperación enviado a: ' . htmlspecialchars($user['email']) . '. Revisa tu bandeja (y spam).';
            $msgTipo = 'ok';
        } else {
            $msg = '❌ No se pudo enviar el correo. Intenta de nuevo en unos minutos.';
            $msgTipo = 'err';
        }
    } elseif ($metodo === 'secret') {
        $r1 = trim($_POST['secret_answer_1'] ?? '');
        $r2 = trim($_POST['secret_answer_2'] ?? '');
        if (!($user['secret_a1'] ?? '') || !($user['secret_a2'] ?? '')) {
            $msg = '❌ No tienes preguntas secretas configuradas.'; $msgTipo = 'err';
        } elseif (password_verify(strtolower($r1), $user['secret_a1']) && password_verify(strtolower($r2), $user['secret_a2'])) {
            $token = generarTokenReset($conn, $userId, 'secret', $ip);
            header("Location: reset_password.php?token=$token"); exit;
        } else {
            $msg = '❌ Respuestas incorrectas. Intenta de nuevo.'; $msgTipo = 'err';
        }
    } elseif ($metodo === 'sms') {
        $phone = $user['phone'] ?? '';
        if (!$phone) {
            $msg = '❌ No tienes teléfono registrado. Agrégalo en Mi Perfil.'; $msgTipo = 'err';
        } else {
            $code = generarCodigoMFA($conn, $userId, 'sms');
            enviarOTPSMS($phone, $code);
            $_SESSION['reset_sms_demo'] = $code;
            $_SESSION['reset_tipo']     = 'sms';
            $_SESSION['reset_user_id']  = $userId;
            header('Location: recuperar_password.php?paso=3&metodo=sms'); exit;
        }
    } elseif ($metodo === 'call') {
        $phone = $user['phone'] ?? '';
        if (!$phone) {
            $msg = '❌ No tienes teléfono registrado. Agrégalo en Mi Perfil.'; $msgTipo = 'err';
        } else {
            $code = generarCodigoMFA($conn, $userId, 'call');
            simularLlamada($phone, $code);
            $_SESSION['reset_call_demo'] = $code;
            $_SESSION['reset_tipo']      = 'call';
            $_SESSION['reset_user_id']   = $userId;
            header('Location: recuperar_password.php?paso=3&metodo=call'); exit;
        }
    }
}

// PASO 3
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $paso === '3') {
    csrf_validate();
    $userId = $_SESSION['reset_user_id'] ?? 0;
    $tipo   = $_SESSION['reset_tipo'] ?? 'sms';
    $code   = trim($_POST['otp_code'] ?? '');
    if (!$userId) { header('Location: recuperar_password.php'); exit; }
    if (validarCodigoMFA($conn, $userId, $code, $tipo)) {
        $token = generarTokenReset($conn, $userId, $tipo, $ip);
        unset($_SESSION['reset_sms_demo'], $_SESSION['reset_call_demo'], $_SESSION['reset_tipo']);
        header("Location: reset_password.php?token=$token"); exit;
    } else {
        $msg = '❌ Código incorrecto o expirado. Intenta de nuevo.'; $msgTipo = 'err';
    }
}

$secretQ1 = $secretQ2 = '';
if ($paso === '2' && $metodo === 'secret' && !empty($_SESSION['reset_user_id'])) {
    $s = $conn->prepare("SELECT secret_q1, secret_q2 FROM clientes WHERE id=?");
    $s->bind_param('i', $_SESSION['reset_user_id']); $s->execute();
    $sq = $s->get_result()->fetch_assoc(); $s->close();
    $secretQ1 = $sq['secret_q1'] ?? ''; $secretQ2 = $sq['secret_q2'] ?? '';
}

$userTheme = $_SESSION['usuario']['theme'] ?? 'dark';
?>
<!DOCTYPE html>
<html lang="<?= htmlspecialchars($userLang) ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($txt['rec_title']) ?></title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="login-body<?= $userTheme === 'light' ? ' theme-light' : '' ?>">

<div class="login-card" style="max-width:460px;">
  <img src="img/Sombrero.png" alt="Logo" style="width:60px;margin-bottom:8px;">
  <h2 style="font-family:'Pirata One',serif;"><?= htmlspecialchars($txt['rec_h2']) ?></h2>

  <?php if ($msg): ?>
    <div class="alert-<?= $msgTipo === 'ok' ? 'success' : 'error' ?>" style="margin:10px 0;">
      <?= htmlspecialchars($msg) ?>
    </div>
  <?php endif; ?>



  <?php if ($paso === '1'): ?>
    <p class="subtitle" style="margin-bottom:14px;"><?= htmlspecialchars($txt['rec_elegir']) ?></p>
    <div style="display:flex;flex-direction:column;gap:8px;margin-bottom:20px;">
      <?php foreach (['email'=>$txt['rec_por_email'],'secret'=>$txt['rec_preguntas'],'sms'=>$txt['rec_sms'],'call'=>$txt['rec_llamada']] as $k=>$lbl): ?>
      <a href="?paso=1&metodo=<?= $k ?>" class="btn-secondary"
         style="text-align:center;<?= $metodo===$k ? 'background:rgba(247,214,122,0.2);border-color:var(--gold-bright);font-weight:bold;' : '' ?>">
        <?= htmlspecialchars($lbl) ?>
      </a>
      <?php endforeach; ?>
    </div>
    <form method="POST" action="?paso=1&metodo=<?= htmlspecialchars($metodo) ?>">
      <?= csrf_field() ?>
      <div class="form-group">
        <label><?= htmlspecialchars($txt['rec_usr_o_email']) ?></label>
        <input type="text" name="identificador" placeholder="tu@correo.com o usuario" required autofocus>
      </div>
      <button type="submit" class="btn-primary"><?= htmlspecialchars($txt['rec_continuar']) ?></button>
    </form>

  <?php elseif ($paso === '2' && $metodo === 'email'): ?>
    <div style="text-align:center;padding:16px 0;">
      <div style="font-size:3rem;margin-bottom:10px;">📧</div>
      <p class="subtitle"><?= htmlspecialchars($txt['rec_revisar_correo']) ?></p>
    </div>
    <a href="recuperar_password.php" class="btn-secondary" style="display:block;text-align:center;margin-top:12px;">
      <?= htmlspecialchars($txt['rec_volver']) ?>
    </a>

  <?php elseif ($paso === '2' && $metodo === 'secret'): ?>
    <?php if (!$secretQ1): ?>
      <div class="alert-error"><?= htmlspecialchars($txt['rec_sin_preg']) ?></div>
      <a href="recuperar_password.php" class="btn-secondary" style="display:block;text-align:center;margin-top:12px;">
        <?= htmlspecialchars($txt['rec_volver']) ?>
      </a>
    <?php else: ?>
    <form method="POST" action="?paso=2&metodo=secret">
      <?= csrf_field() ?>
      <input type="hidden" name="metodo" value="secret">
      <div class="form-group">
        <label><?= htmlspecialchars($secretQ1) ?></label>
        <input type="text" name="secret_answer_1" required autocomplete="off">
      </div>
      <div class="form-group">
        <label><?= htmlspecialchars($secretQ2) ?></label>
        <input type="text" name="secret_answer_2" required autocomplete="off">
      </div>
      <button type="submit" class="btn-primary">✅ Verificar respuestas</button>
    </form>
    <?php endif; ?>

  <?php elseif ($paso === '2' && in_array($metodo, ['sms','call'])): ?>
    <div style="text-align:center;padding:12px 0;">
      <div style="font-size:3rem;margin-bottom:8px;"><?= $metodo === 'sms' ? '📱' : '📞' ?></div>
      <p class="subtitle"><?= htmlspecialchars($txt['rec_telefono_env']) ?></p>
      <p style="font-size:0.78rem;color:rgba(247,214,122,0.45);margin-top:6px;">
        ⚠️ Modo demo: el código se mostrará en pantalla al enviarlo.
      </p>
    </div>
    <form method="POST" action="?paso=2&metodo=<?= htmlspecialchars($metodo) ?>">
      <?= csrf_field() ?>
      <input type="hidden" name="metodo" value="<?= htmlspecialchars($metodo) ?>">
      <button type="submit" class="btn-primary"><?= htmlspecialchars($txt['rec_enviar_codigo']) ?></button>
    </form>
    <a href="recuperar_password.php" class="btn-secondary" style="display:block;text-align:center;margin-top:10px;">
      <?= htmlspecialchars($txt['rec_volver']) ?>
    </a>

  <?php elseif ($paso === '3'): ?>
    <?php
      $demoCode = '';
      if (!empty($_SESSION['reset_sms_demo']))  $demoCode = $_SESSION['reset_sms_demo'];
      if (!empty($_SESSION['reset_call_demo'])) $demoCode = $_SESSION['reset_call_demo'];
    ?>
    <?php if ($demoCode): ?>
    <div style="background:rgba(66,47,26,0.95);border:2px dashed var(--gold);border-radius:12px;padding:18px;text-align:center;margin:10px 0;">
      <div style="font-size:0.8rem;color:rgba(247,214,122,0.6);margin-bottom:8px;">
        🧪 <?= $metodo === 'sms' ? 'SMS simulado' : 'Llamada simulada' ?> — Código:
      </div>
      <div style="font-size:2.6rem;font-weight:bold;color:var(--gold-bright);letter-spacing:14px;font-family:monospace;">
        <?= htmlspecialchars($demoCode) ?>
      </div>
      <div style="font-size:0.72rem;color:rgba(247,214,122,0.4);margin-top:6px;">Válido por 10 minutos</div>
    </div>
    <?php endif; ?>
    <form method="POST" action="?paso=3&metodo=<?= htmlspecialchars($metodo) ?>">
      <?= csrf_field() ?>
      <div class="form-group">
        <label><?= htmlspecialchars($txt['rec_codigo_recib']) ?></label>
        <input type="text" name="otp_code" placeholder="000000" maxlength="6"
               style="letter-spacing:10px;font-size:1.6rem;text-align:center;font-family:monospace;"
               required autofocus inputmode="numeric" pattern="[0-9]{6}">
      </div>
      <button type="submit" class="btn-primary"><?= htmlspecialchars($txt['rec_verificar']) ?></button>
    </form>
    <a href="recuperar_password.php?paso=2&metodo=<?= htmlspecialchars($metodo) ?>"
       class="btn-secondary" style="display:block;text-align:center;margin-top:10px;">
      <?= htmlspecialchars($txt['rec_volver']) ?>
    </a>
  <?php endif; ?>

  <div style="text-align:center;margin-top:16px;">
    <a href="login.php" style="font-size:0.82rem;color:rgba(247,214,122,0.4);text-decoration:none;">
      <?= htmlspecialchars($txt['rec_volver_login']) ?>
    </a>
  </div>
</div>

</body>
</html>

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * register.php — Registro con CSRF, bcrypt y validaciones
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 */

session_start();
include 'db.php';
include __DIR__ . '/seguridad/auth.php';

if (isset($_SESSION['usuario'])) {
    header('Location: dashboard.php');
    exit;
}

$error   = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validate();

    $usuario  = trim($_POST['nombre_usuario'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (strlen($usuario) < 3) {
        $error = 'El usuario debe tener al menos 3 caracteres.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Correo electrónico inválido.';
    } elseif (strlen($password) < 6) {
        $error = 'La contraseña debe tener al menos 6 caracteres.';
    } elseif ($password !== $confirm) {
        $error = 'Las contraseñas no coinciden.';
    } else {
        $check = $conn->prepare("SELECT id FROM clientes WHERE nombre_usuario = ? OR email = ?");
        $check->bind_param('ss', $usuario, $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error = 'El usuario o correo ya está registrado.';
        } else {
            // bcrypt con cost 12 (más seguro que el default 10)
            $hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
            $stmt = $conn->prepare("INSERT INTO clientes (nombre_usuario, email, password, rol) VALUES (?, ?, ?, 'cliente')");
            $stmt->bind_param('sss', $usuario, $email, $hash);
            if ($stmt->execute()) {
                $success = '¡Cuenta creada con éxito! Ahora puedes iniciar sesión.';
            } else {
                $error = 'Error al crear la cuenta: ' . $stmt->error;
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrarse — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="login-body">
<div class="login-card">
  <img src="img/Sombrero.png" alt="Logo" style="width:65px;margin-bottom:10px;">
  <h2>Crear Cuenta</h2>
  <p class="subtitle">Únete a la tripulación de preventas</p>

  <?php if ($error): ?>
    <div class="alert-error">❌ <?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <?php if ($success): ?>
    <div class="alert-success">✅ <?= htmlspecialchars($success) ?>
      <a href="login.php" style="color:var(--gold-bright);margin-left:6px;">Ir al login →</a>
    </div>
  <?php endif; ?>

  <?php if (!$success): ?>
  <form method="POST" action="">
    <?= csrf_field() ?>
    <div class="form-group">
      <label for="nombre_usuario">Nombre de usuario</label>
      <input type="text" id="nombre_usuario" name="nombre_usuario"
             placeholder="Elige un nombre de usuario" required minlength="3"
             value="<?= htmlspecialchars($_POST['nombre_usuario'] ?? '') ?>">
    </div>
    <div class="form-group">
      <label for="email">Correo electrónico</label>
      <input type="email" id="email" name="email"
             placeholder="tu@correo.com" required
             value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
    </div>
    <div class="form-group">
      <label for="password">Contraseña</label>
      <input type="password" id="password" name="password"
             placeholder="Mínimo 6 caracteres" required minlength="6">
    </div>
    <div class="form-group">
      <label for="confirm_password">Confirmar contraseña</label>
      <input type="password" id="confirm_password" name="confirm_password"
             placeholder="Repite tu contraseña" required>
    </div>
    <button type="submit" class="btn-primary">🏴‍☠️ Registrarme</button>
  </form>
  <?php endif; ?>

  <div class="login-divider">¿Ya tienes cuenta?</div>
  <a href="login.php" class="btn-secondary">🔐 Iniciar Sesión</a>
</div>
</body>
</html>

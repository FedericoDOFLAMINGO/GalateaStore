<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * reset_password.php — Cambio de contraseña con token válido
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 *
 * Recibe el token de recuperación (email, secret, sms, call),
 * valida que no haya expirado, permite al usuario establecer nueva contraseña
 * e invalida el token (single-use).
 */

session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

$token   = trim($_GET['token'] ?? '');
$msg     = '';
$msgTipo = '';
$done    = false;

if (!$token) {
    header('Location: recuperar_password.php');
    exit;
}

// Validar token
$resetData = validarTokenReset($conn, $token);
if (!$resetData) {
    $msg     = '❌ El enlace es inválido o ya expiró. Solicita uno nuevo.';
    $msgTipo = 'err';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $resetData) {
    csrf_validate();

    $nueva    = $_POST['nueva_pass'] ?? '';
    $confirma = $_POST['confirmar_pass'] ?? '';

    if (strlen($nueva) < 6) {
        $msg = '❌ La contraseña debe tener al menos 6 caracteres.';
        $msgTipo = 'err';
    } elseif ($nueva !== $confirma) {
        $msg = '❌ Las contraseñas no coinciden.';
        $msgTipo = 'err';
    } else {
        $hash = password_hash($nueva, PASSWORD_BCRYPT, ['cost' => 12]);
        $stmt = $conn->prepare("UPDATE clientes SET password = ? WHERE id = ?");
        $stmt->bind_param('si', $hash, $resetData['user_id']);
        $stmt->execute();
        $stmt->close();

        // Invalidar token (single-use)
        invalidarTokenReset($conn, $token);

        // Revocar todas las sesiones activas por seguridad
        $conn->query("UPDATE sessions SET revoked = 1 WHERE user_id = {$resetData['user_id']}");
        unset($_SESSION['reset_user_id'], $_SESSION['reset_user_email'],
              $_SESSION['reset_user_name'], $_SESSION['reset_link_demo'],
              $_SESSION['reset_sms_demo'], $_SESSION['reset_call_demo']);

        $msg     = '✅ Contraseña actualizada correctamente. Ya puedes iniciar sesión.';
        $msgTipo = 'ok';
        $done    = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Nueva Contraseña — One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="login-body">
<div class="login-card">
  <img src="img/Sombrero.png" alt="Logo" style="width:60px;margin-bottom:8px;">
  <h2>Nueva Contraseña</h2>

  <?php if ($msg): ?>
    <div class="alert-<?= $msgTipo === 'ok' ? 'success' : 'error' ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>

  <?php if ($done): ?>
    <a href="login.php" class="btn-primary" style="display:block;text-align:center;margin-top:12px;">
      🔐 Ir al Login
    </a>
  <?php elseif ($resetData): ?>
  <p class="subtitle">Usuario: <strong style="color:var(--gold-bright);"><?= htmlspecialchars($resetData['nombre_usuario']) ?></strong></p>
  <form method="POST" action="">
    <?= csrf_field() ?>
    <div class="form-group">
      <label>Nueva contraseña</label>
      <input type="password" name="nueva_pass" placeholder="Mínimo 6 caracteres"
             required minlength="6" autocomplete="new-password">
    </div>
    <div class="form-group">
      <label>Confirmar contraseña</label>
      <input type="password" name="confirmar_pass" placeholder="Repite la contraseña"
             required autocomplete="new-password">
    </div>
    <button type="submit" class="btn-primary">💾 Guardar nueva contraseña</button>
  </form>
  <?php else: ?>
    <a href="recuperar_password.php" class="btn-secondary" style="display:block;text-align:center;">← Solicitar nuevo enlace</a>
  <?php endif; ?>
</div>
</body>
</html>

<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * auth.php — Middleware de Autenticación y Control de Acceso
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 *
 * Implementa:
 *  - Validación de sesión en base de datos (multisesiones)
 *  - Control de acceso por rol (RBAC)
 *  - Generación y validación de tokens CSRF
 *  - Detección de brute force
 *  - Protección contra session fixation
 *  - Headers de seguridad HTTP
 */

if (!isset($conn)) {
    include __DIR__ . '/../db.php';
}

// ── Constantes de configuración ──────────────────────────────────────
define('SESSION_LIFETIME',    60 * 60 * 2);   // 2 horas
define('REFRESH_LIFETIME',    60 * 60 * 24 * 7); // 7 días
define('MAX_LOGIN_ATTEMPTS',  5);
define('LOCKOUT_MINUTES',     15);
define('MFA_CODE_EXPIRY_MIN', 10);
define('RESET_TOKEN_EXPIRY',  60 * 30);        // 30 minutos

// ── Headers de seguridad HTTP ─────────────────────────────────────────
function setSecurityHeaders(): void {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://fonts.googleapis.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://fonts.gstatic.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https://api.dicebear.com blob:;");
}
setSecurityHeaders();

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 1: TOKENS CSRF
// Protección contra Cross-Site Request Forgery
// ══════════════════════════════════════════════════════════════════════

/**
 * Genera un token CSRF y lo almacena en sesión.
 * Debe incluirse en todos los formularios POST.
 */
function csrf_generate(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Valida el token CSRF enviado en POST.
 * Aborta con 403 si no coincide.
 */
function csrf_validate(): void {
    $token     = $_POST['csrf_token'] ?? '';
    $expected  = $_SESSION['csrf_token'] ?? '';
    if (!hash_equals($expected, $token)) {
        http_response_code(403);
        die('Error CSRF: token inválido. Recarga la página e intenta de nuevo.');
    }
    // Rotar token después de cada validación exitosa
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

/**
 * Devuelve el campo hidden HTML con el token CSRF.
 */
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_generate()) . '">';
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 2: BRUTE FORCE PROTECTION
// ══════════════════════════════════════════════════════════════════════

/**
 * Registra un intento de login (exitoso o fallido).
 */
function registrarIntento(mysqli $conn, string $identifier, string $ip, bool $success): void {
    $stmt = $conn->prepare(
        "INSERT INTO login_attempts (identifier, ip_address, success) VALUES (?, ?, ?)"
    );
    $s = $success ? 1 : 0;
    $stmt->bind_param('ssi', $identifier, $ip, $s);
    $stmt->execute();
    $stmt->close();
}

/**
 * Comprueba si el usuario/IP está bloqueado por demasiados intentos fallidos.
 * Retorna true si está bloqueado.
 */
function estaBloqueado(mysqli $conn, string $identifier, string $ip): bool {
    $ventana = date('Y-m-d H:i:s', time() - LOCKOUT_MINUTES * 60);

    // Bloquear por identificador (usuario)
    $stmt = $conn->prepare(
        "SELECT COUNT(*) FROM login_attempts
         WHERE identifier = ? AND success = 0 AND created_at >= ?"
    );
    $stmt->bind_param('ss', $identifier, $ventana);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    if ($count >= MAX_LOGIN_ATTEMPTS) return true;

    // Bloquear también por IP (credential stuffing)
    $stmt2 = $conn->prepare(
        "SELECT COUNT(*) FROM login_attempts
         WHERE ip_address = ? AND success = 0 AND created_at >= ?"
    );
    $stmt2->bind_param('ss', $ip, $ventana);
    $stmt2->execute();
    $stmt2->bind_result($countIp);
    $stmt2->fetch();
    $stmt2->close();
    return $countIp >= MAX_LOGIN_ATTEMPTS * 2;
}

/**
 * Retorna los minutos restantes de bloqueo.
 */
function minutosBloqueo(mysqli $conn, string $identifier): int {
    $ventana = date('Y-m-d H:i:s', time() - LOCKOUT_MINUTES * 60);
    $stmt    = $conn->prepare(
        "SELECT MAX(created_at) FROM login_attempts
         WHERE identifier = ? AND success = 0 AND created_at >= ?"
    );
    $stmt->bind_param('ss', $identifier, $ventana);
    $stmt->execute();
    $stmt->bind_result($ultimo);
    $stmt->fetch();
    $stmt->close();
    if (!$ultimo) return 0;
    $segundosRestantes = LOCKOUT_MINUTES * 60 - (time() - strtotime($ultimo));
    return max(0, (int)ceil($segundosRestantes / 60));
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 3: GESTIÓN DE SESIONES EN BD (MULTISESIONES)
// ══════════════════════════════════════════════════════════════════════

/**
 * Crea una nueva sesión en base de datos y devuelve el token.
 * Llamar justo después de autenticar exitosamente.
 */
function crearSesionBD(mysqli $conn, int $userId, string $ip, string $userAgent): string {
    // Limpiar sesiones expiradas del usuario antes de crear una nueva
    $conn->query("DELETE FROM sessions WHERE expires_at < NOW()");

    $token     = bin2hex(random_bytes(64));
    $expiresAt = date('Y-m-d H:i:s', time() + SESSION_LIFETIME);

    $stmt = $conn->prepare(
        "INSERT INTO sessions (user_id, session_token, ip_address, user_agent, expires_at)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param('issss', $userId, $token, $ip, $userAgent, $expiresAt);
    $stmt->execute();
    $stmt->close();

    return $token;
}

/**
 * Valida que el token de sesión existe, no está revocado y no expiró.
 * Actualiza last_activity si es válido.
 * Retorna el registro de sesión o null.
 */
function validarSesionBD(mysqli $conn, string $token): ?array {
    $stmt = $conn->prepare(
        "SELECT s.*, c.nombre_usuario, c.rol, c.email, c.mfa_enabled, c.theme, c.language
         FROM sessions s
         JOIN clientes c ON c.id = s.user_id
         WHERE s.session_token = ?
           AND s.revoked = 0
           AND s.expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result) {
        // Actualizar last_activity
        $conn->query("UPDATE sessions SET last_activity = NOW() WHERE session_token = '" . $conn->real_escape_string($token) . "'");
    }
    return $result ?: null;
}

/**
 * Revoca una sesión específica por su token.
 */
function revocarSesion(mysqli $conn, string $token): void {
    $stmt = $conn->prepare("UPDATE sessions SET revoked = 1 WHERE session_token = ?");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $stmt->close();
}

/**
 * Revoca todas las sesiones de un usuario excepto la actual.
 */
function revocarOtrasSesiones(mysqli $conn, int $userId, string $tokenActual): int {
    $stmt = $conn->prepare(
        "UPDATE sessions SET revoked = 1
         WHERE user_id = ? AND session_token != ? AND revoked = 0"
    );
    $stmt->bind_param('is', $userId, $tokenActual);
    $stmt->execute();
    $afectadas = $stmt->affected_rows;
    $stmt->close();
    return $afectadas;
}

/**
 * Lista todas las sesiones activas de un usuario.
 */
function listarSesiones(mysqli $conn, int $userId): array {
    $stmt = $conn->prepare(
        "SELECT id, session_token, ip_address, user_agent, created_at, last_activity, expires_at
         FROM sessions
         WHERE user_id = ? AND revoked = 0 AND expires_at > NOW()
         ORDER BY last_activity DESC"
    );
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 4: REFRESH TOKENS
// ══════════════════════════════════════════════════════════════════════

/**
 * Genera y almacena un refresh token para un usuario/sesión.
 */
function generarRefreshToken(mysqli $conn, int $userId, int $sessionId): string {
    $token     = bin2hex(random_bytes(64));
    $expiresAt = date('Y-m-d H:i:s', time() + REFRESH_LIFETIME);

    $stmt = $conn->prepare(
        "INSERT INTO refresh_tokens (user_id, token, session_id, expires_at) VALUES (?, ?, ?, ?)"
    );
    $stmt->bind_param('isis', $userId, $token, $sessionId, $expiresAt);
    $stmt->execute();
    $stmt->close();

    return $token;
}

/**
 * Valida un refresh token. Retorna datos del token o null.
 * Marca el token como usado si es válido (single-use).
 */
function validarRefreshToken(mysqli $conn, string $token): ?array {
    $stmt = $conn->prepare(
        "SELECT * FROM refresh_tokens
         WHERE token = ? AND used = 0 AND revoked = 0 AND expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($data) {
        // Marcar como usado (token rotation — previene token replay)
        $conn->query("UPDATE refresh_tokens SET used = 1 WHERE id = {$data['id']}");
    }
    return $data ?: null;
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 5: MFA — CÓDIGOS OTP
// ══════════════════════════════════════════════════════════════════════

/**
 * Genera un código OTP de 6 dígitos y lo almacena en BD.
 * Invalida códigos anteriores del mismo usuario/tipo.
 */
function generarCodigoMFA(mysqli $conn, int $userId, string $tipo = 'email'): string {
    // Invalidar códigos anteriores no usados
    $conn->query("UPDATE mfa_codes SET used = 1 WHERE user_id = $userId AND type = '$tipo' AND used = 0");

    $code      = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiresAt = date('Y-m-d H:i:s', time() + MFA_CODE_EXPIRY_MIN * 60);

    $stmt = $conn->prepare(
        "INSERT INTO mfa_codes (user_id, code, type, expires_at) VALUES (?, ?, ?, ?)"
    );
    $stmt->bind_param('isss', $userId, $code, $tipo, $expiresAt);
    $stmt->execute();
    $stmt->close();

    return $code;
}

/**
 * Valida un código MFA. Retorna true si es correcto y no expiró.
 */
function validarCodigoMFA(mysqli $conn, int $userId, string $code, string $tipo = 'email'): bool {
    $stmt = $conn->prepare(
        "SELECT id FROM mfa_codes
         WHERE user_id = ? AND code = ? AND type = ? AND used = 0 AND expires_at > NOW()"
    );
    $stmt->bind_param('iss', $userId, $code, $tipo);
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($result) {
        // Marcar como usado
        $conn->query("UPDATE mfa_codes SET used = 1 WHERE id = {$result['id']}");
        return true;
    }
    return false;
}

/**
 * Simula envío de OTP por email (en producción usar PHPMailer/SMTP).
 * Devuelve el código para mostrarlo en desarrollo.
 */
function enviarOTPEmail(string $email, string $code, string $nombreUsuario = 'Usuario'): void {
    // Intentar envío real con mailer.php (PHPMailer + Gmail SMTP)
    $mailerPath = __DIR__ . '/../mailer.php';
    if (file_exists($mailerPath)) {
        require_once $mailerPath;
        $enviado = enviarOTPEmailReal($email, $nombreUsuario, $code);
        if ($enviado) {
            error_log("[MFA EMAIL] Enviado realmente a $email | Código: $code");
            return;
        }
    }
    // Fallback simulado si no hay mailer configurado
    error_log("[MFA EMAIL SIMULADO] Para: $email | Código: $code | Expira en " . MFA_CODE_EXPIRY_MIN . " min");
}

/**
 * Simula envío de OTP por SMS.
 */
function enviarOTPSMS(string $phone, string $code): void {
    // Simulado: en producción usar Twilio, AWS SNS, etc.
    error_log("[MFA SMS] Para: $phone | Código: $code | Expira en " . MFA_CODE_EXPIRY_MIN . " min");
}

/**
 * Simula envío de código por llamada telefónica.
 */
function simularLlamada(string $phone, string $code): void {
    error_log("[MFA CALL] Para: $phone | Código de voz: $code | Expira en " . MFA_CODE_EXPIRY_MIN . " min");
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 6: RECUPERACIÓN DE CONTRASEÑA
// ══════════════════════════════════════════════════════════════════════

/**
 * Genera un token de recuperación de contraseña.
 */
function generarTokenReset(mysqli $conn, int $userId, string $tipo, string $ip): string {
    // Invalidar tokens anteriores del mismo tipo
    $conn->query("UPDATE password_resets SET used = 1 WHERE user_id = $userId AND type = '$tipo' AND used = 0");

    $token     = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', time() + RESET_TOKEN_EXPIRY);

    $stmt = $conn->prepare(
        "INSERT INTO password_resets (user_id, token, type, expires_at, ip_address)
         VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param('issss', $userId, $token, $tipo, $expiresAt, $ip);
    $stmt->execute();
    $stmt->close();

    return $token;
}

/**
 * Valida un token de recuperación. Retorna el registro o null.
 */
function validarTokenReset(mysqli $conn, string $token): ?array {
    $stmt = $conn->prepare(
        "SELECT pr.*, c.nombre_usuario, c.email
         FROM password_resets pr
         JOIN clientes c ON c.id = pr.user_id
         WHERE pr.token = ? AND pr.used = 0 AND pr.expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $data ?: null;
}

/**
 * Invalida un token de reset después de usarlo.
 */
function invalidarTokenReset(mysqli $conn, string $token): void {
    $stmt = $conn->prepare("UPDATE password_resets SET used = 1 WHERE token = ?");
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $stmt->close();
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 7: SSO SIMULADO
// ══════════════════════════════════════════════════════════════════════

/**
 * Genera un token SSO para que App B valide sin re-login.
 */
function generarTokenSSO(mysqli $conn, int $userId, string $appOrigin = 'appA'): string {
    $token     = bin2hex(random_bytes(32));
    $expiresAt = date('Y-m-d H:i:s', time() + 300); // 5 minutos

    $stmt = $conn->prepare(
        "INSERT INTO sso_tokens (user_id, token, app_origin, expires_at) VALUES (?, ?, ?, ?)"
    );
    $stmt->bind_param('isss', $userId, $token, $appOrigin, $expiresAt);
    $stmt->execute();
    $stmt->close();

    return $token;
}

/**
 * Valida un token SSO y lo invalida (single-use).
 * Retorna datos del usuario o null.
 */
function validarTokenSSO(mysqli $conn, string $token): ?array {
    $stmt = $conn->prepare(
        "SELECT s.*, c.nombre_usuario, c.rol, c.email
         FROM sso_tokens s
         JOIN clientes c ON c.id = s.user_id
         WHERE s.token = ? AND s.used = 0 AND s.expires_at > NOW()"
    );
    $stmt->bind_param('s', $token);
    $stmt->execute();
    $data = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if ($data) {
        $conn->query("UPDATE sso_tokens SET used = 1 WHERE id = {$data['id']}");
    }
    return $data ?: null;
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 8: RBAC — Control de Acceso por Rol
// ══════════════════════════════════════════════════════════════════════

/**
 * Requiere que el usuario esté autenticado.
 * Si no, redirige al login.
 */
function requireAuth(): void {
    if (!isset($_SESSION['usuario'])) {
        header('Location: /login.php');
        exit;
    }
    // Validar también el token de sesión en BD
    global $conn;
    $tokenBD = $_SESSION['session_token'] ?? null;
    if ($tokenBD && $conn) {
        $sesion = validarSesionBD($conn, $tokenBD);
        if (!$sesion) {
            // Sesión revocada o expirada
            session_unset();
            session_destroy();
            header('Location: /login.php?msg=sesion_expirada');
            exit;
        }
    }
}

/**
 * Requiere que el usuario tenga un rol específico.
 * Aborta con 403 si no tiene permisos.
 */
function requireRole(string ...$roles): void {
    requireAuth();
    $rolUsuario = $_SESSION['usuario']['rol'] ?? '';
    if (!in_array($rolUsuario, $roles, true)) {
        http_response_code(403);
        include __DIR__ . '/../403.html';
        exit;
    }
}

/**
 * Devuelve true si el usuario tiene el rol indicado.
 */
function hasRole(string $rol): bool {
    return ($_SESSION['usuario']['rol'] ?? '') === $rol;
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 9: HELPERS DE IP Y USER-AGENT
// ══════════════════════════════════════════════════════════════════════

function getClientIP(): string {
    $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
    foreach ($headers as $h) {
        if (!empty($_SERVER[$h])) {
            $ip = trim(explode(',', $_SERVER[$h])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

function getUserAgent(): string {
    return substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 512);
}

/**
 * Sanitiza input para prevenir XSS.
 */
function clean(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 10: TOTP — Google Authenticator (RFC 6238)
// Fernando Federico Ledesma Hernández | 221181
// ══════════════════════════════════════════════════════════════════════

function totpGenerarSecreto(int $length = 16): string {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i = 0; $i < $length; $i++) {
        $secret .= $chars[random_int(0, 31)];
    }
    return $secret;
}

function totpBase32Decode(string $base32): string {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $bits = '';
    foreach (str_split(strtoupper($base32)) as $char) {
        $pos = strpos($chars, $char);
        if ($pos === false) continue;
        $bits .= str_pad(decbin($pos), 5, '0', STR_PAD_LEFT);
    }
    $decoded = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) $decoded .= chr(bindec($byte));
    }
    return $decoded;
}

function totpCalcular(string $secret, int $timestamp, int $step = 30): string {
    $key    = totpBase32Decode($secret);
    $time   = str_pad(pack('N', 0) . pack('N', (int)floor($timestamp / $step)), 8, "\0", STR_PAD_LEFT);
    $hash   = hash_hmac('sha1', $time, $key, true);
    $offset = ord(substr($hash, -1)) & 0x0F;
    $code   = ((ord($hash[$offset])   & 0x7F) << 24)
            | ((ord($hash[$offset+1]) & 0xFF) << 16)
            | ((ord($hash[$offset+2]) & 0xFF) << 8)
            |  (ord($hash[$offset+3]) & 0xFF);
    return str_pad((string)($code % 1000000), 6, '0', STR_PAD_LEFT);
}

function totpVerificar(string $secret, string $code, int $window = 1): bool {
    $code = preg_replace('/\s+/', '', $code);
    if (!preg_match('/^\d{6}$/', $code)) return false;
    $now = time();
    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(totpCalcular($secret, $now + $i * 30), $code)) return true;
    }
    return false;
}

// ══════════════════════════════════════════════════════════════════════
// SECCIÓN 11: SMS REAL con Twilio
// ══════════════════════════════════════════════════════════════════════

/**
 * Envía SMS real via Twilio REST API.
 * CONFIGURAR: TWILIO_SID, TWILIO_TOKEN, TWILIO_FROM en config_twilio.php
 */
function enviarSMSReal(string $phone, string $code): bool {
    $configPath = __DIR__ . '/../config_twilio.php';
    if (!file_exists($configPath)) {
        error_log("[TWILIO] config_twilio.php no encontrado. SMS simulado para: $phone | Código: $code");
        return false;
    }
    require_once $configPath;
    if (!defined('TWILIO_SID') || TWILIO_SID === 'TU_ACCOUNT_SID') {
        error_log("[TWILIO] Sin configurar. SMS simulado para: $phone | Código: $code");
        return false;
    }
    $url  = "https://api.twilio.com/2010-04-01/Accounts/" . TWILIO_SID . "/Messages.json";
    $body = http_build_query([
        'From' => TWILIO_FROM,
        'To'   => $phone,
        'Body' => "One Piece Preventas\nTu código de verificación es: $code\nExpira en 10 minutos.",
    ]);
    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => "Authorization: Basic " . base64_encode(TWILIO_SID . ":" . TWILIO_TOKEN) . "\r\n"
                   . "Content-Type: application/x-www-form-urlencoded\r\n",
        'content' => $body,
        'timeout' => 10,
    ]]);
    $resp = @file_get_contents($url, false, $ctx);
    if ($resp === false) {
        error_log("[TWILIO ERROR] No se pudo conectar a la API de Twilio para: $phone");
        return false;
    }
    $data = json_decode($resp, true);
    if (!empty($data['sid'])) {
        error_log("[TWILIO OK] SMS enviado a $phone | SID: {$data['sid']}");
        return true;
    }
    error_log("[TWILIO ERROR] " . ($data['message'] ?? 'Error desconocido'));
    return false;
}

<?php
/**
 * auth/google_callback.php — Callback OAuth 2.0 de Google
 * One Piece Preventas | Fernando Federico Ledesma Hernández | 221181
 */
session_start();
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/auth.php';

// Verificar state anti-CSRF
if (!isset($_GET['state']) || $_GET['state'] !== ($_SESSION['oauth_state'] ?? '')) {
    die('Error de seguridad: state inválido. <a href="../login.php">Volver</a>');
}
unset($_SESSION['oauth_state']);

if (isset($_GET['error'])) {
    header('Location: ../login.php?msg=google_cancelado');
    exit;
}

$code = $_GET['code'] ?? '';
if (!$code) {
    header('Location: ../login.php?msg=error_google');
    exit;
}

// ── Intercambiar code por access_token ───────────────────────────────
$tokenData = json_decode(file_get_contents('https://oauth2.googleapis.com/token', false,
    stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => 'Content-Type: application/x-www-form-urlencoded',
        'content' => http_build_query([
            'code'          => $code,
            'client_id'     => GOOGLE_CLIENT_ID,
            'client_secret' => GOOGLE_CLIENT_SECRET,
            'redirect_uri'  => GOOGLE_REDIRECT_URI,
            'grant_type'    => 'authorization_code',
        ]),
    ]])
), true);

if (!isset($tokenData['access_token'])) {
    header('Location: ../login.php?msg=error_token');
    exit;
}

// ── Obtener info del usuario de Google ───────────────────────────────
$userInfo = json_decode(file_get_contents(
    'https://www.googleapis.com/oauth2/v2/userinfo',
    false,
    stream_context_create(['http' => [
        'header' => 'Authorization: Bearer ' . $tokenData['access_token'],
    ]])
), true);

$googleId = $userInfo['id']       ?? '';
$email    = $userInfo['email']    ?? '';
$nombre   = $userInfo['name']     ?? '';
$picture  = $userInfo['picture']  ?? '';

if (!$googleId || !$email) {
    header('Location: ../login.php?msg=error_google');
    exit;
}

// ── Buscar usuario por google_id o email ─────────────────────────────
$stmt = $conn->prepare("SELECT * FROM clientes WHERE google_id = ? OR email = ? LIMIT 1");
$stmt->bind_param('ss', $googleId, $email);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if ($user) {
    // Actualizar google_id si no lo tenía
    if (!$user['google_id']) {
        $conn->prepare("UPDATE clientes SET google_id = ? WHERE id = ?")->execute();
        $upd = $conn->prepare("UPDATE clientes SET google_id = ? WHERE id = ?");
        $upd->bind_param('si', $googleId, $user['id']);
        $upd->execute();
    }
} else {
    // Crear cuenta nueva con Google
    $nombreUsuario = preg_replace('/[^a-zA-Z0-9_]/', '', str_replace(' ', '_', $nombre));
    // Verificar unicidad del username
    $check = $conn->prepare("SELECT id FROM clientes WHERE nombre_usuario = ?");
    $check->bind_param('s', $nombreUsuario);
    $check->execute();
    if ($check->get_result()->num_rows > 0) {
        $nombreUsuario .= '_' . rand(100, 999);
    }
    $check->close();

    $passHash = password_hash(bin2hex(random_bytes(16)), PASSWORD_BCRYPT);
    $ins = $conn->prepare("INSERT INTO clientes (nombre_usuario, email, password, google_id, rol) VALUES (?, ?, ?, ?, 'cliente')");
    $ins->bind_param('ssss', $nombreUsuario, $email, $passHash, $googleId);
    $ins->execute();
    $newId = $conn->insert_id;
    $ins->close();

    $stmt2 = $conn->prepare("SELECT * FROM clientes WHERE id = ?");
    $stmt2->bind_param('i', $newId);
    $stmt2->execute();
    $user = $stmt2->get_result()->fetch_assoc();
    $stmt2->close();
}

// ── Crear sesión ──────────────────────────────────────────────────────
$ip = getClientIP();
session_regenerate_id(true);
$sessionToken = crearSesionBD($conn, $user['id'], $ip, getUserAgent());
$sessionId    = (int)$conn->insert_id;
$refreshToken = generarRefreshToken($conn, $user['id'], $sessionId);

$_SESSION['usuario'] = [
    'id'             => $user['id'],
    'nombre_usuario' => $user['nombre_usuario'],
    'rol'            => $user['rol'],
    'correo'         => $user['email'],
];
$_SESSION['session_token'] = $sessionToken;
$_SESSION['refresh_token'] = $refreshToken;
$_SESSION['show_welcome']  = true;

header('Location: ../dashboard.php');
exit;

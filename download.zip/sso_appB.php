<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * sso_appB.php — Single Sign-On simulado (App B) — Parte 6
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 *
 * Simula una segunda aplicación (App B) que acepta el token SSO
 * generado por App A (dashboard) sin requerir login adicional.
 *
 * Flujo:
 *   1. Usuario autenticado en App A genera token SSO vía sso_generar.php
 *   2. App A redirige al usuario a sso_appB.php?sso_token=XXX
 *   3. App B valida el token en BD (single-use, expira en 5 min)
 *   4. Si válido → usuario autenticado en App B sin contraseña
 */

session_start();
include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

$ssoToken = trim($_GET['sso_token'] ?? '');
$error    = '';
$userData = null;

if ($ssoToken) {
    $userData = validarTokenSSO($conn, $ssoToken);
    if (!$userData) {
        $error = '❌ Token SSO inválido, expirado o ya utilizado.';
    } else {
        // Autenticar en App B (sesión local de App B)
        session_regenerate_id(true);
        $_SESSION['sso_usuario'] = [
            'id'             => $userData['user_id'],
            'nombre_usuario' => $userData['nombre_usuario'],
            'rol'            => $userData['rol'],
            'correo'         => $userData['email'],
            'via_sso'        => true,
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>App B — SSO One Piece Preventas</title>
  <link rel="stylesheet" href="css/estilos.css">
  <link rel="stylesheet" href="css/animations.css">
</head>
<body class="dashboard-body">
<div class="page-content" style="max-width:700px;margin:60px auto;">
  <div style="background:rgba(30,18,10,0.92);border:2px solid rgba(247,214,122,0.35);border-radius:18px;padding:36px;">
    <h1 style="font-family:'Pirata One',serif;color:var(--gold-bright);text-align:center;margin-bottom:6px;">
      🏴‍☠️ Aplicación B — SSO Demo
    </h1>
    <p style="text-align:center;color:rgba(247,214,122,0.5);margin-bottom:28px;font-size:0.9rem;">
      Parte 6: Single Sign-On Simulado
    </p>

    <?php if ($error): ?>
      <div class="alert-error"><?= htmlspecialchars($error) ?></div>
      <div style="text-align:center;margin-top:16px;">
        <a href="dashboard.php" style="color:var(--gold-bright);">← Volver a App A</a>
      </div>

    <?php elseif (isset($_SESSION['sso_usuario'])): ?>
      <?php $u = $_SESSION['sso_usuario']; ?>
      <div class="alert-success" style="margin-bottom:20px;">
        ✅ <strong>Autenticado exitosamente via SSO</strong><br>
        <small>No se requirió contraseña — token compartido de App A</small>
      </div>
      <div style="display:grid;gap:12px;">
        <div style="background:rgba(247,214,122,0.07);border:1px solid rgba(247,214,122,0.2);border-radius:10px;padding:14px;">
          <div style="font-size:0.75rem;color:rgba(247,214,122,0.5);margin-bottom:6px;">USUARIO AUTENTICADO</div>
          <div style="font-size:1.1rem;color:var(--gold-bright);">⚓ <?= htmlspecialchars($u['nombre_usuario']) ?></div>
          <div style="font-size:0.82rem;color:rgba(247,214,122,0.6);">📧 <?= htmlspecialchars($u['correo']) ?> &nbsp;|&nbsp; 🎭 <?= ucfirst(htmlspecialchars($u['rol'])) ?></div>
        </div>
        <div style="background:rgba(30,160,80,0.08);border:1px solid rgba(60,200,100,0.2);border-radius:10px;padding:14px;">
          <div style="font-size:0.75rem;color:rgba(100,220,130,0.7);margin-bottom:6px;">CÓMO FUNCIONA EL SSO</div>
          <ol style="font-size:0.82rem;color:rgba(247,214,122,0.7);margin:0;padding-left:16px;line-height:1.8;">
            <li>App A genera un token único de 5 minutos en la tabla <code>sso_tokens</code></li>
            <li>App A redirige aquí con <code>?sso_token=XXX</code></li>
            <li>App B valida el token en BD (single-use, se marca como usado)</li>
            <li>Si es válido, App B crea su propia sesión sin pedir contraseña</li>
          </ol>
        </div>
      </div>
      <div style="text-align:center;margin-top:20px;">
        <a href="dashboard.php" class="btn-secondary">← Volver a App A</a>
      </div>

    <?php else: ?>
      <div class="alert-error">No se recibió ningún token SSO.</div>
      <div style="text-align:center;margin-top:16px;">
        <a href="dashboard.php" style="color:var(--gold-bright);">← Volver a App A</a>
      </div>
    <?php endif; ?>
  </div>
</div>
</body>
</html>

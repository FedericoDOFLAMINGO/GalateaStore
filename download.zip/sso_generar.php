<?php
/**
 * Código desarrollado por Fernando Federico Ledesma Hernández
 * Estudiante de Ingeniería en Desarrollo y Gestión de Software
 * Universidad Tecnológica de Aguascalientes
 * Matrícula: 221181 | Grupo: IDGS 8B
 */
/**
 * sso_generar.php — Genera token SSO y redirige a App B
 * One Piece Preventas | IDGS 8B | Fernando Federico Ledesma Hernández | 221181
 */

session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: login.php');
    exit;
}

include __DIR__ . '/db.php';
include __DIR__ . '/seguridad/auth.php';

$userId   = (int)$_SESSION['usuario']['id'];
$token    = generarTokenSSO($conn, $userId, 'appA');

// Redirigir a App B con el token SSO
header("Location: sso_appB.php?sso_token=$token");
exit;
